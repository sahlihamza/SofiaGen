import React, { createContext, useContext, useState, useRef, useEffect, useCallback } from "react";
import { THEMES } from "../../core/editorConfig";
import { initEditor } from "../../core/initEditor";
import { settingsToCssVars } from "../../core/defaultThemeSettings";
import { loadSavedBlocks, injectComponentToolbar } from "../../plugins/registerSavedBlocks";
import ThemeEditorServices from "@/services/ThemeEditorServices";
import globalSectionService from "@/services/globalSectionService";
import userService from "@/services/userService";
import templateService from "@/services/templateService";

const EDITOR_CONTEXT_KEY = "__SOFIAGEN_EDITOR_CONTEXT__";
const EditorContext = typeof globalThis !== "undefined" && globalThis[EDITOR_CONTEXT_KEY]
  ? globalThis[EDITOR_CONTEXT_KEY]
  : createContext();
if (typeof globalThis !== "undefined" && !globalThis[EDITOR_CONTEXT_KEY]) {
  globalThis[EDITOR_CONTEXT_KEY] = EditorContext;
}
const AUTOSAVE_DELAY_MS = 1200;

export const GLOBAL_SECTION_IDS = {
  header: "__global_header__",
  footer: "__global_footer__",
  announcement_bar: "__global_announcement_bar__",
  cookie_banner: "__global_cookie_banner__",
};

const isGlobalSectionId = (id) => Object.values(GLOBAL_SECTION_IDS).includes(id);
const globalSectionTypeFromId = (id) =>
  Object.entries(GLOBAL_SECTION_IDS).find(([, v]) => v === id)?.[0];

export const isPopupId = (id) => id?.startsWith("__popup_");
export const popupIdFromId = (id) => id?.replace("__popup_", "");

function emptyProjectData() {
  return { pages: [{ frames: [{ component: { type: "wrapper", components: [] } }] }] };
}

/**
 * storeId: which store we're editing (required — every page/theme call is scoped to it)
 * onStateChange: optional callback({html, css, projectData}) kept for backward-compat
 */
export const EditorProvider = ({ children, onStateChange, storeId, themeId }) => {
  const editorRef = useRef(null);
  const editorInstanceRef = useRef(null);
  const styleTagRef = useRef(null);
  const saveTimerRef = useRef(null);
  const themeDocRef = useRef(null);      // latest theme doc — used by canvas:frame:load handler
  const currentPageIdRef = useRef(null);
  const pageLoadInProgressRef = useRef(false);

  const [editorTheme, setEditorTheme] = useState("dark");
  const [themeDoc, setThemeDoc] = useState(null); // the store's active Theme doc (settings only)
  const [pages, setPages] = useState([]); // pages fetched from the backend for this store
  const [currentPageId, setCurrentPageId] = useState(null);
  const [isEditingGlobalSection, setIsEditingGlobalSection] = useState(false);
  const [versionHistory, setVersionHistory] = useState([]);
  const [undoStack, setUndoStack] = useState([]);
  const [redoStack, setRedoStack] = useState([]);
  const [pageVersionCounter, setPageVersionCounter] = useState(0);
  const [historyLoading, setHistoryLoading] = useState(false);
  const [historyError, setHistoryError] = useState(null);
  const [undoAvailable, setUndoAvailable] = useState(false);
  const [redoAvailable, setRedoAvailable] = useState(false);
  const [currentDevice, setCurrentDevice] = useState("desktop");
  const [showAddPageModal, setShowAddPageModal] = useState(false);
  const [isLoadingPage, setIsLoadingPage] = useState(false);
  const [saveStatus, setSaveStatus] = useState("idle"); // idle | saving | saved | error
  const [hasUnsavedChanges, setHasUnsavedChanges] = useState(false);
  const [isPageEmpty, setIsPageEmpty] = useState(false);
  const [selectedComponent, setSelectedComponent] = useState(null);
  const selectedComponentRef = useRef(null);
  const [showStructureOutlines, setShowStructureOutlines] = useState(true);
  const structureOutlinesEnabledRef = useRef(true);
  const [isHistoryPanelOpen, setIsHistoryPanelOpen] = useState(false);
  const [pageVersions, setPageVersions] = useState([]);
  const [isLoadingVersions, setIsLoadingVersions] = useState(false);
  const [editorReady, setEditorReady] = useState(false); // forces re-render once GrapesJS is init'd
  const [effectiveStoreId, setEffectiveStoreId] = useState(storeId || null);
  const currentStoreIdRef = useRef(storeId || null);
  
  const [menus, setMenus] = useState({ header: null, footer: null, mobile: null });
  
  const [showMediaLibrary, setShowMediaLibrary] = useState(false);
  const [mediaLibraryCallback, setMediaLibraryCallback] = useState(null);
  const [isCommandPaletteOpen, setIsCommandPaletteOpen] = useState(false);
  const [showGlobalComponentsPanel, setShowGlobalComponentsPanel] = useState(false);
  const [globalEditorBlockId, setGlobalEditorBlockId] = useState(null);
  const [compareMode, setCompareMode] = useState(false);
  const [compareSelected, setCompareSelected] = useState([]);
  const [compareResult, setCompareResult] = useState(null);
  const [isLoadingCompare, setIsLoadingCompare] = useState(false);
  const [compareError, setCompareError] = useState(null);

  const openCommandPalette = useCallback(() => setIsCommandPaletteOpen(true), []);
  const closeCommandPalette = useCallback(() => setIsCommandPaletteOpen(false), []);

  useEffect(() => {
    const handleKeyDown = (e) => {
      if ((e.metaKey || e.ctrlKey) && e.key === "k") {
        e.preventDefault();
        setIsCommandPaletteOpen(prev => !prev);
      }
    };
    document.addEventListener("keydown", handleKeyDown);
    return () => document.removeEventListener("keydown", handleKeyDown);
  }, []);

  const openMediaLibrary = useCallback((callback) => {
    setMediaLibraryCallback(() => callback);
    setShowMediaLibrary(true);
  }, []);

  const closeMediaLibrary = useCallback(() => {
    setShowMediaLibrary(false);
    setMediaLibraryCallback(null);
  }, []);

  useEffect(() => {
    structureOutlinesEnabledRef.current = showStructureOutlines;
  }, [showStructureOutlines]);

  const applyStructureOutlinesClass = useCallback((editorInst) => {
    const editor = editorInst || editorInstanceRef.current;
    if (!editor || !editor.Canvas) return;
    const body = editor.Canvas.getBody?.() || editor.Canvas.getDocument?.()?.body;
    if (!body) return;
    body.classList.toggle("show-structure-outlines", structureOutlinesEnabledRef.current);
  }, []);

  const toggleStructureOutlines = useCallback(() => {
    setShowStructureOutlines((prev) => {
      const next = !prev;
      const editor = editorInstanceRef.current;
      if (editor && editor.Canvas) {
        const body = editor.Canvas.getBody?.() || editor.Canvas.getDocument?.()?.body;
        if (body) body.classList.toggle("show-structure-outlines", next);
      }
      return next;
    });
  }, []);

  const tk = THEMES[editorTheme];

  /* ── Inject / refresh CSS custom properties inside the GrapesJS canvas iframe ── */
  const injectThemeVars = useCallback((themeDoc, editorInst) => {
    const editor = editorInst || editorInstanceRef.current;
    if (!editor) return;
    try {
      const frame = editor.Canvas?.getFrameEl?.();
      const doc   = frame?.contentDocument || frame?.contentWindow?.document;
      if (!doc) return;
      let tag = doc.getElementById("ts-theme-vars");
      if (!tag) {
        tag = doc.createElement("style");
        tag.id = "ts-theme-vars";
        (doc.head || doc.documentElement).appendChild(tag);
      }
      tag.textContent = `${settingsToCssVars(themeDoc?.settings ?? {})}
        /* Section / column hover and selection outlines inside GrapesJS canvas */
        [data-gjs-highlightable].section-component:hover,
        [data-gjs-highlightable].columns-component:hover,
        [data-gjs-highlightable].column-cell:hover {
          outline: 2px dashed rgba(59, 130, 246, 0.55) !important;
          outline-offset: -3px !important;
          box-shadow: inset 0 0 0 1px rgba(59, 130, 246, 0.25) !important;
        }
        [data-gjs-highlightable].section-component.gjs-selected,
        [data-gjs-highlightable].columns-component.gjs-selected,
        [data-gjs-highlightable].column-cell.gjs-selected {
          outline: 2px dashed rgba(16, 185, 129, 0.95) !important;
          outline-offset: -3px !important;
          box-shadow: inset 0 0 0 1px rgba(16, 185, 129, 0.55) !important;
        }
        .gjs-cv-canvas .gjs-highlighter,
        .gjs-cv-canvas .gjs-highlighter-sel {
          outline-style: dashed !important;
          outline-width: 2px !important;
          outline-color: rgba(56, 189, 248, 0.85) !important;
          outline-offset: -2px !important;
          box-shadow: none !important;
          background: transparent !important;
        }
        .gjs-cv-canvas .gjs-highlighter-sel {
          outline-color: rgba(16, 185, 129, 0.95) !important;
        }
      `;

      const fonts = ["Inter:400,500,600,700", "Roboto:400,500,700", "Open Sans:400,600,700", "Poppins:400,500,600,700", "Raleway:400,500,600,700", "Montserrat:400,500,600,700", "Outfit:400,500,600,700", "Space Grotesk:400,500,600,700", "Plus Jakarta Sans:400,500,600,700", "DM Sans:400,500,700", "Playfair Display:400,600,700", "Merriweather:400,700", "Lora:400,500,700", "Work Sans:400,500,600", "Manrope:400,500,600,700", "Urbanist:400,500,600,700", "Sora:400,500,600,700"];
      const url = `https://fonts.googleapis.com/css2?family=${fonts.join("&family=")}&display=swap`;
      let link = doc.getElementById("ts-google-fonts");
      if (!link) {
        link = doc.createElement("link");
        link.id = "ts-google-fonts";
        link.rel = "stylesheet";
        link.href = url;
        (doc.head || doc.documentElement).appendChild(link);
      } else {
        link.href = url;
      }
    } catch (e) {
      console.debug("injectThemeVars failed", e);
    }
  }, []);

  

  /* ── Inject / update GrapesJS CSS overrides when editor theme changes ── */
  useEffect(() => {
    if (!styleTagRef.current) {
      styleTagRef.current = document.createElement("style");
      styleTagRef.current.id = "gjs-theme-overrides";
      document.head.appendChild(styleTagRef.current);
    }
    styleTagRef.current.textContent = THEMES[editorTheme].gjsVars;
  }, [editorTheme]);

  /* ── Persist current page content (debounced) ── */
  const persistCurrentPage = useCallback((pageId) => {
    const editor = editorInstanceRef.current;
    if (!editor || !pageId || pageLoadInProgressRef.current) return;

    if (saveTimerRef.current) clearTimeout(saveTimerRef.current);

    saveTimerRef.current = setTimeout(async () => {
      if (currentPageIdRef.current !== pageId) return; // page changed while waiting
      try {
        setSaveStatus("saving");
        const projectData = editor.getProjectData();
        const compiledHtml = editor.getHtml();
        let compiledCss;
        try {
          compiledCss = editor.getCss({ avoidProtected: true });
        } catch (error) {
          compiledCss = editor.getCss();
        }

        if (isGlobalSectionId(pageId)) {
          const type = globalSectionTypeFromId(pageId);
          await globalSectionService.updateGlobalSection(effectiveStoreId || storeId, type, {
            projectData,
            compiledHtml,
            compiledCss,
          });
        } else if (isPopupId(pageId)) {
          const pId = popupIdFromId(pageId);
          await ThemeEditorServices.updateTemplate(effectiveStoreId || storeId, pId, {
            projectData,
            compiledHtml,
            compiledCss,
          });
        } else {
          await ThemeEditorServices.updatePageContent(pageId, {
            projectData,
            compiledHtml,
            compiledCss,
          });
        }

        const nextVersion = (pageVersionCounter || 0) + 1;
        setUndoStack((prev) => [nextVersion, ...prev]);
        setRedoStack([]);
        setPageVersionCounter(nextVersion);
        setHasUnsavedChanges(false);
        try {
          if (typeof editor.setDirty === "function") editor.setDirty(false);
        } catch (e) {
          console.debug("Failed to clear editor dirty state", e);
        }

        setSaveStatus("saved");
        onStateChange?.({ projectData, compiledHtml, compiledCss });
      } catch (err) {
        console.error("Autosave failed:", err);
        setSaveStatus("error");
      }
    }, AUTOSAVE_DELAY_MS);
  }, [onStateChange, pageVersionCounter, effectiveStoreId, storeId]);

  useEffect(() => {
    currentStoreIdRef.current = effectiveStoreId || storeId;
  }, [effectiveStoreId, storeId]);

  const loadVersionHistory = useCallback(async (pageId) => {
    if (!pageId || isPopupId(pageId)) return;
    setHistoryLoading(true);
    setHistoryError(null);

    try {
      const versions = await ThemeEditorServices.getPageVersions(pageId);
      const summary = Array.isArray(versions) ? versions : versions.data || [];
      setVersionHistory(summary);
      setUndoStack(summary.map((v) => v.versionNumber).reverse());
      setRedoStack([]);
      setPageVersionCounter(summary.length ? summary[summary.length - 1].versionNumber : 0);
    } catch (err) {
      console.error("Failed to load version history:", err);
      setHistoryError("Unable to load version history");
    } finally {
      setHistoryLoading(false);
    }
  }, []);

  /* ── Load a page's content into the (already-initialized) editor ── */
  const loadPage = useCallback(async (pageId) => {
    const editor = editorInstanceRef.current;
    if (!editor || !pageId) return;

    setSelectedComponent(null);
    selectedComponentRef.current = null;
    setIsLoadingPage(true);
    currentPageIdRef.current = pageId;
    try {
      let page;
      if (isPopupId(pageId)) {
        const pId = popupIdFromId(pageId);
        page = await ThemeEditorServices.getTemplateById(effectiveStoreId || storeId, pId);
      } else {
        page = await ThemeEditorServices.getPageContent(pageId);
      }
      
      if (currentPageIdRef.current !== pageId) return; // user switched again meanwhile

      pageLoadInProgressRef.current = true;
      if (page.projectData) {
        editor.loadProjectData(page.projectData);
      } else {
        editor.setComponents(page.html || page.compiledHtml || '<div style="padding:60px;text-align:center;">Empty</div>');
        editor.setStyle(page.css || page.compiledCss || "");
      }
      setHasUnsavedChanges(false);
      setCurrentPageId(pageId);
      pageLoadInProgressRef.current = false;
      if (!isPopupId(pageId) && !isGlobalSectionId(pageId)) {
        await loadVersionHistory(pageId);
      }
    } catch (err) {
      console.error("Failed to load page:", err);
    } finally {
      setIsLoadingPage(false);
    }
  }, [loadVersionHistory]);

  /* ── Fetch the store's theme (settings) + page list, init GrapesJS, load first page ── */
  useEffect(() => {
    if (!editorRef.current || editorInstanceRef.current) return;

    let cancelled = false;

    const bootstrap = async () => {
      let fallbackStoreId = storeId;
      if (!fallbackStoreId) {
        const me = await userService.getMe();
        fallbackStoreId = me?.company || me?.storeId || me?.store || null;
      }

      if (!fallbackStoreId) {
        console.error("Unable to determine storeId for theme editor");
        return;
      }

      setEffectiveStoreId(fallbackStoreId);
      currentStoreIdRef.current = fallbackStoreId;

      const editor = initEditor(editorRef.current, () => currentStoreIdRef.current);
      editorInstanceRef.current = editor;
      setEditorReady(true); // trigger re-render so consumers get the live editor instance

      // Override default asset manager with our React Media Library
      editor.Commands.add("open-assets", {
        run(editor, sender, opts) {
          openMediaLibrary((asset) => {
            if (opts.target) {
              opts.target.set("src", asset.src);
            }
            if (opts.onSelect) {
              opts.onSelect(asset);
            }
          });
        }
      });

      injectComponentToolbar(editor);
      editor.on("saved-blocks:refresh", () => {
        loadSavedBlocks(editor, currentStoreIdRef.current);
      });

      editor.on('saved-blocks:open-editor', ({ blockId } = {}) => {
        setGlobalEditorBlockId(blockId || null);
        setShowGlobalComponentsPanel(true);
      });

      // Any content/style change schedules an autosave for the currently open page
      editor.on("component:update component:add component:remove style:update", () => {
        if (pageLoadInProgressRef.current) return;
        setHasUnsavedChanges(true);
        persistCurrentPage(currentPageIdRef.current);
      });

      const handleSelectedComponent = (maybeComponent) => {
        if (pageLoadInProgressRef.current) return;
        const component = maybeComponent?.component || maybeComponent;
        selectedComponentRef.current = component || null;
        setSelectedComponent(component || null);
      };

      editor.on("component:select", handleSelectedComponent);
      editor.on("component:selected", handleSelectedComponent);
      editor.on("component:toggled", handleSelectedComponent);

      const handleDeselectedComponent = (component) => {
        if (pageLoadInProgressRef.current) return;
        setTimeout(() => {
          try {
            const stillSelected = editor.getSelected && editor.getSelected();
            if (!stillSelected) {
              selectedComponentRef.current = null;
              setSelectedComponent(null);
            }
          } catch (e) {
            console.debug("component:deselected handler error", e);
          }
        }, 0);
      };

      editor.on("component:deselected", handleDeselectedComponent);
      // Update undo/redo button state when editor changes
      const updateUndoRedoState = () => {
        try {
          const um = editor.UndoManager;
          setUndoAvailable(Boolean(um && typeof um.hasUndo === "function" && um.hasUndo()));
          setRedoAvailable(Boolean(um && typeof um.hasRedo === "function" && um.hasRedo()));
        } catch (e) {
          console.debug("updateUndoRedoState error", e);
        }
      };

      editor.on("component:update component:add component:remove style:update", updateUndoRedoState);
      editor.on("run:undo run:redo", updateUndoRedoState);

      // Register keymaps scoped to the editor (won't interfere with inputs outside canvas)
      try {
        // common combos: ctrl+z / cmd+z, ctrl+shift+z, ctrl+y
        if (editor.Keymaps && typeof editor.Keymaps.add === "function") {
          editor.Keymaps.add("core:undo", "ctrl+z", () => editor.UndoManager && editor.UndoManager.undo());
          editor.Keymaps.add("core:undo", "meta+z", () => editor.UndoManager && editor.UndoManager.undo());
          editor.Keymaps.add("core:redo", "ctrl+shift+z", () => editor.UndoManager && editor.UndoManager.redo());
          editor.Keymaps.add("core:redo", "ctrl+y", () => editor.UndoManager && editor.UndoManager.redo());
        }
      } catch (e) {
        console.debug("Failed to register editor keymaps for undo/redo", e);
      }
      editor.on("device:select", (device) => {
        if (device) setCurrentDevice(device.id || device);
      });
      // Re-inject theme CSS vars every time the canvas frame is (re)loaded
      editor.on("canvas:frame:load", () => {
        injectThemeVars(themeDocRef.current, editor);
        attachCanvasGlobalClickHandlers(editor);
        applyStructureOutlinesClass(editor);
      });

      try {
        // If themeId is passed, fetch it. Otherwise get active theme for store
        let fetchedThemeDoc;
        let fetchedPages;

        if (themeId) {
          fetchedThemeDoc = await ThemeEditorServices.getThemeById(themeId);
          if (fetchedThemeDoc.data) fetchedThemeDoc = fetchedThemeDoc.data; // Unwrap if wrapped
        } else {
          fetchedThemeDoc = await ThemeEditorServices.getActiveTheme(fallbackStoreId);
        }
        
        fetchedPages = await ThemeEditorServices.getStorePages(fallbackStoreId);
        
        const fetchedMenusArr = await ThemeEditorServices.getMenusByStore(fallbackStoreId);
        const byLocation = { header: null, footer: null, mobile: null };
        for (const m of fetchedMenusArr) byLocation[m.location] = m;
        setMenus(byLocation);

        if (cancelled) return;

        // Filter pages so we only see pages associated with THIS theme
        const activeThemeId = fetchedThemeDoc._id?.toString() || fetchedThemeDoc.id;
        const filteredPages = fetchedPages.filter(p => {
          const pageThemeId = p.themeId != null ? p.themeId.toString() : null;
          const themeIdStr = activeThemeId != null ? activeThemeId.toString() : null;
          return pageThemeId === themeIdStr;
        });

        setThemeDoc(fetchedThemeDoc);
        themeDocRef.current = fetchedThemeDoc;
        // Inject theme CSS vars into the canvas immediately after init
        injectThemeVars(fetchedThemeDoc, editor);

        let pageList = filteredPages;
        if (pageList.length === 0) {
          // First time this store/theme opens the builder: create a Home page automatically
          const home = await ThemeEditorServices.createPage(fallbackStoreId, { name: "Home", slug: "/", themeId: activeThemeId });
          pageList = [home];
        }
        setPages(pageList);

        const homePage = pageList.find((p) => p.isHome) || pageList[0];
        await loadPage(homePage._id);
      } catch (err) {
        console.error("Failed to bootstrap theme editor:", err);
      }
    };

    bootstrap();

    return () => {
      cancelled = true;
      if (saveTimerRef.current) clearTimeout(saveTimerRef.current);
      if (editorInstanceRef.current) {
        editorInstanceRef.current.destroy();
        editorInstanceRef.current = null;
      }
      if (styleTagRef.current) {
        styleTagRef.current.remove();
        styleTagRef.current = null;
      }
    };
    // include themeId so switching theme reloads bootstrap
  }, [storeId, themeId]);

  /* ── Inject the live menu into the canvas <nav> of a global section ──
     The builder canvas shows the raw HeaderBlock projectData (static
     placeholder links). This replaces those with the real menu items so the
     navigation actually reflects what was configured in the MenuManager. */
  const syncMenuInCanvas = useCallback((editorInst, navClass, menuDoc) => {
    try {
      const editor = editorInst || editorInstanceRef.current;
      if (!editor) return;
      const wrapper = editor.getWrapper();
      if (!wrapper) return;

      let navs = wrapper.find(navClass);
      if (!navs || (Array.isArray(navs) && navs.length === 0)) {
        // No <nav> placeholder present — nothing to inject into
        return;
      }
      const nav = Array.isArray(navs) ? navs[0] : navs;
      if (!nav) return;

      const items = menuDoc?.items || [];
      const buildItem = (item) => {
        const hasChildren = Array.isArray(item.children) && item.children.length > 0;
        const link = {
          tagName: "a",
          attributes: { class: "nav-link", href: item.url || "#" },
          content: item.label || "Lien",
        };
        if (item.openInNewTab) {
          link.attributes.target = "_blank";
          link.attributes.rel = "noopener";
        }
        if (!hasChildren) return link;
        return {
          tagName: "li",
          attributes: { class: "nav-item has-children" },
          components: [link, {
            tagName: "ul",
            attributes: { class: "nav-submenu" },
            components: item.children.map(buildItem),
          }],
        };
      };

      const components = items.length
        ? items.map((it) => buildItem(it))
        : [{ tagName: "a", attributes: { class: "nav-link", href: "#" }, content: "Aucun lien" }];

      nav.components(components);
    } catch (e) {
      console.debug("syncMenuInCanvas failed", e);
    }
  }, []);

  useEffect(() => {
    const editor = editorInstanceRef.current;
    const sid = currentStoreIdRef.current;
    if (!editor || !sid) return;
    loadSavedBlocks(editor, sid);
  }, [effectiveStoreId, storeId]);

  // Keep the canvas header/footer nav in sync with the edited menu while a
  // global section is being edited (e.g. user saves menu items in MenuManager).
  useEffect(() => {
    const editor = editorInstanceRef.current;
    if (!editor || !isEditingGlobalSection || !currentPageId) return;
    const type = globalSectionTypeFromId(currentPageId);
    if (!type) return;
    const navClass = type === "footer" ? ".footer-links" : ".header-nav";
    const menuDoc = menus[type] || null;
    setTimeout(() => syncMenuInCanvas(editor, navClass, menuDoc), 0);
  }, [menus, isEditingGlobalSection, currentPageId, syncMenuInCanvas]);

  const openHistory = useCallback(async () => {
    if (!currentPageId || isPopupId(currentPageId)) return;
    setIsHistoryPanelOpen(true);
    setIsLoadingVersions(true);
    try {
      const versions = await ThemeEditorServices.getPageVersions(currentPageId);
      setPageVersions(Array.isArray(versions) ? versions : (versions.data || []));
    } catch (err) {
      console.error("Failed to load version history:", err);
    } finally {
      setIsLoadingVersions(false);
    }
  }, [currentPageId]);

  const closeHistory = useCallback(() => setIsHistoryPanelOpen(false), []);

  const restoreVersion = useCallback(async (versionNumber) => {
    if (!currentPageId || isPopupId(currentPageId)) return;
    try {
      const restored = await ThemeEditorServices.restorePageVersion(currentPageId, versionNumber);
      const editor = editorInstanceRef.current;
      if (editor && restored?.projectData) {
        editor.loadProjectData(restored.projectData);
      }
    } catch (err) {
      console.error("Failed to restore version:", err);
    } finally {
      setIsHistoryPanelOpen(false);
    }
  }, [currentPageId]);

  const restorePageVersion = useCallback(async (pageId, versionNumber) => {
    if (!pageId) return null;
    const page = await ThemeEditorServices.restorePageVersion(pageId, versionNumber);
    const editor = editorInstanceRef.current;
    if (editor && page?.projectData) {
      editor.loadProjectData(page.projectData);
    }
    await loadVersionHistory(pageId);
    setRedoStack([]);
    return page;
  }, [loadVersionHistory]);

  const compareVersions = useCallback(async (from, to) => {
    if (!currentPageId) return;
    setIsLoadingCompare(true);
    setCompareError(null);
    try {
      const result = await ThemeEditorServices.comparePageVersions(currentPageId, from, to);
      setCompareResult(result?.data || result);
    } catch (err) {
      console.error("Failed to compare versions:", err);
      setCompareError("Impossible de comparer ces versions");
    } finally {
      setIsLoadingCompare(false);
    }
  }, [currentPageId]);

  const closeCompare = useCallback(() => {
    setCompareMode(false);
    setCompareSelected([]);
    setCompareResult(null);
    setCompareError(null);
  }, []);

  const handleUndo = useCallback(async () => {
    if (!currentPageId || undoStack.length === 0) return;
    const [versionNumber, ...rest] = undoStack;
    const nextSnapshotNumber = (pageVersionCounter || 0) + 1;

    try {
      setSaveStatus("saving");
      await restorePageVersion(currentPageId, versionNumber);
      setUndoStack(rest);
      setRedoStack((prev) => [nextSnapshotNumber, ...prev]);
      setSaveStatus("saved");
    } catch (err) {
      console.error("Undo failed:", err);
      setSaveStatus("error");
    }
  }, [currentPageId, undoStack, pageVersionCounter, restorePageVersion]);

  const handleRedo = useCallback(async () => {
    if (!currentPageId || redoStack.length === 0) return;
    const [versionNumber, ...rest] = redoStack;
    const nextSnapshotNumber = (pageVersionCounter || 0) + 1;

    try {
      setSaveStatus("saving");
      await restorePageVersion(currentPageId, versionNumber);
      setRedoStack(rest);
      setUndoStack((prev) => [nextSnapshotNumber, ...prev]);
      setSaveStatus("saved");
    } catch (err) {
      console.error("Redo failed:", err);
      setSaveStatus("error");
    }
  }, [currentPageId, redoStack, pageVersionCounter, restorePageVersion]);

  // NOTE: keyboard shortcuts for undo/redo are registered on the GrapesJS editor
  // via `editor.Keymaps.add(...)` during editor bootstrap. Avoid adding a
  // global `document` keydown handler so text inputs remain working normally.

  /* ── Public API: switch page (flushes pending autosave for the page we leave) ── */
  const saveCurrentPageNow = useCallback(async () => {
    const editor = editorInstanceRef.current;
    if (!editor || !currentPageId || !hasUnsavedChanges) return;

    if (saveTimerRef.current) {
      clearTimeout(saveTimerRef.current);
    }

    try {
      setSaveStatus("saving");
      const projectData = editor.getProjectData();
      const compiledHtml = editor.getHtml();
      let compiledCss;
      try {
        compiledCss = editor.getCss({ avoidProtected: true });
      } catch (error) {
        compiledCss = editor.getCss();
      }

      if (isGlobalSectionId(currentPageId)) {
        const type = globalSectionTypeFromId(currentPageId);
        await globalSectionService.updateGlobalSection(effectiveStoreId || storeId, type, {
          projectData,
          compiledHtml,
          compiledCss,
        });
      } else if (isPopupId(currentPageId)) {
        const pId = popupIdFromId(currentPageId);
        await ThemeEditorServices.updateTemplate(effectiveStoreId || storeId, pId, {
          projectData,
          compiledHtml,
          compiledCss,
        });
      } else {
        await ThemeEditorServices.updatePageContent(currentPageId, {
          projectData,
          compiledHtml,
          compiledCss,
        });
      }

      const nextVersion = (pageVersionCounter || 0) + 1;
      setUndoStack((prev) => [nextVersion, ...prev]);
      setRedoStack([]);
      setPageVersionCounter(nextVersion);
      setHasUnsavedChanges(false);
      try {
        if (typeof editor.setDirty === "function") editor.setDirty(false);
      } catch (e) {
        console.debug("Failed to clear editor dirty state", e);
      }

      setSaveStatus("saved");
      onStateChange?.({ projectData, compiledHtml, compiledCss });
    } catch (err) {
      console.error("Manual save failed:", err);
      setSaveStatus("error");
      throw err;
    }
  }, [currentPageId, effectiveStoreId, hasUnsavedChanges, onStateChange, pageVersionCounter, storeId]);


  const selectPage = useCallback(async (pageId) => {
    if (pageId === currentPageId) return;

    if (saveTimerRef.current) {
      clearTimeout(saveTimerRef.current);
      const editor = editorInstanceRef.current;
      const leavingPageId = currentPageIdRef.current;
      if (editor && leavingPageId) {
        try {
          const projectData = editor.getProjectData();
          const compiledHtml = editor.getHtml();
          let compiledCss;
          try {
            compiledCss = editor.getCss({ avoidProtected: true });
          } catch (error) {
            compiledCss = editor.getCss();
          }
          if (isGlobalSectionId(leavingPageId)) {
            const type = globalSectionTypeFromId(leavingPageId);
            await globalSectionService.updateGlobalSection(effectiveStoreId || storeId, type, {
              projectData,
              compiledHtml,
              compiledCss,
            });
          } else if (isPopupId(leavingPageId)) {
            const pId = popupIdFromId(leavingPageId);
            await ThemeEditorServices.updateTemplate(effectiveStoreId || storeId, pId, {
              projectData,
              compiledHtml,
              compiledCss,
            });
          } else {
            await ThemeEditorServices.updatePageContent(leavingPageId, {
              projectData,
              compiledHtml,
              compiledCss,
            });
          }
        } catch (err) {
          console.error("Failed to flush page before switching:", err);
        }
      }
    }

    const editor = editorInstanceRef.current;
    if (!editor) return;

    setIsLoadingPage(true);
    currentPageIdRef.current = pageId;

    if (isGlobalSectionId(pageId)) {
      try {
        const type = globalSectionTypeFromId(pageId);
        const section = await globalSectionService.getGlobalSection(effectiveStoreId || storeId, type);
        if (currentPageIdRef.current !== pageId) return;
        editor.loadProjectData(section.projectData || emptyProjectData());
        setIsEditingGlobalSection(true);
        setCurrentPageId(pageId);
        // Inject the live menu into the canvas header/footer nav
        const navClass = type === "footer" ? ".footer-links" : ".header-nav";
        const menuDoc = menus[type] || null;
        setTimeout(() => syncMenuInCanvas(editor, navClass, menuDoc), 0);
      } catch (err) {
        console.error("Failed to load global section:", err);
      } finally {
        setIsLoadingPage(false);
      }
      return;
    }

    try {
      await loadPage(pageId);
      setIsEditingGlobalSection(false);
    } finally {
      setIsLoadingPage(false);
    }
  }, [currentPageId, effectiveStoreId, loadPage, storeId]);

  // Attach handlers inside the canvas iframe to support clickable global section previews
  const attachCanvasGlobalClickHandlers = useCallback((editorInst) => {
    try {
      const editor = editorInst || editorInstanceRef.current;
      if (!editor) return;
      const frame = editor.Canvas?.getFrameEl?.();
      const doc = frame?.contentDocument || frame?.contentWindow?.document;
      if (!doc) return;

      if (doc.__tsGlobalHandlerAttached) return;
      doc.__tsGlobalHandlerAttached = true;

      doc.addEventListener("click", (ev) => {
        try {
          const target = ev.target;
          const el = target.closest && target.closest('[data-global-section]');
          if (el) {
            ev.preventDefault();
            ev.stopPropagation();
            const type = el.getAttribute('data-global-section');
            if (type && typeof type === 'string') {
              const gid = GLOBAL_SECTION_IDS[type];
              if (gid) {
                // Switch the editor to the global section for editing
                // Use a microtask so any native handlers finish first
                Promise.resolve().then(() => selectPage(gid));
              }
            }
          }
        } catch (e) {
          // swallow
        }
      }, true);
    } catch (e) {
      console.debug("attachCanvasGlobalClickHandlers failed", e);
    }
  }, [selectPage]);

  /* ── Public API: create a new page for this store ── */
  const addPage = useCallback(async ({ name, slug, projectData, compiledHtml, compiledCss }) => {
    const storeScopeId = effectiveStoreId || storeId;
    if (!storeScopeId) {
      throw new Error("addPage: storeId is not provided. Ensure the 'company' cookie is set.");
    }
    const themeId = themeDoc?._id?.toString() || themeDoc?.id;
    const page = await ThemeEditorServices.createPage(storeScopeId, { name, slug, projectData, compiledHtml, compiledCss, themeId });
    setPages((prev) => [...prev, page]);
    await selectPage(page._id);
    return page;
  }, [effectiveStoreId, storeId, selectPage, themeDoc]);

  const insertLibraryItem = useCallback(async (item, type) => {
    const editor = editorInstanceRef.current;
    if (!editor) {
      throw new Error("insertLibraryItem: editor instance is not available.");
    }

    if (type === "page") {
      const defaultName = item.name || item.title || item.slug || "Nouvelle page";
      return addPage({
        name: defaultName,
        projectData: item.projectData,
        compiledHtml: item.compiledHtml,
        compiledCss: item.compiledCss,
      });
    }

    if (type === "popup") {
      if (!item._id) throw new Error("insertLibraryItem: popup item ID is missing.");
      await loadPage(`__popup_${item._id}`);
      return item;
    }

    if (type === "component") {
      const content = item.componentJson || item.projectData;
      if (!content) {
        throw new Error("insertLibraryItem: component content is missing.");
      }
      editor.addComponent(content);
      return item;
    }

    if (type === "section") {
      const projectData = item.projectData;
      const sectionComponent = projectData?.pages?.[0]?.frames?.[0]?.component;
      if (sectionComponent) {
        const components = sectionComponent.components;
        if (Array.isArray(components) && components.length > 0) {
          editor.addComponents(components);
        } else {
          editor.addComponent(sectionComponent);
        }
      } else if (item.componentJson) {
        editor.addComponent(item.componentJson);
      } else if (item.html || item.compiledHtml) {
        editor.setComponents(item.html || item.compiledHtml);
      } else {
        throw new Error("insertLibraryItem: section content is missing.");
      }
      return item;
    }

    throw new Error(`insertLibraryItem: unsupported library item type '${type}'.`);
  }, [addPage, loadPage]);

  const saveCurrentPageAsTemplate = useCallback(async (pageId, { name, category } = {}) => {
    if (!pageId) throw new Error("pageId required");
    const page = await ThemeEditorServices.getPageContent(pageId);
    const storeScopeId = effectiveStoreId || storeId;
    if (!storeScopeId) throw new Error("storeId missing");

    const tpl = await templateService.createTemplate(storeScopeId, {
      name: name || (page.title || page.name || "Untitled Template"),
      category: category || "Uncategorized",
      projectData: page.projectData,
      compiledHtml: page.html || page.compiledHtml,
      compiledCss: page.css || page.compiledCss,
    });
    return tpl;
  }, [effectiveStoreId, storeId]);

  const refetchMenus = useCallback(async () => {
    const storeScopeId = effectiveStoreId || storeId;
    if (!storeScopeId) return;
    try {
      const fetchedMenusArr = await ThemeEditorServices.getMenusByStore(storeScopeId);
      const byLocation = { header: null, footer: null, mobile: null };
      for (const m of fetchedMenusArr) byLocation[m.location] = m;
      setMenus(byLocation);
    } catch (e) {
      console.error("Failed to refetch menus:", e);
    }
  }, [effectiveStoreId, storeId]);

  const updatePageStatus = useCallback(async (pageId, isPublished) => {
    if (isGlobalSectionId(pageId) || isPopupId(pageId)) return;
    const updated = await ThemeEditorServices.updatePageSettings(pageId, { isPublished });
    setPages(prev => prev.map(p => p._id === pageId ? { ...p, isPublished: updated.isPublished, isDraft: updated.isDraft } : p));
  }, []);

  const schedulePageAt = useCallback(async (pageId, scheduledAt) => {
    if (isGlobalSectionId(pageId) || isPopupId(pageId)) return;
    const updated = await ThemeEditorServices.schedulePage(pageId, scheduledAt);
    setPages(prev => prev.map(p => p._id === pageId ? { ...p, scheduledAt: updated.scheduledAt, scheduleStatus: updated.scheduleStatus } : p));
  }, []);

  const cancelPageSchedule = useCallback(async (pageId) => {
    if (isGlobalSectionId(pageId) || isPopupId(pageId)) return;
    const updated = await ThemeEditorServices.cancelSchedule(pageId);
    setPages(prev => prev.map(p => p._id === pageId ? { ...p, scheduledAt: updated.scheduledAt, scheduleStatus: updated.scheduleStatus } : p));
  }, []);

  const renamePage = useCallback(async (pageId, title, slug) => {
    if (isGlobalSectionId(pageId) || isPopupId(pageId)) return;
    const res = await ThemeEditorServices.updatePageSettings(pageId, { title, slug });
    const updated = res?.data || res;
    setPages(prev => prev.map(p => p._id === pageId ? { ...p, title: updated.title, slug: updated.slug } : p));
  }, []);

  const updatePageSeo = useCallback(async (pageId, seo) => {
    if (isGlobalSectionId(pageId) || isPopupId(pageId)) return;
    const updated = await ThemeEditorServices.updatePageSettings(pageId, { seo });
    const newSeo = (updated && (updated.data?.seo || updated.seo)) || seo;
    setPages(prev => prev.map(p => p._id === pageId ? { ...p, seo: newSeo } : p));
    return newSeo;
  }, []);

  const duplicatePage = useCallback(async (pageId) => {
    if (isGlobalSectionId(pageId) || isPopupId(pageId)) return;
    const newPage = await ThemeEditorServices.duplicatePage(pageId);
    setPages(prev => [...prev, newPage]);
    await selectPage(newPage._id);
  }, [selectPage]);

  const deletePage = useCallback(async (pageId) => {
    if (isGlobalSectionId(pageId) || isPopupId(pageId)) return;
    await ThemeEditorServices.deletePage(pageId);
    setPages(prev => prev.filter(p => p._id !== pageId));
    if (pageId === currentPageId) {
      const nextPages = pages.filter(p => p._id !== pageId);
      const homePage = nextPages.find(p => p.isHome) || nextPages[0];
      if (homePage) await selectPage(homePage._id);
    }
  }, [currentPageId, pages, selectPage]);

  const setHomePage = useCallback(async (pageId) => {
    if (isGlobalSectionId(pageId) || isPopupId(pageId)) return;
    await ThemeEditorServices.setHomePage(pageId);
    setPages(prev => prev.map(p => 
      p._id === pageId ? { ...p, isHome: true, pageType: "home", slug: "/" } 
                       : { ...p, isHome: false, pageType: "custom" }
    ));
  }, []);

  /* ── Public API: update theme-wide settings (colors/typography/...) ──
     This never touches Page documents — every page instantly reflects the
     change because rendering reads theme settings by themeId at display time. */
  const updateThemeSettings = useCallback(async (settings) => {
    const storeScopeId = effectiveStoreId || storeId;
    if (!storeScopeId) {
      throw new Error("updateThemeSettings: storeId is not provided.");
    }
    const updated = await ThemeEditorServices.updateThemeSettings(storeScopeId, settings);
    setThemeDoc(updated);
    themeDocRef.current = updated;
    // Immediately push new CSS variables into the live canvas
    injectThemeVars(updated);
    return updated;
  }, [effectiveStoreId, storeId, injectThemeVars]);

  const isEditingPopup = isPopupId(currentPageId);

  const value = React.useMemo(() => ({
    editor: editorReady ? editorInstanceRef.current : null, // null until GrapesJS is initialised
    editorRef,
    editorTheme,
    setEditorTheme,
    tk,
    showStructureOutlines,
    toggleStructureOutlines,

    theme: themeDoc,      // { _id, name, settings } — design system for the store
    updateThemeSettings,

    undoAvailable,
    redoAvailable,

    pages,               // [{ _id, name, slug, status, isHome }]
    currentPageId,
    isEditingPopup,
    selectPage,
    addPage,
    saveCurrentPageAsTemplate,
    updatePageStatus,
    schedulePageAt,
    cancelPageSchedule,
    renamePage,
    updatePageSeo,
    duplicatePage,
    deletePage,
    insertLibraryItem,
    setHomePage,
    isEditingGlobalSection,
    GLOBAL_SECTION_IDS,
    isLoadingPage,
    saveStatus,          // "idle" | "saving" | "saved" | "error" — drive a small UI indicator

    menus,
    refetchMenus,

    currentDevice,
    setCurrentDevice,
    hasUnsavedChanges,
    isPageEmpty,
    showAddPageModal,
    setShowAddPageModal,
    saveCurrentPageNow,
    // History panel
    isHistoryPanelOpen,
    pageVersions,
    isLoadingVersions,
    openHistory,
    closeHistory,
    restoreVersion,
    versionHistory,
    undoStack,
    redoStack,
    historyLoading,
    historyError,
    loadVersionHistory,
    restorePageVersion,
    handleUndo,
    handleRedo,
    // Compare mode
    compareMode,
    setCompareMode,
    compareSelected,
    setCompareSelected,
    compareResult,
    isLoadingCompare,
    compareError,
    compareVersions,
    closeCompare,
    
    // Media Library
    showMediaLibrary,
    mediaLibraryCallback,
    openMediaLibrary,
    closeMediaLibrary,
    
    // Command Palette
    isCommandPaletteOpen,
    openCommandPalette,
    closeCommandPalette,
  }), [
    editorReady,
    editorRef,
    editorTheme,
    setEditorTheme,
    tk,
    effectiveStoreId,
    storeId,
    themeDoc,
    updateThemeSettings,
    pages,
    currentPageId,
    selectPage,
    addPage,
    saveCurrentPageAsTemplate,
    updatePageStatus,
    schedulePageAt,
    cancelPageSchedule,
    renamePage,
    updatePageSeo,
    duplicatePage,
    deletePage,
    setHomePage,
    isLoadingPage,
    saveStatus,
    menus,
    refetchMenus,
    currentDevice,
    setCurrentDevice,
    hasUnsavedChanges,
    isPageEmpty,
    showAddPageModal,
    setShowAddPageModal,
    saveCurrentPageNow,
    insertLibraryItem,
    isHistoryPanelOpen,
    pageVersions,
    isLoadingVersions,
    openHistory,
    closeHistory,
    restoreVersion,
    versionHistory,
    undoStack,
    redoStack,
    undoAvailable,
    redoAvailable,
    historyLoading,
    historyError,
    loadVersionHistory,
    restorePageVersion,
    handleUndo,
    handleRedo,
    compareMode,
    setCompareMode,
    compareSelected,
    setCompareSelected,
    compareResult,
    isLoadingCompare,
    compareError,
    compareVersions,
    closeCompare,
    showMediaLibrary,
    mediaLibraryCallback,
    openMediaLibrary,
    closeMediaLibrary,
    selectedComponent,
    setSelectedComponent,
    showGlobalComponentsPanel,
    setShowGlobalComponentsPanel,
    globalEditorBlockId,
    isCommandPaletteOpen,
    openCommandPalette,
    closeCommandPalette,
  ]);

  return (
    <EditorContext.Provider value={value}>
      {children}
    </EditorContext.Provider>
  );
};

export const useEditor = () => {
  const context = useContext(EditorContext);
  if (!context) {
    throw new Error("useEditor must be used within an EditorProvider");
  }
  return context;
};
