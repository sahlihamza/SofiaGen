export const THEMES = {
  dark: {
    label: "Dark",
    icon: "🌙",
    sidebar: "#1e1e1e",
    sidebarBorder: "#333",
    header: "#111",
    headerText: "#e0e0e0",
    tabActive: "#3b3b3b",
    tabActiveText: "#4ade80",
    tabActiveBorder: "#4ade80",
    tabText: "#888",
    sectionLabel: "#555",
    canvasBg: "#2a2a2a",
    // GrapesJS CSS overrides injected via a <style> tag
    gjsVars: `
      .gjs-one-bg  { background-color: #1e1e1e !important; }
      .gjs-two-bg  { background-color: #111    !important; }
      .gjs-three-bg{ background-color: #2c2c2c !important; }
      .gjs-four-bg { background-color: #333    !important; }
      .gjs-one-color      { color: #ccc !important; }
      .gjs-two-color      { color: #aaa !important; }
      .gjs-three-color    { color: #888 !important; }
      .gjs-one-color-h:hover { color: #fff !important; }
      .gjs-block { background:#2c2c2c !important; border-color:#444 !important; color:#ddd !important; }
      .gjs-block:hover { background:#3a3a3a !important; }
    `,
  },
  light: {
    label: "Light",
    icon: "☀️",
    sidebar: "#f5f5f5",
    sidebarBorder: "#ddd",
    header: "#ffffff",
    headerText: "#1a1a1a",
    tabActive: "#e8e8e8",
    tabActiveText: "#16a34a",
    tabActiveBorder: "#16a34a",
    tabText: "#666",
    sectionLabel: "#999",
    canvasBg: "#e9ecef",
    gjsVars: `
      .gjs-one-bg  { background-color: #f5f5f5 !important; }
      .gjs-two-bg  { background-color: #ffffff !important; }
      .gjs-three-bg{ background-color: #eeeeee !important; }
      .gjs-four-bg { background-color: #e0e0e0 !important; }
      .gjs-one-color      { color: #333 !important; }
      .gjs-two-color      { color: #555 !important; }
      .gjs-three-color    { color: #777 !important; }
      .gjs-one-color-h:hover { color: #000 !important; }
      .gjs-block { background:#ffffff !important; border-color:#ddd !important; color:#333 !important; }
      .gjs-block:hover { background:#f0f0f0 !important; }
    `,
  },
};
