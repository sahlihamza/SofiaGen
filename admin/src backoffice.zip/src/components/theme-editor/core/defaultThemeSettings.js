/**
 * Default Theme Settings — source of truth for all 9 ThemeSettings sections.
 * All values here correspond 1-to-1 to CSS custom properties injected into the GrapesJS canvas.
 * NEVER hardcode these values directly in block CSS; always use var(--ts-*, fallback).
 */
export const DEFAULT_THEME_SETTINGS = {
  /* ── 1. BRANDING ──────────────────────────────────────────────────────── */
  branding: {
    logo: "",
    logoMobile: "",
    favicon: "",
  },

  /* ── 2. COLORS ────────────────────────────────────────────────────────── */
  colors: {
    primary:       "#667eea",
    secondary:     "#764ba2",
    accent:        "#10b981",
    success:       "#22c55e",
    warning:       "#f59e0b",
    danger:        "#ef4444",
    background:    "#ffffff",
    surface:       "#f8f9fa",
    border:        "#e5e7eb",
    textPrimary:   "#1a1a1a",
    textSecondary: "#6b7280",
    link:          "#667eea",
  },

  /* ── 3. TYPOGRAPHY ────────────────────────────────────────────────────── */
  typography: {
    headingFont:   "Inter",
    bodyFont:      "Inter",
    buttonFont:    "Inter",
    fontSizeScale: "1",
    lineHeight:    "1.6",
    letterSpacing: "0",
  },

  /* Design system: spacing, radius, shadows, breakpoints, typescale */
  spacing: {
    xs: "4px",
    sm: "8px",
    md: "16px",
    lg: "24px",
    xl: "40px",
    "2xl": "64px",
  },
  radius: {
    none: "0px",
    sm: "4px",
    md: "8px",
    lg: "16px",
    full: "9999px",
  },
  shadows: {
    sm: "0 1px 2px rgba(0,0,0,0.05)",
    md: "0 4px 8px rgba(0,0,0,0.1)",
    lg: "0 12px 24px rgba(0,0,0,0.15)",
  },
  breakpoints: {
    mobile: 480,
    tablet: 992,
    laptop: 1280,
    desktop: 0,
  },
  typescale: {
    xs: "12px",
    sm: "14px",
    base: "16px",
    lg: "20px",
    xl: "28px",
    "2xl": "48px",
  },

  /* ── 4. LAYOUT ────────────────────────────────────────────────────────── */
  layout: {
    containerWidth:  "1280px",
    sectionSpacing:  "80px",
    borderRadius:    "8px",
    shadow:          "0 2px 12px rgba(0,0,0,0.08)",
  },

  /* ── 5. BUTTONS ───────────────────────────────────────────────────────── */
  buttons: {
    primaryBg:      "#667eea",
    primaryText:    "#ffffff",
    secondaryBg:    "transparent",
    secondaryText:  "#667eea",
    borderRadius:   "8px",
    padding:        "12px 24px",
    transition:     "0.2s ease",
  },

  /* ── 6. CARDS ─────────────────────────────────────────────────────────── */
  cards: {
    background:  "#ffffff",
    border:      "1px solid #e5e7eb",
    radius:      "12px",
    shadow:      "0 2px 12px rgba(0,0,0,0.08)",
    padding:     "20px",
  },

  /* ── 7. FORMS ─────────────────────────────────────────────────────────── */
  forms: {
    inputRadius:       "6px",
    border:            "1px solid #e5e7eb",
    focusColor:        "#667eea",
    placeholderColor:  "#9ca3af",
    errorColor:        "#ef4444",
  },

  /* ── 8. ANIMATIONS ────────────────────────────────────────────────────── */
  animations: {
    speed:  "200ms",
    easing: "ease",
    type:   "fade",  // fade | slide | none
  },

  /* ── 9. CUSTOM CSS ────────────────────────────────────────────────────── */
  customCss: {
    css: "",
  },

  /* ── HIDDEN (kept in DB, not shown in nav) ───────────────────────────── */
  general: {
    storeName:       "",
    description:     "",
    defaultLanguage: "en",
    currency:        "USD",
    socialLinks: { facebook: "", instagram: "", twitter: "", tiktok: "", youtube: "", pinterest: "" },
  },
  commerce: {
    currency:          "USD",
    taxIncluded:       false,
    shippingNote:      "",
    checkoutStyle:     "multi-step",
    cartStyle:         "drawer",
    wishlistEnabled:   true,
    inventoryTracking: true,
    priceFormat:       "{amount} {currency}",
  },
  productCards: {
    imageRatio:      "1/1",
    hoverEffect:     "zoom",
    showPrice:       true,
    showRating:      true,
    showBadge:       true,
    quickAddButton:  true,
    wishlist:        true,
  },
  navigation: {
    headerStyle:     "sticky",
    megaMenu:        false,
    footerColumns:   4,
    sidebarEnabled:  false,
    breadcrumb:      true,
    searchStyle:     "overlay",
  },
  integrations: {
    googleAnalyticsId:  "",
    facebookPixelId:    "",
    googleTagManagerId: "",
    metaPixelId:        "",
    tiktokPixelId:      "",
    mailchimpApiKey:    "",
  },
};

/**
 * Converts a settings object into CSS custom properties that are injected
 * into the GrapesJS canvas iframe so that blocks can use var(--ts-*).
 */
export function settingsToCssVars(settings = {}) {
  const s = settings;
  const c = s.colors       || DEFAULT_THEME_SETTINGS.colors;
  const t = s.typography   || DEFAULT_THEME_SETTINGS.typography;
  const l = s.layout       || DEFAULT_THEME_SETTINGS.layout;
  const b = s.buttons      || DEFAULT_THEME_SETTINGS.buttons;
  const k = s.cards        || DEFAULT_THEME_SETTINGS.cards;
  const f = s.forms        || DEFAULT_THEME_SETTINGS.forms;
  const a = s.animations   || DEFAULT_THEME_SETTINGS.animations;
  const cc = s.customCss   || DEFAULT_THEME_SETTINGS.customCss;
  const spacing = s.spacing || DEFAULT_THEME_SETTINGS.spacing;
  const radius = s.radius || DEFAULT_THEME_SETTINGS.radius;
  const shadows = s.shadows || DEFAULT_THEME_SETTINGS.shadows;
  const breakpoints = s.breakpoints || DEFAULT_THEME_SETTINGS.breakpoints;
  const typescale = s.typescale || DEFAULT_THEME_SETTINGS.typescale;

  return `
:root {
  /* Colors */
  --ts-color-primary:        ${c.primary};
  --ts-color-secondary:      ${c.secondary};
  --ts-color-accent:         ${c.accent};
  --ts-color-success:        ${c.success};
  --ts-color-warning:        ${c.warning};
  --ts-color-danger:         ${c.danger};
  --ts-color-background:     ${c.background};
  --ts-color-surface:        ${c.surface};
  --ts-color-border:         ${c.border};
  --ts-color-text-primary:   ${c.textPrimary};
  --ts-color-text-secondary: ${c.textSecondary};
  --ts-color-link:           ${c.link};

  /* Typography */
  --ts-font-heading:         '${t.headingFont}', sans-serif;
  --ts-font-body:            '${t.bodyFont}', sans-serif;
  --ts-font-button:          '${t.buttonFont}', sans-serif;
  --ts-font-scale:           ${t.fontSizeScale};
  --ts-line-height:          ${t.lineHeight};
  --ts-letter-spacing:       ${t.letterSpacing}em;

  /* Layout */
  --ts-container-width:      ${l.containerWidth};
  --ts-section-spacing:      ${l.sectionSpacing};
  --ts-border-radius:        ${l.borderRadius};
  --ts-shadow:               ${l.shadow};

  /* Buttons */
  --ts-btn-primary-bg:       ${b.primaryBg};
  --ts-btn-primary-text:     ${b.primaryText};
  --ts-btn-secondary-bg:     ${b.secondaryBg};
  --ts-btn-secondary-text:   ${b.secondaryText};
  --ts-btn-radius:           ${b.borderRadius};
  --ts-btn-padding:          ${b.padding};
  --ts-btn-transition:       ${b.transition};

  /* Cards */
  --ts-card-bg:              ${k.background};
  --ts-card-border:          ${k.border};
  --ts-card-radius:          ${k.radius};
  --ts-card-shadow:          ${k.shadow};
  --ts-card-padding:         ${k.padding};

  /* Forms */
  --ts-input-radius:         ${f.inputRadius};
  --ts-input-border:         ${f.border};
  --ts-focus-color:          ${f.focusColor};
  --ts-placeholder-color:    ${f.placeholderColor};
  --ts-error-color:          ${f.errorColor};

  /* Animations */
  --ts-anim-speed:           ${a.speed};
  --ts-anim-easing:          ${a.easing};
}

/* Spacing */
:root {
  --ts-spacing-xs: ${spacing.xs};
  --ts-spacing-sm: ${spacing.sm};
  --ts-spacing-md: ${spacing.md};
  --ts-spacing-lg: ${spacing.lg};
  --ts-spacing-xl: ${spacing.xl};
  --ts-spacing-2xl: ${spacing["2xl"]};
}

/* Radius */
:root {
  --ts-radius-none: ${radius.none};
  --ts-radius-sm: ${radius.sm};
  --ts-radius-md: ${radius.md};
  --ts-radius-lg: ${radius.lg};
  --ts-radius-full: ${radius.full};
}

/* Shadows */
:root {
  --ts-shadow-sm: ${shadows.sm};
  --ts-shadow-md: ${shadows.md};
  --ts-shadow-lg: ${shadows.lg};
}

/* Typescale */
:root {
  --ts-font-size-xs: ${typescale.xs};
  --ts-font-size-sm: ${typescale.sm};
  --ts-font-size-base: ${typescale.base};
  --ts-font-size-lg: ${typescale.lg};
  --ts-font-size-xl: ${typescale.xl};
  --ts-font-size-2xl: ${typescale["2xl"]};
}

/* Breakpoints (px) */
:root {
  --ts-bp-mobile: ${breakpoints.mobile}px;
  --ts-bp-tablet: ${breakpoints.tablet}px;
  --ts-bp-laptop: ${breakpoints.laptop}px;
  --ts-bp-desktop: ${breakpoints.desktop}px;
}

${cc.css || ""}
  `.trim();
}
