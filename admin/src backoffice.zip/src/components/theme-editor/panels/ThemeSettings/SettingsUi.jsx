import React from "react";
import { useEditor } from "../../hooks/editor/EditorProvider";

/**
 * SettingsUi — primitive building blocks for ThemeSettings sections.
 * All colors come from the tk (editor theme token) object — zero hardcoded values.
 */

/* ─── Field wrapper ───────────────────────────────────────────────────────── */
export const Field = ({ label, hint, children }) => {
  const { tk } = useEditor();
  return (
    <div style={{ marginBottom: 18 }}>
      <label style={{
        display: "block", fontSize: 11, fontWeight: 600,
        color: tk.sectionLabel || tk.tabText,
        textTransform: "uppercase", letterSpacing: 0.8, marginBottom: hint ? 3 : 6,
      }}>
        {label}
      </label>
      {hint && (
        <div style={{ fontSize: 11, color: tk.tabText, marginBottom: 6, opacity: 0.75 }}>
          {hint}
        </div>
      )}
      {children}
    </div>
  );
};

/* ─── Text / Number Input ─────────────────────────────────────────────────── */
export const Input = ({ value, onChange, placeholder, type = "text" }) => {
  const { tk } = useEditor();
  return (
    <input
      type={type}
      value={value ?? ""}
      onChange={e => onChange(e.target.value)}
      placeholder={placeholder}
      style={{
        width: "100%", padding: "7px 10px",
        background: tk.canvasBg, color: tk.headerText,
        border: `1px solid ${tk.sidebarBorder}`,
        borderRadius: 6, fontSize: 13,
        outline: "none", boxSizing: "border-box",
        transition: "border-color 0.15s",
      }}
      onFocus={e => (e.target.style.borderColor = tk.tabActiveBorder)}
      onBlur={e => (e.target.style.borderColor = tk.sidebarBorder)}
    />
  );
};

/* ─── Color Input (swatch + hex text) ────────────────────────────────────── */
export const ColorInput = ({ value, onChange }) => {
  const { tk } = useEditor();
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
      <input
        type="color"
        value={value || "#000000"}
        onChange={e => onChange(e.target.value)}
        style={{
          width: 38, height: 38, border: `1px solid ${tk.sidebarBorder}`,
          borderRadius: 6, cursor: "pointer", padding: 2,
          background: "transparent",
        }}
      />
      <input
        type="text"
        value={value ?? ""}
        onChange={e => onChange(e.target.value)}
        style={{
          flex: 1, padding: "7px 10px",
          background: tk.canvasBg, color: tk.headerText,
          border: `1px solid ${tk.sidebarBorder}`,
          borderRadius: 6, fontSize: 12,
          outline: "none",
          fontFamily: "monospace",
        }}
        onFocus={e => (e.target.style.borderColor = tk.tabActiveBorder)}
        onBlur={e => (e.target.style.borderColor = tk.sidebarBorder)}
        placeholder="#rrggbb"
      />
    </div>
  );
};

/* ─── Select ──────────────────────────────────────────────────────────────── */
export const Select = ({ value, onChange, options }) => {
  const { tk } = useEditor();
  return (
    <select
      value={value ?? ""}
      onChange={e => onChange(e.target.value)}
      style={{
        width: "100%", padding: "7px 10px",
        background: tk.canvasBg, color: tk.headerText,
        border: `1px solid ${tk.sidebarBorder}`,
        borderRadius: 6, fontSize: 13,
        outline: "none", cursor: "pointer",
      }}
    >
      {options.map(o => (
        <option key={o.value} value={o.value}>{o.label}</option>
      ))}
    </select>
  );
};

/* ─── Toggle ──────────────────────────────────────────────────────────────── */
export const Toggle = ({ value, onChange, label }) => {
  const { tk } = useEditor();
  return (
    <div style={{
      display: "flex", alignItems: "center", justifyContent: "space-between",
      marginBottom: 14, padding: "8px 0", borderBottom: `1px solid ${tk.sidebarBorder}`,
    }}>
      <span style={{ fontSize: 13, color: tk.headerText }}>{label}</span>
      <div
        onClick={() => onChange(!value)}
        role="checkbox"
        aria-checked={!!value}
        tabIndex={0}
        onKeyDown={e => e.key === " " && onChange(!value)}
        style={{
          width: 38, height: 21, borderRadius: 11,
          background: value ? tk.tabActiveText : tk.sidebarBorder,
          cursor: "pointer", position: "relative",
          transition: "background 0.2s", flexShrink: 0,
        }}
      >
        <div style={{
          position: "absolute", top: 3,
          left: value ? 19 : 3,
          width: 15, height: 15, borderRadius: "50%",
          background: value ? tk.sidebar : tk.tabText,
          transition: "left 0.2s",
        }} />
      </div>
    </div>
  );
};

/* ─── Section divider title ───────────────────────────────────────────────── */
export const SectionTitle = ({ children }) => {
  const { tk } = useEditor();
  return (
    <div style={{
      fontSize: 10, fontWeight: 700,
      color: tk.sectionLabel || tk.tabText,
      textTransform: "uppercase", letterSpacing: 1.4,
      marginBottom: 14, marginTop: 24,
      paddingBottom: 8,
      borderBottom: `1px solid ${tk.sidebarBorder}`,
    }}>
      {children}
    </div>
  );
};

/* ─── Textarea ────────────────────────────────────────────────────────────── */
export const Textarea = ({ value, onChange, placeholder, rows = 4 }) => {
  const { tk } = useEditor();
  return (
    <textarea
      value={value ?? ""}
      onChange={e => onChange(e.target.value)}
      placeholder={placeholder}
      rows={rows}
      style={{
        width: "100%", padding: "8px 10px",
        background: tk.canvasBg, color: tk.headerText,
        border: `1px solid ${tk.sidebarBorder}`,
        borderRadius: 6, fontSize: 12,
        outline: "none", resize: "vertical",
        fontFamily: "'Fira Code', 'Cascadia Code', monospace",
        lineHeight: 1.6, boxSizing: "border-box",
        transition: "border-color 0.15s",
      }}
      onFocus={e => (e.target.style.borderColor = tk.tabActiveBorder)}
      onBlur={e => (e.target.style.borderColor = tk.sidebarBorder)}
    />
  );
};
