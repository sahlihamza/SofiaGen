import React, { useState } from "react";
import { useEditor } from "../../hooks/editor/EditorProvider";
import { THEMES } from "../../core/editorConfig";
import ThemePicker from "../ThemePicker";
import ThemeSettingsPanel from "../ThemeSettings";
import PageManager from "../PageManager";
import PreviewDrawer from "../PreviewDrawer";
import MenuManager from "../MenuManager";
import PopupManager from "../PopupManager";
import GlobalComponentsPanel from "../GlobalComponentsPanel";
import { notifySuccess, notifyError } from "@/utils/toast";

const Topbar = () => {
  const {
    tk,
    editorTheme,
    setEditorTheme,
    pages,
    currentPageId,
    currentDevice,
    setShowAddPageModal,
    editor,
    saveCurrentPageNow,
    saveStatus,
    hasUnsavedChanges,
    openHistory,
    openCommandPalette,
    undoAvailable,
    redoAvailable,
    handleUndo,
    handleRedo,
    showStructureOutlines,
    toggleStructureOutlines,
  } = useEditor();

  const [showThemePicker, setShowThemePicker] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [showPageManager, setShowPageManager] = useState(false);
  const [showPreview, setShowPreview] = useState(false);
  const [showMenuManager, setShowMenuManager] = useState(false);
  const [showPopupManager, setShowPopupManager] = useState(false);
    const { showGlobalComponentsPanel, setShowGlobalComponentsPanel } = useEditor();
  

  const activePage = pages.find((p) => p._id === currentPageId);
  const pageTitle = activePage ? (activePage.title || activePage.name) : "Pages";
  let saveStatusLabel = "";
  if (saveStatus === "saving") saveStatusLabel = "Saving…";
  else if (saveStatus === "saved") saveStatusLabel = "Saved";
  else if (saveStatus === "error") saveStatusLabel = "Save failed";

  return (
    <>
      {showThemePicker && <ThemePicker onClose={() => setShowThemePicker(false)} />}
      {showSettings && <ThemeSettingsPanel onClose={() => setShowSettings(false)} />}
      {showPageManager && <PageManager onClose={() => setShowPageManager(false)} />}
      {showMenuManager && <MenuManager onClose={() => setShowMenuManager(false)} />}
      {showPopupManager && <PopupManager onClose={() => setShowPopupManager(false)} />}
      <div
        style={{
          height: 40,
          background: tk.header,
          borderBottom: `1px solid ${tk.sidebarBorder}`,
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          padding: "0 12px",
          flexShrink: 0,
          transition: "background 0.25s",
        }}
      >
      {/* Left side: Page Manager */}
      <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
        {/* Pages and theme controls */}
        <button
          onClick={() => setShowPageManager(true)}
          style={{
            background: tk.sidebar,
            color: tk.headerText,
            border: `1px solid ${tk.sidebarBorder}`,
            borderRadius: 6,
            padding: "5px 12px",
            fontSize: 12,
            fontWeight: 600,
            cursor: "pointer",
            display: "flex",
            alignItems: "center",
            gap: 6,
          }}
        >
          <span>📄</span>
          <span>{pageTitle}</span>
          <span style={{ fontSize: 10, opacity: 0.7 }}>▼</span>
        </button>

        <button
          onClick={() => setShowAddPageModal(true)}
          style={{
            background: "#1d4ed8",
            color: "#fff",
            border: "none",
            borderRadius: 6,
            padding: "5px 12px",
            fontSize: 12,
            fontWeight: 600,
            cursor: "pointer",
          }}
        >
          + New page
        </button>

        <button
          onClick={() => setShowThemePicker(true)}
          style={{
            background: "linear-gradient(135deg, #667eea, #764ba2)",
            color: "#fff",
            border: "none",
            borderRadius: 6,
            padding: "5px 12px",
            fontSize: 12,
            fontWeight: 700,
            cursor: "pointer",
            letterSpacing: 0.5,
          }}
        >
          🎨 Themes
        </button>
        
        <button
          onClick={() => setShowMenuManager(true)}
          style={{
            background: "transparent",
            color: tk.headerText,
            border: `1px solid ${tk.sidebarBorder}`,
            borderRadius: 6,
            padding: "5px 12px",
            fontSize: 12,
            fontWeight: 600,
            cursor: "pointer",
          }}
        >
          🧭 Navigation
        </button>
        
        <button
          onClick={() => setShowPopupManager(true)}
          style={{
            background: "transparent",
            color: tk.headerText,
            border: `1px solid ${tk.sidebarBorder}`,
            borderRadius: 6,
            padding: "5px 12px",
            fontSize: 12,
            fontWeight: 600,
            cursor: "pointer",
          }}
        >
          🪟 Popups
        </button>
        <button
          onClick={() => setShowGlobalComponentsPanel(true)}
          style={{
            background: "transparent",
            color: tk.headerText,
            border: `1px solid ${tk.sidebarBorder}`,
            borderRadius: 6,
            padding: "5px 12px",
            fontSize: 12,
            fontWeight: 600,
            cursor: "pointer",
          }}
        >
          🌐 Composants globaux
        </button>
        {showGlobalComponentsPanel && <GlobalComponentsPanel onClose={() => setShowGlobalComponentsPanel(false)} />}
      </div>

      {/* Center: Device Manager */}
      <div style={{ display: "flex", alignItems: "center", gap: 5, flex: 1, justifyContent: "center" }}>
        {["desktop", "tablet", "mobilePortrait"].map(dev => {
          const isSelected = currentDevice === dev;
          let icon = "💻";
          if (dev === "tablet") icon = "📟";
          if (dev === "mobilePortrait") icon = "📱";

          return (
            <button
              key={dev}
              title={dev}
              onClick={() => editor && editor.setDevice(dev)}
              style={{
                padding: "4px 8px",
                fontSize: 14,
                background: isSelected ? tk.tabActive : "transparent",
                color: isSelected ? tk.tabActiveText : tk.tabText,
                border: isSelected ? `1px solid ${tk.tabActiveBorder}` : "1px solid transparent",
                borderRadius: 4,
                cursor: "pointer",
                transition: "all 0.2s"
              }}
            >
              {icon}
            </button>
          )
        })}
      </div>

      {/* Right side: Actions and status */}
      <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
        <span style={{ fontSize: 12, color: tk.tabText, opacity: 0.9 }}>
          {saveStatusLabel}
        </span>

        {/* Undo */}
        <button
          onClick={handleUndo}
          disabled={!undoAvailable}
          title="Annuler (Ctrl+Z)"
          style={{
            background: tk.sidebar,
            color: tk.headerText,
            border: `1px solid ${tk.sidebarBorder}`,
            borderRadius: 6,
            padding: "4px 10px",
            fontSize: 13,
            fontWeight: 600,
            cursor: undoAvailable ? "pointer" : "not-allowed",
            opacity: undoAvailable ? 1 : 0.4,
          }}
        >
          &#8634;
        </button>

        {/* Redo */}
        <button
          onClick={handleRedo}
          disabled={!redoAvailable}
          title="Rétablir (Ctrl+Shift+Z)"
          style={{
            background: tk.sidebar,
            color: tk.headerText,
            border: `1px solid ${tk.sidebarBorder}`,
            borderRadius: 6,
            padding: "4px 10px",
            fontSize: 13,
            fontWeight: 600,
            cursor: redoAvailable ? "pointer" : "not-allowed",
            opacity: redoAvailable ? 1 : 0.4,
          }}
        >
          &#8635;
        </button>

        <button
          onClick={() => setShowPreview(true)}
          title="Preview current page"
          style={{
            background: tk.sidebar,
            color: tk.headerText,
            border: `1px solid ${tk.sidebarBorder}`,
            borderRadius: 6,
            padding: "4px 10px",
            fontSize: 12,
            fontWeight: 600,
            cursor: "pointer",
          }}
        >
          👁️ Preview
        </button>

        <button
          onClick={toggleStructureOutlines}
          title={showStructureOutlines ? "Hide structure outlines" : "Show structure outlines"}
          style={{
            background: tk.sidebar,
            color: tk.headerText,
            border: `1px solid ${tk.sidebarBorder}`,
            borderRadius: 6,
            padding: "4px 10px",
            fontSize: 12,
            fontWeight: 600,
            cursor: "pointer",
          }}
        >
          ▦
        </button>

        <button
          onClick={() => openHistory && openHistory()}
          title="View version history"
          style={{
            background: tk.sidebar,
            color: tk.headerText,
            border: `1px solid ${tk.sidebarBorder}`,
            borderRadius: 6,
            padding: "4px 10px",
            fontSize: 12,
            fontWeight: 600,
            cursor: "pointer",
          }}
        >
          🕒 History
        </button>

        <button
          onClick={() => openCommandPalette && openCommandPalette()}
          title="Command Palette (Ctrl+K)"
          style={{
            background: tk.sidebar,
            color: tk.headerText,
            border: `1px solid ${tk.sidebarBorder}`,
            borderRadius: 6,
            padding: "4px 10px",
            fontSize: 12,
            fontWeight: 600,
            cursor: "pointer",
          }}
        >
          ⌘K
        </button>

        <button
          onClick={async () => {
            if (!hasUnsavedChanges) {
              notifySuccess("No changes to save");
              return;
            }
            try {
              await saveCurrentPageNow();
              notifySuccess("Saved successfully");
            } catch (err) {
              console.error(err);
              notifyError("Save failed");
            }
          }}
          title="Save current page now"
          style={{
            background: "#10b981",
            color: "#fff",
            border: "none",
            borderRadius: 6,
            padding: "6px 14px",
            fontSize: 12,
            fontWeight: 700,
            cursor: "pointer",
          }}
        >
          Save
        </button>

        <div style={{ width: 1, height: 22, background: tk.sidebarBorder }} />

        <span style={{ fontSize: 11, color: tk.tabText }}>Editor theme:</span>

        {Object.entries(THEMES).map(([key, t]) => (
          <button
            key={key}
            onClick={() => setEditorTheme(key)}
            title={t.label}
            style={{
              display: "flex",
              alignItems: "center",
              gap: 5,
              padding: "4px 10px",
              fontSize: 11,
              fontWeight: 600,
              border: editorTheme === key
                ? `1.5px solid ${tk.tabActiveBorder}`
                : `1.5px solid ${tk.sidebarBorder}`,
              borderRadius: 20,
              cursor: "pointer",
              background: editorTheme === key ? tk.tabActive : "transparent",
              color: editorTheme === key ? tk.tabActiveText : tk.tabText,
              transition: "all 0.18s",
            }}
          >
            <span>{t.icon}</span>
            <span>{t.label}</span>
          </button>
        ))}

        {/* Settings gear button */}
        <button
          onClick={() => setShowSettings(true)}
          title="Store Settings"
          style={{
            background: "transparent",
            border: `1px solid ${tk.sidebarBorder}`,
            color: tk.tabText,
            borderRadius: 6,
            padding: "4px 8px",
            fontSize: 16,
            cursor: "pointer",
            marginLeft: 8,
            transition: "all 0.15s",
          }}
        >
          ⚙️
        </button>
      </div>
    </div>
    {showPreview && <PreviewDrawer onClose={() => setShowPreview(false)} />}

  </>
  );
};

export default Topbar;
