import React from "react";
import { useEditor } from "./hooks/editor/EditorProvider";

const LABELS = {
  header: "le Header",
  footer: "le Footer",
  announcement_bar: "la barre d'annonce",
  cookie_banner: "le bandeau cookies",
};

const GlobalSectionBanner = () => {
  const { isEditingGlobalSection, currentPageId, GLOBAL_SECTION_IDS, selectPage, pages } = useEditor();

  if (!isEditingGlobalSection) return null;

  const type = Object.entries(GLOBAL_SECTION_IDS || {}).find(([, id]) => id === currentPageId)?.[0];
  const homePage = pages.find((p) => p.isHome);

  return (
    <div
      style={{
        display: "flex",
        alignItems: "center",
        gap: 10,
        padding: "8px 16px",
        background: "#DBEAFE",
        borderBottom: "1px solid #93C5FD",
        fontSize: 13,
        color: "#1E3A5F",
        flexShrink: 0,
      }}
    >
      <span style={{ fontSize: 16 }}>🔗</span>
      <span>
        Vous modifiez <strong>{LABELS[type] || "une section globale"}</strong> —
        ce changement s'appliquera à <strong>toutes les pages</strong> de la boutique dès la publication.
      </span>
      <button
        onClick={() => homePage && selectPage(homePage._id)}
        style={{
          marginLeft: "auto",
          fontSize: 12,
          padding: "4px 10px",
          borderRadius: 6,
          border: "1px solid #93C5FD",
          background: "transparent",
          color: "#1E3A5F",
          cursor: "pointer",
        }}
      >
        ← Retour à la page
      </button>
    </div>
  );
};

export default GlobalSectionBanner;
