import React from "react";
import { EditorProvider } from "./hooks/editor/EditorProvider";
import Topbar from "./panels/Topbar";
import LeftSidebar from "./panels/LeftSidebar";
import RightSidebar from "./panels/RightSidebar";
import Canvas from "./canvas/Canvas";
import PageModal from "./panels/PageModal";
import HistoryPanel from "./panels/HistoryPanel";
import GlobalSectionBanner from "./GlobalSectionBanner";
import MediaLibraryModal from "./panels/MediaLibraryModal";
import CommandPalette from "./panels/CommandPalette";

/* ─── Layout Component ──────────────────────────────────────────────────────── */
const EditorLayout = () => {
  return (
    <div style={{ display: "flex", flexDirection: "column", height: "100%", width: "100%", overflow: "hidden", fontFamily: "system-ui,sans-serif" }}>
      <Topbar />
      <GlobalSectionBanner />

      <div style={{ display: "flex", flex: 1, overflow: "hidden" }}>
        <LeftSidebar />
        <Canvas />
        <RightSidebar />
      </div>

      <PageModal />
      <HistoryPanel />
      <MediaLibraryModal />
      <CommandPalette />
    </div>
  );
};

/* ─── Main Wrapper ────────────────────────────────────────────────────────── */
/**
 * props.storeId (required): scopes every theme/page API call to this store.
 * props.onStateChange (optional): called with {html, css, projectData} after each autosave.
 */
const GjsEditorShell = (props) => {
  return (
    <EditorProvider {...props}>
      <EditorLayout />
    </EditorProvider>
  );
};

export default GjsEditorShell;
