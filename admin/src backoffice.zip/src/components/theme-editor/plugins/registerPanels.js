/**
 * registerPanels.js
 *
 * Câble le StyleManager NATIF de GrapesJS (editor.StyleManager) sur les
 * composants custom déjà existants dans le projet (ColorPicker,
 * SpacingControl, BorderControl, ShadowControl). Sans ce fichier, le
 * panneau "Styles" de RightSidebar peut afficher une belle UI, mais elle
 * n'est reliée à aucun composant réellement sélectionné dans le canvas.
 *
 * Principe GrapesJS : un "sector" regroupe des "properties". Chaque
 * property peut être `type: 'custom'`, ce qui délègue entièrement le
 * rendu à une fonction `onRender` — c'est là qu'on monte nos composants
 * React existants par-dessus le DOM fourni par GrapesJS.
 *
 * IMPORTANT : adapte les props passées à <ColorPicker>, <SpacingControl>,
 * <BorderControl>, <ShadowControl> à leur signature RÉELLE si elle
 * diffère de celle supposée ici (value / onChange). Vérifie leurs
 * fichiers avant d'utiliser ce plugin tel quel.
 */

import { createRoot } from "react-dom/client";
import React from "react";
import ColorPicker from "../components/ColorPicker";
import SpacingControl from "../components/SpacingControl";
import BorderControl from "../components/BorderControl";
import ShadowControl from "../components/ShadowControl";
import MediaPickerTraitField from "../traits/components/MediaPickerTraitField";
import { GOOGLE_FONTS, SYSTEM_FONTS } from "../core/fonts";

/**
 * Monte un composant React à l'intérieur d'un élément DOM fourni par
 * GrapesJS pour une "custom property", et relie les changements de
 * valeur au binding natif GrapesJS (property.upValue).
 *
 * @param {HTMLElement} el - conteneur fourni par onRender
 * @param {Function} Component - composant React (ColorPicker, etc.)
 * @param {Object} property - instance PropertyView de GrapesJS
 * @param {Object} extraProps - props supplémentaires à transmettre
 */
function mountReactControl(el, Component, property, extraProps = {}) {
  const root = createRoot(el);

  const handleChange = (newValue) => {
    // upValue() est LA méthode native GrapesJS qui pousse la valeur dans
    // le modèle de style du composant sélectionné, déclenche le rendu
    // live dans le canvas ET écrit la règle CSS scoped au device actif
    // (Desktop/Tablet/Mobile) si un device non-défaut est sélectionné.
    property.upValue(newValue, { partial: false });
  };

  const render = () => {
    root.render(
      React.createElement(Component, {
        value: property.getValue(),
        onChange: handleChange,
        ...extraProps,
      })
    );
  };

  render();

  // Re-render si la valeur change depuis l'extérieur (ex: changement de
  // device, ou undo/redo) pour garder le contrôle synchronisé.
  property.on("change:value", render);

  return () => {
    property.off("change:value", render);
    root.unmount();
  };
}

function mountBackgroundImageControl(el, property) {
  const root = createRoot(el);

  const parseUrl = (value) => {
    if (!value) return "";
    const stringValue = String(value).trim();
    const match = stringValue.match(/url\((?:'|")?(.*?)(?:'|")?\)/);
    return match ? match[1] : stringValue;
  };

  const getValue = () => parseUrl(property.getValue());

  const handleChange = (url) => {
    const nextValue = url ? `url("${url}")` : "";
    property.upValue(nextValue, { partial: false });
  };

  const render = () => {
    root.render(
      React.createElement(MediaPickerTraitField, {
        value: getValue(),
        onChange: handleChange,
      })
    );
  };

  render();
  property.on("change:value", render);

  return () => {
    property.off("change:value", render);
    root.unmount();
  };
}

export default function registerPanels(editor) {
  const sm = editor.StyleManager;

  // ─────────────────────────────────────────────────────────
  // SECTOR : Typography
  // ─────────────────────────────────────────────────────────
  sm.addSector("typography", {
    name: "Typographie",
    open: false,
    properties: [
      { property: "font-family", type: "select", defaults: "Inter, sans-serif",
        options: [
          ...SYSTEM_FONTS.map(f => ({ value: f.value, name: f.label })),
          ...GOOGLE_FONTS.map(f => ({ value: `'${f.value}', sans-serif`, name: `${f.label} (Google)` })),
        ] },
      { property: "font-size", type: "integer", units: ["px", "rem", "em"], defaults: "16px" },
      { property: "font-weight", type: "select",
        options: [
          { value: "400", name: "Normal" },
          { value: "500", name: "Medium" },
          { value: "600", name: "Semi-bold" },
          { value: "700", name: "Bold" },
        ] },
      { property: "color", type: "custom",
        onRender: ({ elParent, property }) => mountReactControl(elParent, ColorPicker, property) },
      { property: "text-align", type: "radio",
        options: [
          { value: "left", name: "◀" },
          { value: "center", name: "◆" },
          { value: "right", name: "▶" },
        ] },
      { property: "line-height", type: "integer", units: ["px", "em", "%"], defaults: "1.5" },
    ],
  });

  // ─────────────────────────────────────────────────────────
  // SECTOR : Spacing (margin/padding via SpacingControl custom, 4 côtés)
  // ─────────────────────────────────────────────────────────
  sm.addSector("spacing", {
    name: "Espacement",
    open: false,
    properties: [
      { property: "margin", type: "custom", extend: "margin",
        onRender: ({ elParent, property }) =>
          mountReactControl(elParent, SpacingControl, property, { label: "Marge" }) },
      { property: "padding", type: "custom", extend: "padding",
        onRender: ({ elParent, property }) =>
          mountReactControl(elParent, SpacingControl, property, { label: "Padding" }) },
    ],
  });

  // ─────────────────────────────────────────────────────────
  // SECTOR : Background
  // ─────────────────────────────────────────────────────────
  sm.addSector("background", {
    name: "Arrière-plan",
    open: false,
    properties: [
      { property: "background-color", type: "custom",
        onRender: ({ elParent, property }) => mountReactControl(elParent, ColorPicker, property) },
      { property: "background-image", type: "custom",
        onRender: ({ elParent, property }) => mountBackgroundImageControl(elParent, property) },
      { property: "background-size", type: "select",
        options: [
          { value: "cover", name: "Cover" },
          { value: "contain", name: "Contain" },
          { value: "auto", name: "Auto" },
        ] },
    ],
  });

  // ─────────────────────────────────────────────────────────
  // SECTOR : Border
  // ─────────────────────────────────────────────────────────
  sm.addSector("border", {
    name: "Bordure",
    open: false,
    properties: [
      { property: "border", type: "custom",
        onRender: ({ elParent, property }) => mountReactControl(elParent, BorderControl, property) },
      { property: "border-radius", type: "integer", units: ["px", "%"], defaults: "0" },
    ],
  });

  // ─────────────────────────────────────────────────────────
  // SECTOR : Shadow (box-shadow)
  // ─────────────────────────────────────────────────────────
  sm.addSector("shadow", {
    name: "Ombre",
    open: false,
    properties: [
      { property: "box-shadow", type: "custom",
        onRender: ({ elParent, property }) => mountReactControl(elParent, ShadowControl, property) },
    ],
  });

  // ─────────────────────────────────────────────────────────
  // SECTOR : Flexbox (utile pour les blocs Section/Colonnes)
  // ─────────────────────────────────────────────────────────
  sm.addSector("flex", {
    name: "Disposition",
    open: false,
    properties: [
      { property: "display", type: "select",
        options: [
          { value: "block", name: "Bloc" },
          { value: "flex", name: "Flex" },
          { value: "grid", name: "Grille" },
        ] },
      { property: "flex-direction", type: "select",
        options: [
          { value: "row", name: "Ligne" },
          { value: "column", name: "Colonne" },
        ] },
      { property: "justify-content", type: "select",
        options: [
          { value: "flex-start", name: "Début" },
          { value: "center", name: "Centre" },
          { value: "flex-end", name: "Fin" },
          { value: "space-between", name: "Espacé" },
        ] },
      { property: "align-items", type: "select",
        options: [
          { value: "flex-start", name: "Haut" },
          { value: "center", name: "Centre" },
          { value: "flex-end", name: "Bas" },
        ] },
      { property: "gap", type: "integer", units: ["px", "rem"], defaults: "0" },
    ],
  });
}
