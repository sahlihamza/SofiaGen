import Cookies from "js-cookie";
import { getAccessToken } from "@/services/tokenStore";

const BASE_URL = import.meta.env.VITE_APP_API_BASE_URL;

export const initAssetManager = (editor) => {
  const am = editor.AssetManager;

  // ── 1. Load existing assets from the backend ──────────────────────────
  const loadAssets = () => {
    const token = getAccessToken();
    const company = Cookies.get("company");
    fetch(`${BASE_URL}/assets`, {
      headers: {
        Authorization: token ? `Bearer ${token}` : "",
        company: company || "",
      },
    })
      .then((r) => (r.ok ? r.json() : []))
      .then((assets) => {
        if (Array.isArray(assets)) {
          am.add(assets.map((a) => ({ type: "image", src: a.url, name: a.filename })));
        }
      })
      .catch(() => {});
  };

  loadAssets();

  // ── 2. Override uploadFile — this is the method GrapesJS calls when ──
  //       files are selected from the input or dropped onto the uploader.
  am.uploadFile = async (ev) => {
    const files = ev.dataTransfer
      ? ev.dataTransfer.files
      : ev.target
      ? ev.target.files
      : ev; // some GrapesJS versions pass a FileList directly

    if (!files || files.length === 0) return;

    const token = getAccessToken();
    const company = Cookies.get("company");
    const uploaded = [];

    // Show a loading spinner if the asset manager has one
    editor.trigger("asset:upload:start");

    for (const file of Array.from(files)) {
      try {
        const fd = new FormData();
        fd.append("file", file);

        const res = await fetch(`${BASE_URL}/assets/upload`, {
          method: "POST",
          headers: {
            Authorization: token ? `Bearer ${token}` : "",
            company: company || "",
          },
          body: fd,
        });

        if (!res.ok) {
          const text = await res.text();
          console.error(`[AssetManager] Upload failed (${res.status}):`, text);
          editor.trigger("asset:upload:error", `Upload failed: ${res.status}`);
          continue;
        }

        const asset = await res.json();
        // asset = { _id, url, filename, mimeType, size, ... }
        uploaded.push({ type: "image", src: asset.url, name: asset.filename });
      } catch (err) {
        console.error("[AssetManager] Upload error:", err);
        editor.trigger("asset:upload:error", err);
      }
    }

    if (uploaded.length > 0) {
      am.add(uploaded);
      editor.trigger("asset:upload:end", uploaded);
    }
  };

  return am;
};

export default function registerAssets(editor) {
  return initAssetManager(editor);
}
