import React, { useEffect, useState } from "react";
import { useTranslation } from "react-i18next";
import { FiX } from "react-icons/fi";
import { Button } from "@windmill/react-ui";

const USER_TYPES = [
  { value: "superadmin", label: "SuperAdmin" },
  { value: "platform_admin", label: "Platform Admin" },
  { value: "store_admin", label: "Store Admin" },
  { value: "staff", label: "Staff" },
  { value: "customer", label: "Customer" },
];

const STATUSES = ["Active", "Inactive", "Suspended", "Blocked", "Archived", "Invited", "PendingActivation"];

const PRESETS = [
  { key: "platformOnly", label: "Platform Users" },
  { key: "storeOwners", label: "Store Owners" },
  { key: "staff", label: "Staff" },
  { key: "all", label: "All" },
];

const UserFilterPanel = ({
  isOpen,
  onClose,
  filters,
  setFilters,
  userTypes = [],
  statuses = [],
  roleOptions = [],
  stores = [],
  departments = [],
  onApply,
  onPresetSelect,
}) => {
  const { t } = useTranslation();

  const [localFilters, setLocalFilters] = useState({
    userType: filters?.userType ?? filters?.userTypes ?? [],
    status: filters?.status ?? filters?.statuses ?? [],
    twoFactorEnabled: filters?.twoFactorEnabled ?? null,
    twoFactorVerified: filters?.twoFactorVerified ?? null,
    forcePasswordChange: filters?.forcePasswordChange ?? null,
    storeIds: filters?.storeIds ?? [],
    roleIds: filters?.roleIds ?? [],
    teamId: filters?.teamId ?? null,
    department: filters?.department ?? null,
    platformOnly: filters?.platformOnly ?? true,
    dateFrom: filters?.dateFrom ?? null,
    dateTo: filters?.dateTo ?? null,
    lastLoginFrom: filters?.lastLoginFrom ?? null,
    lastLoginTo: filters?.lastLoginTo ?? null,
  });

  useEffect(() => {
    if (!isOpen) return;
    setLocalFilters({
      userType: filters?.userType ?? filters?.userTypes ?? [],
      status: filters?.status ?? filters?.statuses ?? [],
      twoFactorEnabled: filters?.twoFactorEnabled ?? null,
      twoFactorVerified: filters?.twoFactorVerified ?? null,
      forcePasswordChange: filters?.forcePasswordChange ?? null,
      storeIds: filters?.storeIds ?? [],
      roleIds: filters?.roleIds ?? [],
      teamId: filters?.teamId ?? null,
      department: filters?.department ?? null,
      platformOnly: filters?.platformOnly ?? true,
      dateFrom: filters?.dateFrom ?? null,
      dateTo: filters?.dateTo ?? null,
      lastLoginFrom: filters?.lastLoginFrom ?? null,
      lastLoginTo: filters?.lastLoginTo ?? null,
    });
  }, [isOpen, filters]);

  const toggleArrayValue = (arr, setArr, value) => {
    if (arr.includes(value)) {
      setArr(arr.filter((v) => v !== value));
    } else {
      setArr([...arr, value]);
    }
  };

  const handleApply = () => {
    setFilters(localFilters);
    onApply && onApply(localFilters);
    onClose && onClose();
  };

  const availableUserTypes = userTypes.length > 0 ? userTypes : USER_TYPES;
  const normalizedUserTypes = availableUserTypes.map((ut) =>
    typeof ut === "string" ? { value: ut, label: ut } : ut
  );
  const availableStatuses = statuses.length > 0 ? statuses : STATUSES;
  const platformRoleOptions = roleOptions.filter((r) => !r.scope || r.scope === "platform");

  return (
    <>
      {isOpen && (
        <div
          className="fixed inset-0 bg-black bg-opacity-20 z-30"
          onClick={onClose}
        />
      )}

      <div
        className={`fixed inset-y-0 left-0 z-40 w-80 bg-white dark:bg-gray-800 shadow-xl transform transition-transform duration-300 ease-in-out ${
          isOpen ? "translate-x-0" : "-translate-x-full"
        }`}
      >
        <div className="flex items-center justify-between p-4 border-b border-gray-200 dark:border-gray-700">
          <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100">
            {t("Filters")}
          </h3>
     
        </div>

        <div className="p-4 overflow-y-auto h-full pb-24 space-y-6">
          {/* Presets */}
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              {t("Preset") || "Preset"}
            </label>
            <div className="grid grid-cols-2 gap-2">
              {PRESETS.map((preset) => (
                <button
                  key={preset.key}
                  type="button"
                  onClick={() => onPresetSelect && onPresetSelect(preset.key)}
                  className="px-3 py-2 text-xs font-medium text-center text-gray-700 dark:text-gray-300 bg-gray-100 dark:bg-gray-700 rounded-lg hover:bg-gray-200 dark:hover:bg-gray-600 transition-colors"
                >
                  {t(preset.label) || preset.label}
                </button>
              ))}
            </div>
          </div>

          {/* Platform Only Toggle */}
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              {t("PlatformOnly") || "Platform Only"}
            </label>
            <div className="space-y-2">
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="radio"
                  name="platformOnly"
                  checked={localFilters.platformOnly === true}
                  onChange={() => setLocalFilters({ ...localFilters, platformOnly: true })}
                  className="h-4 w-4 border-gray-300 text-emerald-600 focus:ring-emerald-500"
                />
                <span className="text-sm text-gray-700 dark:text-gray-300">
                  {t("Yes")}
                </span>
              </label>
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="radio"
                  name="platformOnly"
                  checked={localFilters.platformOnly === false}
                  onChange={() => setLocalFilters({ ...localFilters, platformOnly: false })}
                  className="h-4 w-4 border-gray-300 text-emerald-600 focus:ring-emerald-500"
                />
                <span className="text-sm text-gray-700 dark:text-gray-300">
                  {t("No")}
                </span>
              </label>
            </div>
          </div>

          {/* User Type */}
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              {t("UserType")}
            </label>
            <div className="space-y-2">
              {normalizedUserTypes.map((ut) => (
                <label
                  key={ut.value}
                  className="flex items-center gap-2 cursor-pointer"
                >
                  <input
                    type="checkbox"
                    checked={localFilters.userType.includes(ut.value)}
                    onChange={() =>
                      toggleArrayValue(
                        localFilters.userType,
                        (v) => setLocalFilters({ ...localFilters, userType: v }),
                        ut.value
                      )
                    }
                    className="h-4 w-4 rounded border-gray-300 text-emerald-600 focus:ring-emerald-500"
                  />
                  <span className="text-sm text-gray-700 dark:text-gray-300">
                    {t(ut.label) || ut.label}
                  </span>
                </label>
              ))}
            </div>
          </div>

          {/* Status */}
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              {t("Status")}
            </label>
            <div className="space-y-2">
              {availableStatuses.map((st) => (
                <label
                  key={st}
                  className="flex items-center gap-2 cursor-pointer"
                >
                  <input
                    type="checkbox"
                    checked={localFilters.status.includes(st)}
                    onChange={() =>
                      toggleArrayValue(
                        localFilters.status,
                        (v) => setLocalFilters({ ...localFilters, status: v }),
                        st
                      )
                    }
                    className="h-4 w-4 rounded border-gray-300 text-emerald-600 focus:ring-emerald-500"
                  />
                  <span className="text-sm text-gray-700 dark:text-gray-300">
                    {t(st) || st}
                  </span>
                </label>
              ))}
            </div>
          </div>

          {/* 2FA */}
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              {t("TwoFA")}
            </label>
            <div className="space-y-2">
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="radio"
                  name="twoFactorEnabled"
                  checked={localFilters.twoFactorEnabled === true}
                  onChange={() =>
                    setLocalFilters({ ...localFilters, twoFactorEnabled: true })
                  }
                  className="h-4 w-4 border-gray-300 text-emerald-600 focus:ring-emerald-500"
                />
                <span className="text-sm text-gray-700 dark:text-gray-300">
                  {t("Enabled")}
                </span>
              </label>
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="radio"
                  name="twoFactorEnabled"
                  checked={localFilters.twoFactorEnabled === false}
                  onChange={() =>
                    setLocalFilters({ ...localFilters, twoFactorEnabled: false })
                  }
                  className="h-4 w-4 border-gray-300 text-emerald-600 focus:ring-emerald-500"
                />
                <span className="text-sm text-gray-700 dark:text-gray-300">
                  {t("Disabled")}
                </span>
              </label>
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="radio"
                  name="twoFactorEnabled"
                  checked={localFilters.twoFactorEnabled === null}
                  onChange={() =>
                    setLocalFilters({ ...localFilters, twoFactorEnabled: null })
                  }
                  className="h-4 w-4 border-gray-300 text-emerald-600 focus:ring-emerald-500"
                />
                <span className="text-sm text-gray-700 dark:text-gray-300">
                  {t("All")}
                </span>
              </label>
            </div>
          </div>

          {/* Store Assignment */}
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              {t("StoreAssignment")}
            </label>
            <select
              multiple
              value={localFilters.storeIds}
              onChange={(e) => {
                const ids = Array.from(e.target.selectedOptions).map((o) => o.value);
                setLocalFilters({ ...localFilters, storeIds: ids });
              }}
              className="w-full h-32 px-3 py-2 border border-gray-300 rounded-md bg-white dark:bg-gray-700 dark:border-gray-600 dark:text-gray-200 text-sm"
            >
              {stores.map((store) => (
                <option key={store._id} value={store._id}>
                  {store.name}
                </option>
              ))}
            </select>
          </div>

          {/* Role */}
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              {t("Role")}
            </label>
            <select
              multiple
              value={localFilters.roleIds}
              onChange={(e) => {
                const ids = Array.from(e.target.selectedOptions).map((o) => o.value);
                setLocalFilters({ ...localFilters, roleIds: ids });
              }}
              className="w-full h-32 px-3 py-2 border border-gray-300 rounded-md bg-white dark:bg-gray-700 dark:border-gray-600 dark:text-gray-200 text-sm"
            >
              {platformRoleOptions.map((role) => (
                <option key={role._id} value={role._id}>
                  {role.name}
                </option>
              ))}
            </select>
          </div>

          {/* Force Password Change */}
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              {t("ForcePasswordChange")}
            </label>
            <div className="space-y-2">
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="radio"
                  name="forcePasswordChange"
                  checked={localFilters.forcePasswordChange === true}
                  onChange={() => setLocalFilters({ ...localFilters, forcePasswordChange: true })}
                  className="h-4 w-4 border-gray-300 text-emerald-600 focus:ring-emerald-500"
                />
                <span className="text-sm text-gray-700 dark:text-gray-300">{t("Yes")}</span>
              </label>
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="radio"
                  name="forcePasswordChange"
                  checked={localFilters.forcePasswordChange === false}
                  onChange={() => setLocalFilters({ ...localFilters, forcePasswordChange: false })}
                  className="h-4 w-4 border-gray-300 text-emerald-600 focus:ring-emerald-500"
                />
                <span className="text-sm text-gray-700 dark:text-gray-300">{t("No")}</span>
              </label>
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="radio"
                  name="forcePasswordChange"
                  checked={localFilters.forcePasswordChange === null}
                  onChange={() => setLocalFilters({ ...localFilters, forcePasswordChange: null })}
                  className="h-4 w-4 border-gray-300 text-emerald-600 focus:ring-emerald-500"
                />
                <span className="text-sm text-gray-700 dark:text-gray-300">{t("All")}</span>
              </label>
            </div>
          </div>

          {/* Team */}
          {departments && departments.length > 0 && (
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                {t("Department")}
              </label>
              <select
                value={localFilters.department || ""}
                onChange={(e) => setLocalFilters({ ...localFilters, department: e.target.value || null })}
                className="w-full px-3 py-2 border border-gray-300 rounded-md bg-white dark:bg-gray-700 dark:border-gray-600 dark:text-gray-200 text-sm"
              >
                <option value="">{t("AllDepartments")}</option>
                {departments.map((dept) => (
                  <option key={dept} value={dept}>
                    {dept}
                  </option>
                ))}
              </select>
            </div>
          )}

          {/* Last Login Date Range */}
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              {t("LastLoginRange")}
            </label>
            <div className="space-y-3">
              <div>
                <label className="text-xs text-gray-500 dark:text-gray-400">
                  {t("From")}
                </label>
                <input
                  type="date"
                  value={
                    localFilters.lastLoginFrom
                      ? new Date(localFilters.lastLoginFrom).toISOString().split("T")[0]
                      : ""
                  }
                  onChange={(e) =>
                    setLocalFilters({
                      ...localFilters,
                      lastLoginFrom: e.target.value ? new Date(e.target.value) : null,
                    })
                  }
                  className="w-full px-3 py-2 border border-gray-300 rounded-md bg-white dark:bg-gray-700 dark:border-gray-600 dark:text-gray-200 text-sm"
                />
              </div>
              <div>
                <label className="text-xs text-gray-500 dark:text-gray-400">
                  {t("To")}
                </label>
                <input
                  type="date"
                  value={
                    localFilters.lastLoginTo
                      ? new Date(localFilters.lastLoginTo).toISOString().split("T")[0]
                      : ""
                  }
                  onChange={(e) =>
                    setLocalFilters({
                      ...localFilters,
                      lastLoginTo: e.target.value ? new Date(e.target.value) : null,
                    })
                  }
                  className="w-full px-3 py-2 border border-gray-300 rounded-md bg-white dark:bg-gray-700 dark:border-gray-600 dark:text-gray-200 text-sm"
                />
              </div>
            </div>
          </div>

          {/* Date Created */}
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              {t("DateCreated")}
            </label>
            <div className="space-y-3">
              <div>
                <label className="text-xs text-gray-500 dark:text-gray-400">
                  {t("From")}
                </label>
                <input
                  type="date"
                  value={localFilters.dateFrom ? new Date(localFilters.dateFrom).toISOString().split("T")[0] : ""}
                  onChange={(e) =>
                    setLocalFilters({ ...localFilters, dateFrom: e.target.value ? new Date(e.target.value) : null })
                  }
                  className="w-full px-3 py-2 border border-gray-300 rounded-md bg-white dark:bg-gray-700 dark:border-gray-600 dark:text-gray-200 text-sm"
                />
              </div>
              <div>
                <label className="text-xs text-gray-500 dark:text-gray-400">
                  {t("To")}
                </label>
                <input
                  type="date"
                  value={localFilters.dateTo ? new Date(localFilters.dateTo).toISOString().split("T")[0] : ""}
                  onChange={(e) =>
                    setLocalFilters({ ...localFilters, dateTo: e.target.value ? new Date(e.target.value) : null })
                  }
                  className="w-full px-3 py-2 border border-gray-300 rounded-md bg-white dark:bg-gray-700 dark:border-gray-600 dark:text-gray-200 text-sm"
                />
              </div>
            </div>
          </div>
        </div>

      
      </div>
    </>
  );
};

export default UserFilterPanel;
