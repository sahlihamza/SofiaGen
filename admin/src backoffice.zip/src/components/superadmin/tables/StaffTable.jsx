import React from "react";
import { useTranslation } from "react-i18next";
import {
  Table,
  TableCell,
  TableContainer,
  TableHeader,
  TableBody,
  TableRow,
  Pagination,
} from "@windmill/react-ui";
import { FiEye, FiShieldOff, FiPower, FiLock, FiCheck, FiX } from "react-icons/fi";
import { resolveRoleName, toRoleArray } from "@/utils/roleUtils";

const USER_TYPE_CONFIG = {
  superadmin: { label: "SuperAdmin", className: "badge-superadmin" },
  store_admin: { label: "Store Admin", className: "badge-store-admin" },
  staff: { label: "Staff", className: "badge-staff" },
  customer: { label: "Customer", className: "badge-customer" },
  platform_admin: { label: "Platform Admin", className: "badge-platform-admin" },
};

const getStatusBadge = (status) => {
  switch (status) {
    case "Active":
      return { label: "Active", className: "status-active", icon: "✓" };
    case "Inactive":
      return { label: "Inactive", className: "status-inactive", icon: "—" };
    case "Suspended":
      return { label: "Suspended", className: "status-suspended", icon: "⚠" };
    case "PendingActivation":
      return { label: "Pending", className: "status-pending", icon: "⏳" };
    case "Invited":
      return { label: "Invited", className: "status-invited", icon: "✉" };
    default:
      return { label: status || "Unknown", className: "status-inactive", icon: "—" };
  }
};

const formatDate = (dateStr) => {
  if (!dateStr) return "—";
  const date = new Date(dateStr);
  const diffMs = Date.now() - date.getTime();
  const diffMins = Math.floor(diffMs / 60000);
  const diffHours = Math.floor(diffMins / 60);
  const diffDays = Math.floor(diffHours / 24);

  if (diffMins < 1) return "Just now";
  if (diffMins < 60) return `${diffMins}m ago`;
  if (diffHours < 24) return `${diffHours}h ago`;
  if (diffDays < 7) return `${diffDays}d ago`;
  return date.toLocaleDateString();
};

const getColumns = (userType) => {
  switch (userType) {
    case "superadmin":
      return ["name", "email", "status", "twoFA", "lastLogin", "actions"];
    case "platform_admin":
      return ["name", "email", "platformRole", "status", "lastLogin", "actions"];
    case "staff":
      return ["name", "email", "platformRole", "status", "lastLogin", "actions"];
    default:
      return ["name", "email", "userType", "platformRole", "status", "lastLogin", "actions"];
  }
};

const renderCell = (user, columnKey, t) => {
  switch (columnKey) {
    case "name":
      return (
        <div className="flex items-center gap-3">
          <div className="flex-shrink-0 w-9 h-9 rounded-full bg-gray-200 dark:bg-gray-600 flex items-center justify-center overflow-hidden">
            {user.image ? (
              <img src={user.image} alt={user.firstName || user.name} className="w-full h-full object-cover" />
            ) : (
              <span className="text-xs font-medium text-gray-600 dark:text-gray-300">
                {(user.firstName || user.name || user.email)?.charAt(0)?.toUpperCase()}
              </span>
            )}
          </div>
          <div>
            <p className="font-medium text-sm text-gray-900 dark:text-gray-100">
              {user.firstName && user.lastName
                ? `${user.firstName} ${user.lastName}`
                : user.displayName || user.name}
            </p>
          </div>
        </div>
      );
    case "email":
      return <span className="text-sm text-gray-900 dark:text-gray-100">{user.email}</span>;
    case "userType": {
      const config = USER_TYPE_CONFIG[user.userType] || USER_TYPE_CONFIG.customer;
      return (
        <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${config.className}`}>
          {t(config.label) || config.label}
        </span>
      );
    }
    case "platformRole": {
      const roles = toRoleArray(user?.platformRoles || user?.role);
      return (
        <div className="flex flex-wrap gap-1">
          {roles.length > 0 ? (
            roles.map((role, idx) => (
              <span
                key={idx}
                className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-emerald-50 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-200"
              >
                {typeof role === "string" ? resolveRoleName(role, []) : role?.name || "—"}
              </span>
            ))
          ) : (
            <span className="text-xs text-gray-400 dark:text-gray-500">—</span>
          )}
        </div>
      );
    }
    case "status": {
      const badge = getStatusBadge(user.status);
      return (
        <span className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-medium ${badge.className}`}>
          <span>{badge.icon}</span>
          {t(badge.label) || badge.label}
        </span>
      );
    }
    case "twoFA":
      return user.twoFactorEnabled ? (
        <span className="inline-flex items-center gap-1 text-xs text-blue-600 dark:text-blue-400">
          <FiLock size={14} /> {t("Enabled") || "Enabled"}
        </span>
      ) : (
        <span className="inline-flex items-center gap-1 text-xs text-gray-400 dark:text-gray-500">
          {t("Disabled") || "Disabled"}
        </span>
      );
    case "lastLogin":
      return <span className="text-sm text-gray-600 dark:text-gray-300">{formatDate(user.lastLogin)}</span>;
    case "actions":
      return (
        <div className="flex items-center gap-1">
          <button
            onClick={(e) => {
              e.stopPropagation();
              onViewUser && onViewUser(user);
            }}
            className="p-1.5 text-blue-600 hover:text-blue-800 dark:text-blue-400 dark:hover:text-blue-300 rounded hover:bg-blue-50 dark:hover:bg-blue-900/20"
            title={t("View") || "View"}
          >
            <FiEye size={16} />
          </button>
          {(user.status === "PendingActivation" || user.status === "Invited") && (
            <>
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  onApproveUser && onApproveUser(user);
                }}
                className="p-1.5 text-emerald-600 hover:text-emerald-800 dark:text-emerald-400 dark:hover:text-emerald-300 rounded hover:bg-emerald-50 dark:hover:bg-emerald-900/20"
                title={t("Approve") || "Approve"}
              >
                <FiCheck size={16} />
              </button>
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  onRejectUser && onRejectUser(user);
                }}
                className="p-1.5 text-red-600 hover:text-red-800 dark:text-red-400 dark:hover:text-red-300 rounded hover:bg-red-50 dark:hover:bg-red-900/20"
                title={t("Reject") || "Reject"}
              >
                <FiX size={16} />
              </button>
            </>
          )}
          {user.status === "Suspended" ? (
            <button
              onClick={(e) => {
                e.stopPropagation();
                onReactivateUser && onReactivateUser(user);
              }}
              className="p-1.5 text-green-600 hover:text-green-800 dark:text-green-400 dark:hover:text-green-300 rounded hover:bg-green-50 dark:hover:bg-green-900/20"
              title={t("Reactivate") || "Reactivate"}
            >
              <FiPower size={16} />
            </button>
          ) : (
            <button
              onClick={(e) => {
                e.stopPropagation();
                onSuspendUser && onSuspendUser(user);
              }}
              className="p-1.5 text-orange-600 hover:text-orange-800 dark:text-orange-400 dark:hover:text-orange-300 rounded hover:bg-orange-50 dark:hover:bg-orange-900/20"
              title={t("Suspend") || "Suspend"}
            >
              <FiShieldOff size={16} />
            </button>
          )}
          <button
            onClick={(e) => {
              e.stopPropagation();
              onResetPassword && onResetPassword(user);
            }}
            className="p-1.5 text-blue-600 hover:text-blue-800 dark:text-blue-400 dark:hover:text-blue-300 rounded hover:bg-blue-50 dark:hover:bg-blue-900/20"
            title={t("ResetPassword") || "Reset Password"}
          >
            <FiLock size={16} />
          </button>
        </div>
      );
    default:
      return <span className="text-sm text-gray-600 dark:text-gray-300">{user[columnKey] || "—"}</span>;
  }
};

const StaffTable = ({ users = [], userType = "all", onViewUser, pagination = {}, onSuspendUser, onReactivateUser, onDeleteUser, onResetPassword, onPageChange, onApproveUser, onRejectUser }) => {
  const { t } = useTranslation();
  const columns = getColumns(userType);

  const labelMap = {
    name: "Name",
    email: "Email",
    userType: "Type",
    platformRole: "PlatformRole",
    status: "Status",
    twoFA: "2FA",
    lastLogin: "LastLogin",
    actions: "Actions",
  };

  return (
    <TableContainer className="mb-0">
      <Table>
        <TableHeader>
          <tr className="bg-gray-50 dark:bg-gray-800">
            {columns.map((col) => (
              <TableCell key={col} className="cursor-default">
                <span className="font-medium text-xs text-gray-700 dark:text-gray-300 uppercase tracking-wider">
                  {t(labelMap[col] || col)}
                </span>
              </TableCell>
            ))}
          </tr>
        </TableHeader>
        <TableBody>
          {users.map((user) => (
            <TableRow
              key={user._id}
              className="hover:bg-gray-50 dark:hover:bg-gray-700/50 cursor-pointer transition-colors"
              onClick={() => onViewUser && onViewUser(user)}
            >
              {columns.map((col) => (
                <TableCell key={`${user._id}-${col}`}>
                  {renderCell(user, col, t)}
                </TableCell>
              ))}
            </TableRow>
          ))}
        </TableBody>
      </Table>
      {pagination.total > 0 && (
        <div className="flex items-center justify-between p-4 text-sm text-gray-600 dark:text-gray-400 border-t border-gray-200 dark:border-gray-700">
          <span>
            {t("Showing")} {Math.min((pagination.page - 1) * pagination.limit + 1, pagination.total)}{" "}
            {t("To")} {Math.min(pagination.page * pagination.limit, pagination.total)}{" "}
            {t("Of")} {pagination.total}
          </span>
          <Pagination
            totalResults={pagination.total || 0}
            resultsPerPage={pagination.limit || 25}
            onChange={(page) => onPageChange && onPageChange(page + 1)}
            label="Table navigation"
          />
        </div>
      )}
    </TableContainer>
  );
};

export default StaffTable;
