import React, { useState } from "react";
import { useTranslation } from "react-i18next";
import { Modal, ModalBody, ModalFooter, Button, Select } from "@windmill/react-ui";
import { useQuery } from "@tanstack/react-query";
import userAPI from "@/services/api/userAPI";

const AddTeamMemberModal = ({ isOpen, onClose, onAdd, isSubmitting }) => {
  const { t } = useTranslation();
  const [selectedUserId, setSelectedUserId] = useState("");

  const { data: usersData, isLoading } = useQuery({
    queryKey: ["all-users-for-team"],
    queryFn: async () => {
      // Pour éviter de charger des millions d'utilisateurs,
      // on pourrait idéalement utiliser un Select asynchrone avec recherche.
      // Ici nous demandons les 200 derniers pour l'exemple.
      return await userAPI.getAllUsers({ limit: 200, status: "Active" });
    },
    enabled: isOpen,
  });

  const users = usersData?.data?.data || usersData?.data || [];

  const handleSubmit = () => {
    if (selectedUserId) {
      onAdd(selectedUserId);
    }
  };

  return (
    <Modal isOpen={isOpen} onClose={isSubmitting ? undefined : onClose}>
      <ModalBody className="p-6">
        <h2 className="text-xl font-semibold text-gray-900 dark:text-gray-100 mb-4">
          {t("AddTeamMember") || "Ajouter un membre"}
        </h2>
        
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
              {t("SelectUser") || "Sélectionner un utilisateur"}
            </label>
            <Select 
              value={selectedUserId} 
              onChange={(e) => setSelectedUserId(e.target.value)}
              className="mt-1"
              disabled={isLoading || isSubmitting}
            >
              <option value="" disabled>
                {isLoading ? (t("Loading") || "Chargement...") : (t("ChooseUser") || "Choisir un utilisateur...")}
              </option>
              {users.map((user) => (
                <option key={user._id} value={user._id}>
                  {user.name || user.email} ({user.email})
                </option>
              ))}
            </Select>
          </div>
        </div>
      </ModalBody>
      <ModalFooter>
        <div className="w-full sm:w-auto flex flex-col sm:flex-row items-center justify-end gap-2">
          <Button layout="outline" onClick={onClose} disabled={isSubmitting}>
            {t("CancelBtn")}
          </Button>
          <Button onClick={handleSubmit} disabled={!selectedUserId || isSubmitting}>
            {isSubmitting ? t("Adding") || "Ajout..." : t("Add")}
          </Button>
        </div>
      </ModalFooter>
    </Modal>
  );
};

export default AddTeamMemberModal;
