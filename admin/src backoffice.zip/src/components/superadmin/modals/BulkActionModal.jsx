import React, { useState } from "react";
import { useTranslation } from "react-i18next";
import {
  Modal,
  ModalBody,
  ModalFooter,
  Button,
  Textarea,
  Select,
} from "@windmill/react-ui";
import { FiAlertTriangle } from "react-icons/fi";
import spinnerLoadingImage from "@/assets/img/spinner.gif";

const BulkActionModal = ({
  isOpen,
  onClose,
  action,
  selectedCount,
  isSubmitting,
  onSubmit,
  roleOptions = [],
}) => {
  const { t } = useTranslation();
  const [reason, setReason] = useState("");
  const [selectedRole, setSelectedRole] = useState("");

  const getConfig = () => {
    switch (action) {
      case "suspend":
        return {
          title: t("SuspendUsers"),
          message: (
            <div className="space-y-3">
              <p>
                {t("BulkSuspendMessage", { count: selectedCount })}
              </p>
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  {t("SuspensionReason")}
                </label>
                <Textarea
                  value={reason}
                  onChange={(e) => setReason(e.target.value)}
                  placeholder={t("EnterSuspensionReason")}
                  rows={3}
                />
              </div>
            </div>
          ),
          label: t("Suspend"),
        };
      case "block":
        return {
          title: t("BlockUsers"),
          message: (
            <div className="space-y-3">
              <p>
                {t("BulkBlockMessage", { count: selectedCount })}
              </p>
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  {t("BlockReason")}
                </label>
                <Textarea
                  value={reason}
                  onChange={(e) => setReason(e.target.value)}
                  placeholder={t("EnterBlockReason")}
                  rows={3}
                />
              </div>
            </div>
          ),
          label: t("Block"),
          confirmClass: "bg-red-600 hover:bg-red-700",
        };
      case "unblock":
        return {
          title: t("UnblockUsers"),
          message: t("BulkUnblockMessage", { count: selectedCount }),
          label: t("Unblock"),
        };
      case "archive":
        return {
          title: t("ArchiveUsers"),
          message: (
            <div className="space-y-3">
              <p>
                {t("BulkArchiveMessage", { count: selectedCount })}
              </p>
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  {t("ArchiveReason")}
                </label>
                <Textarea
                  value={reason}
                  onChange={(e) => setReason(e.target.value)}
                  placeholder={t("EnterArchiveReason")}
                  rows={3}
                />
              </div>
            </div>
          ),
          label: t("Archive"),
          confirmClass: "bg-purple-600 hover:bg-purple-700",
        };
      case "unarchive":
        return {
          title: t("UnarchiveUsers"),
          message: t("BulkUnarchiveMessage", { count: selectedCount }),
          label: t("Unarchive"),
        };
      case "delete":
        return {
          title: t("DeleteUsers"),
          message: (
            <div className="space-y-3">
              <div className="flex items-start gap-3 p-3 bg-red-50 dark:bg-red-900/20 rounded-md">
                <FiAlertTriangle className="text-red-500 mt-0.5 flex-shrink-0" size={20} />
                <p className="text-sm text-red-800 dark:text-red-200">
                  {t("BulkDeleteWarning", { count: selectedCount })}
                </p>
              </div>
              <p className="text-sm text-gray-500 dark:text-gray-400">
                {t("BulkDeleteMessage", { count: selectedCount })}
              </p>
            </div>
          ),
          label: t("DeletePermanently"),
        };
      case "reactivate":
        return {
          title: t("ReactivateUsers"),
          message: t("BulkReactivateMessage", { count: selectedCount }),
          label: t("Reactivate"),
        };
      case "assign_role":
        return {
          title: t("AssignRoleToUsers"),
          message: (
            <div className="space-y-3">
              <p>{t("BulkAssignRoleMessage", { count: selectedCount })}</p>
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  {t("SelectRole")}
                </label>
                <Select
                  value={selectedRole}
                  onChange={(e) => setSelectedRole(e.target.value)}
                  className="w-full"
                >
                  <option value="">{t("SelectRole")}</option>
                  {roleOptions.map((role) => (
                    <option key={role._id} value={role._id}>
                      {role.name}
                    </option>
                  ))}
                </Select>
              </div>
            </div>
          ),
          label: t("Assign"),
        };
      case "force_password_change":
        return {
          title: t("ForcePasswordChangeForAll"),
          message: t("BulkForcePasswordChangeMessage", { count: selectedCount }),
          label: t("ForcePasswordChange"),
          confirmClass: "bg-amber-600 hover:bg-amber-700",
        };
      case "resend_invitation":
        return {
          title: t("ResendInvitationForAll"),
          message: t("BulkResendInvitationMessage", { count: selectedCount }),
          label: t("Resend"),
          confirmClass: "bg-emerald-600 hover:bg-emerald-700",
        };
      default:
        return {
          title: t("BulkAction"),
          message: t("BulkActionMessage", { count: selectedCount }),
          label: t("Confirm"),
        };
    }
  };

  const config = getConfig();

  const handleSubmit = () => {
    const extraData = {};
    if (action === "suspend") extraData.reason = reason;
    if (action === "block") extraData.reason = reason;
    if (action === "archive") extraData.reason = reason;

    onSubmit && onSubmit(action, { reason, ...extraData });
  };

  const confirmClass = config.confirmClass || (action === "delete"
    ? "bg-red-600 hover:bg-red-700"
    : "bg-emerald-700 hover:bg-emerald-800");

  return (
    <Modal isOpen={isOpen} onClose={isSubmitting ? undefined : onClose} size="lg" className="custom-modal">
      <ModalBody className="px-6 pt-6 pb-4">
        <div className="flex items-center gap-3 mb-4">
          <span className="flex justify-center text-2xl text-yellow-500">
            <FiAlertTriangle />
          </span>
          <h2 className="text-xl font-bold text-gray-900 dark:text-gray-100">
            {config.title}
          </h2>
        </div>
        <div className="text-sm text-gray-600 dark:text-gray-300">
          {config.message}
        </div>
      </ModalBody>

      <ModalFooter className="justify-end gap-2">
        <Button
          layout="outline"
          onClick={isSubmitting ? undefined : onClose}
          disabled={isSubmitting}
          className="text-sm"
        >
          {t("CancelBtn")}
        </Button>
        {isSubmitting ? (
          <Button disabled className="text-sm">
            <img src={spinnerLoadingImage} alt="Loading" width={20} height={10} />
            <span className="font-serif ml-2 font-light">{t("Processing")}</span>
          </Button>
        ) : (
          <Button
            onClick={handleSubmit}
            className={`text-sm ${confirmClass}`}
          >
            {config.label}
          </Button>
        )}
      </ModalFooter>
    </Modal>
  );
};

export default BulkActionModal;
