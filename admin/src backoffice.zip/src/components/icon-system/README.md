# Système d'Icônes Global

Architecture complète d'un système d'icônes réutilisable pour le page builder.

## Structure

```
admin/src/components/icon-system/
├── context/
│   └── IconContext.jsx          # Provider React Context (favorites, recent, custom, libraries)
├── hooks/
│   └── index.js                 # Hooks: useIcons, useIconSearch, useIconFavorites, useCustomIcons
├── libraries/
│   ├── index.js                 # Import all built-in libraries
│   ├── faBrands.js              # Font Awesome 6 Brands
│   ├── materialFilled.js        # Material Icons (Filled)
│   ├── lucide.js                # Lucide Icons
│   ├── remix.js                 # Remix Icon (Outline + Filled)
│   └── customLibrary.js         # Dynamic loader for custom uploaded icons
├── utils/
│   ├── iconRegistry.js          # Registry central, register/unregister libraries
│   ├── svgParser.js             # Parse, sanitize SVG strings
│   └── virtualizeGrid.js        # Virtualization pour grille d'icônes
├── services/
│   └── iconService.js           # API calls (axios)
├── components/
│   ├── IconPreview.jsx          # Render n'importe quelle icône (SVG inline)
│   ├── IconGrid.jsx             # Grille virtualisée avec recherche et sélection
│   ├── IconDisplay.jsx          # Icône avec animations (spin, pulse, bounce, shake)
│   ├── IconPickerModal.jsx      # Modal principal: tabs, search, filters, upload
│   ├── IconPickerTrigger.jsx    # Bouton trigger pour ouvrir le picker
│   └── index.js                 # Exports
└── widgets/
    └── IconBoxWidget.js         # Exemple GrapesJS widget utilisant IconPickerTrait

theme-editor/
├── traits/
│   └── icon/
│       ├── IconPickerTrait.js       # Trait definition pour GrapesJS
│       └── IconPickerTraitField.jsx # React field pour le trait panel
└── plugins/
    └── registerTraits.js            # Enregistrement du type "icon-picker"
```

## Intégration dans un widget

```jsx
import { IconPickerTrigger } from "../../components/icon-system/components/IconPickerTrigger";

function MyWidget({ value, onChange }) {
  return (
    <IconPickerTrigger
      value={value}
      onChange={onChange}
      storeId="store-123"
      label="Icône"
      size={24}
    />
  );
}
```

## Intégration dans GrapesJS

```js
import { IconPickerTrait } from "../theme-editor/traits";

// Dans la définition du block:
{
  traits: [
    IconPickerTrait("icon", "Icône"),
    // ... autres traits
  ]
}
```

## Ajouter une nouvelle bibliothèque

```js
import { registerLibrary } from "./utils/iconRegistry";

registerLibrary({
  id: "ma-lib",
  name: "Ma Bibliothèque",
  category: "custom",
  tags: ["outline"],
  iconCount: 100,
  getIcons: async () => [
    { id: "icon-1", name: "mon-icone", tags: ["foo"], svg: '<path d="..."/>' },
  ],
});
```

## Upload custom (ZIP / SVG)

Drag & drop dans le modal, ou appel API:
```js
const res = await iconService.uploadZip(file);
const created = await iconService.batchCreate({ storeId, icons: res.icons });
```

## Backend

```
POST   /api/custom-icons              # Créer icône
POST   /api/custom-icons/batch        # Créer plusieurs
GET    /api/custom-icons              # Lister (avec search, tags, favorites, pagination)
GET    /api/custom-icons/:name         # Récupérer une icône
PATCH  /api/custom-icons/:name/favorite # Toggle favorite
DELETE /api/custom-icons/:name         # Supprimer
DELETE /api/custom-icons/batch        # Supprimer plusieurs
POST   /api/icon-upload/              # Upload ZIP + parsing serveur
```

## Performance

- Grille virtualisée (react-window style) — seul les éléments visibles sont rendus
- Recherche debounced 150ms
- Custom icons chargés depuis localStorage + fallback serveur
- Registre centralisé, pas de re-render inutile

## Accessibilité

- ARIA labels sur tous les éléments interactifs
- Navigation clavier (Enter/Space pour sélectionner)
- role="listbox" / role="option" sur la grille
- aria-modal sur le dialog
- aria-label sur les boutons d'action
