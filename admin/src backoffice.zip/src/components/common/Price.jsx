import { useCurrency } from "@/hooks/useCurrency";

const Price = ({ product, price }) => {
  const { formatMoney } = useCurrency();

  return (
    <div className="font-serif product-price font-bold dark:text-gray-400">
      {formatMoney(price || product?.prices?.originalPriceWithTax)}
    </div>
  );
};

export default Price;
