import { Button, Modal, ModalBody, ModalFooter } from "@windmill/react-ui";
import React, { useContext } from "react";
import { FiTrash2 } from "react-icons/fi";
import { useState } from "react";
import { useTranslation } from "react-i18next";
import { useLocation } from "react-router-dom";

//internal import
import spinnerLoadingImage from "@/assets/img/spinner.gif";
import { SidebarContext } from "@/context/SidebarContext";
import UserServices from "@/services/UserServices";
import ProductCategoryServices from "@/services/ProductCategoryServices";
import CouponServices from "@/services/CouponServices";
import CustomerServices from "@/services/CustomerServices";
import ProductServices from "@/services/ProductServices";
import StoreServices from "@/services/StoreServices";
import CurrencyServices from "@/services/CurrencyServices";
import RiderServices from "@/services/RiderServices";
import PlanServices from "@/services/PlanServices";
import useToggleDrawer from "@/hooks/useToggleDrawer";
import AttributeServices from "@/services/AttributeServices";
import { notifyError, notifySuccess } from "@/utils/toast";
import useDisableForDemo from "@/hooks/useDisableForDemo";

const DeleteModal = ({ id, ids, setIsCheck, category, title, useParamId }) => {
  const { isModalOpen, closeModal, setIsUpdate } = useContext(SidebarContext);
  const { setServiceId } = useToggleDrawer();
  const location = useLocation();
  const { t } = useTranslation();

  const [isSubmitting, setIsSubmitting] = useState(false);

  const { handleDisableForDemo } = useDisableForDemo();

  // An empty array is truthy, so `ids` must be length-checked before it can be
  // treated as a bulk selection.
  const hasBulkIds = Array.isArray(ids) && ids.length > 0;

  const handleDelete = async () => {
    if (handleDisableForDemo()) {
      return;
    }

    if (!hasBulkIds && !id) {
      notifyError(t("DeleteModalNothingSelected"));
      return closeModal();
    }

    try {
      setIsSubmitting(true);

      if (location.pathname === "/stores") {
        const isRestore = title?.toLowerCase().includes("restore");
        if (isRestore) {
          const res = await StoreServices.restoreStore(id);
          setIsUpdate(true);
          notifySuccess("Store restored successfully!");
        } else {
          const res = await StoreServices.deleteStore(id);
          setIsUpdate(true);
          notifySuccess("Store deleted successfully!");
        }
        setServiceId();
        closeModal();
        setIsSubmitting(false);
      }

      if (location.pathname === "/products") {
        if (hasBulkIds) {
          const res = await ProductServices.deleteManyProducts({ ids: ids });
          setIsUpdate(true);
          notifySuccess(res.message);
          setIsCheck([]);
          setServiceId();
          closeModal();
          setIsSubmitting(false);
        } else {
          const res = await ProductServices.deleteProduct(id);
          setIsUpdate(true);
          notifySuccess(res.message);
          setServiceId();
          closeModal();
          setIsSubmitting(false);
        }
      }

      if (location.pathname === "/coupons") {
        if (ids) {
          const res = await CouponServices.deleteManyCoupons({ ids: ids });
          setIsUpdate(true);
          notifySuccess(res.message);
          setIsCheck([]);
          setServiceId();
          closeModal();
          setIsSubmitting(false);
        } else {
          const res = await CouponServices.deleteCoupon(id);
          setIsUpdate(true);
          notifySuccess(res.message);
          setServiceId();
          closeModal();
          setIsSubmitting(false);
        }
      }

      if (location.pathname === "/platform-coupons") {
        if (ids) {
          const res = await PlatformCouponServices.deleteManyCoupons({
            ids: ids,
          });
          setIsUpdate(true);
          notifySuccess(res.message);
          setIsCheck([]);
          setServiceId();
          closeModal();
          setIsSubmitting(false);
        } else {
          const res = await PlatformCouponServices.deleteCoupon(id);
          setIsUpdate(true);
          notifySuccess(res.message);
          setServiceId();
          closeModal();
          setIsSubmitting(false);
        }
      }

      if (location.pathname === "/categories" || category) {
        // hasBulkIds, not `ids`: an empty selection array is truthy and would
        // otherwise send an empty bulk delete instead of the single one
        if (hasBulkIds) {
          const res = await ProductCategoryServices.deleteManyCategories({
            ids: ids,
          });
          setIsUpdate(true);
          notifySuccess(res.message);
          setIsCheck([]);
          setServiceId();
          closeModal();
          setIsSubmitting(false);
        } else {
          if (id === undefined || !id) {
            notifyError("Please select a category first!");
            setIsSubmitting(false);
            return closeModal();
          }
          const res = await ProductCategoryServices.deleteCategory(id);
          setIsUpdate(true);
          notifySuccess(res.message);
          closeModal();
          setServiceId();
          setIsSubmitting(false);
        }
      }

      if (location.pathname === "/customers") {
        const res = await CustomerServices.deleteCustomer(id);
        setIsUpdate(true);
        notifySuccess(res.message);
        setServiceId();
        closeModal();
        setIsSubmitting(false);
      }

      if (location.pathname === "/plans") {
        await PlanServices.deletePlan(id);
        setIsUpdate(true);
        notifySuccess("Plan deleted successfully");
        setServiceId();
        setIsCheck([]);
        closeModal();
        setIsSubmitting(false);
      }

      if (location.pathname === "/attributes") {
        if (ids) {
          const res = await AttributeServices.deleteManyAttribute({ ids: ids });
          setIsUpdate(true);
          notifySuccess(res.message);
          setIsCheck([]);
          setServiceId();
          closeModal();
          setIsSubmitting(false);
        } else {
          const res = await AttributeServices.deleteAttribute(id);
          setIsUpdate(true);
          notifySuccess(res.message);
          setServiceId();
          closeModal();
          setIsSubmitting(false);
        }
      }

      if (location.pathname === `/attributes/${location.pathname.split("/")[2]}`) {
        if (ids) {
          const res = await AttributeServices.deleteManyChildAttribute({
            id: location.pathname.split("/")[2],
            ids: ids,
          });
          setIsUpdate(true);
          notifySuccess(res.message);
          setServiceId();
          setIsCheck([]);
          closeModal();
          setIsSubmitting(false);
        } else {
          const res = await AttributeServices.deleteChildAttribute({
            id: id,
            ids: location.pathname.split("/")[2],
          });
          setIsUpdate(true);
          notifySuccess(res.message);
          setServiceId();
          closeModal();
          setIsSubmitting(false);
        }
      }

      if (location.pathname === "/our-staff") {
        await UserServices.deleteStaff(id);
        setIsUpdate(true);
        notifySuccess(t("StaffDeleteSuccess"));
        setServiceId();
        closeModal();
        setIsSubmitting(false);
      }

      if (location.pathname === "/riders") {
        await RiderServices.deleteRider(id);
        setIsUpdate(true);
        notifySuccess(t("RiderDeleteSuccess"));
        setServiceId();
        closeModal();
        setIsSubmitting(false);
      }

      if (location.pathname === "/currencies") {
        if (ids) {
          const res = await CurrencyServices.deleteManyCurrency({ ids: ids });
          setIsUpdate(true);
          notifySuccess(res.message);
          setIsCheck([]);
          closeModal();
          setIsSubmitting(false);
        } else {
          const res = await CurrencyServices.deleteCurrency(id);
          setIsUpdate(true);
          notifySuccess(res.message);
          setServiceId();
          closeModal();
          setIsSubmitting(false);
        }
      }

    } catch (err) {
      notifyError(err ? err?.response?.data?.message : err?.message);
      setServiceId();
      if (setIsCheck) {
        setIsCheck([]);
      }
      closeModal();
      setIsSubmitting(false);
    }
  };

  return (
    <>
      <Modal isOpen={isModalOpen} onClose={closeModal}>
        <ModalBody className="text-center custom-modal px-8 pt-6 pb-4">
          <span className="flex justify-center text-3xl mb-6 text-red-500">
            <FiTrash2 />
          </span>
          <h2 className="text-xl font-medium mb-2">
            {t("DeleteModalH2")} <span className="text-red-500">{title}</span>?
          </h2>
          <p>{t("DeleteModalPtag")}</p>
        </ModalBody>

        <ModalFooter className="justify-center">
          <Button
            className="w-full sm:w-auto hover:bg-white hover:border-gray-50"
            layout="outline"
            onClick={closeModal}
          >
            {t("modalKeepBtn")}
          </Button>
          <div className="flex justify-end">
            {isSubmitting ? (
              <Button disabled={true} type="button" className="w-full h-12 sm:w-auto">
                <img src={spinnerLoadingImage} alt="Loading" width={20} height={10} />
                <span className="font-serif ml-2 font-light">{t("Processing")}</span>
              </Button>
            ) : (
              <Button onClick={handleDelete} className="w-full h-12 sm:w-auto">
                {t("modalDeletBtn")}
              </Button>
            )}
          </div>
        </ModalFooter>
      </Modal>
    </>
  );
};

export default React.memo(DeleteModal);