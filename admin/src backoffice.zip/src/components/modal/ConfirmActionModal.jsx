import React from "react";
import { Modal, ModalBody, ModalFooter, Button } from "@windmill/react-ui";
import { FiAlertTriangle } from "react-icons/fi";
import { useTranslation } from "react-i18next";

//internal import
import spinnerLoadingImage from "@/assets/img/spinner.gif";

const ConfirmActionModal = ({
  isOpen,
  onClose,
  onConfirm,
  isSubmitting,
  title,
  message,
  confirmLabel,
}) => {
  const { t } = useTranslation();

  return (
    <Modal isOpen={isOpen} onClose={onClose}>
      <ModalBody className="text-center custom-modal px-8 pt-6 pb-4">
        <span className="flex justify-center text-3xl mb-6 text-yellow-500">
          <FiAlertTriangle />
        </span>
        <h2 className="text-xl font-medium mb-2">{title}</h2>
        <p className="text-sm text-gray-500 dark:text-gray-400">{message}</p>
      </ModalBody>

      <ModalFooter className="justify-center">
        <Button
          className="w-full sm:w-auto hover:bg-white hover:border-gray-50"
          layout="outline"
          onClick={onClose}
        >
          {t("CancelBtn")}
        </Button>
        <div className="flex justify-end">
          {isSubmitting ? (
            <Button disabled={true} type="button" className="w-full h-12 sm:w-auto">
              <img
                src={spinnerLoadingImage}
                alt="Loading"
                width={20}
                height={10}
              />
              <span className="font-serif ml-2 font-light">{t("Processing")}</span>
            </Button>
          ) : (
            <Button onClick={onConfirm} className="w-full h-12 sm:w-auto">
              {confirmLabel}
            </Button>
          )}
        </div>
      </ModalFooter>
    </Modal>
  );
};

export default ConfirmActionModal;
