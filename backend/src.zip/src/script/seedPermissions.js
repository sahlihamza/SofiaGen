const Permission = require("../models/Permission");
const AuditService = require("../service/AuditService");
const { permissions, getRiskLevel } = require("../config/rbac/permissions");

const seedPermissions = async () => {
  for (const perm of permissions) {
    // Upsert on `code` (the unique index key). Keying on module/action
    // re-inserted duplicates when legacy docs used a different casing.
    await Permission.findOneAndUpdate(
      { code: perm.code },
      {
        code: perm.code,
        name: perm.name,
        module: perm.module,
        action: perm.action,
        scope: perm.scope,
        category: perm.category,
        riskLevel: getRiskLevel(perm.action),
        description: perm.description,
      },
      { upsert: true, new: true, setDefaultsOnInsert: true, runValidators: true }
    );
  }

  await AuditService.logAction({
    actorType: "system",
    module: "PermissionService",
    action: "policy_updated",
    summary: `Permission seed completed: ${permissions.length} permissions synced`,
    entityType: "Permission",
    status: "success",
    severity: "low",
    newValue: { count: permissions.length },
  });

  return Permission.find();
};

module.exports = seedPermissions;

if (require.main === module) {
  require("dotenv").config();
  const mongoose = require("mongoose");
  const logger = require("../config/logger");

  (async () => {
    try {
      await mongoose.connect(process.env.MONGO_URI);
      const result = await seedPermissions();
      logger.info(`✅ ${result.length} permissions créées/mises à jour`);
      process.exit(0);
    } catch (error) {
      logger.error("❌ Erreur seed permissions:", error.message);
      process.exit(1);
    }
  })();
}
