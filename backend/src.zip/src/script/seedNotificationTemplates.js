const NotificationTemplate = require("../models/NotificationTemplate");
const { EVENT_CONFIG } = require("../service/NotificationEventHandler");
const AuditService = require("../service/AuditService");

const TEMPLATE_CONTENT = {
  "store.created": {
    name: "New store",
    title: { fr: "Nouveau store", en: "New store", ar: "متجر جديد" },
    message: {
      fr: "Le store {{storeName}} a été créé.",
      en: "Store {{storeName}} has been created.",
      ar: "تم إنشاء المتجر {{storeName}}.",
    },
    variables: ["storeName"],
    channels: { in_app: true, email: true, push: false },
  },
  "store.updated": {
    name: "Store updated",
    title: { fr: "Store mis à jour", en: "Store updated", ar: "تم تحديث المتجر" },
    message: {
      fr: "Le store {{storeName}} a été mis à jour.",
      en: "Store {{storeName}} has been updated.",
      ar: "تم تحديث المتجر {{storeName}}.",
    },
    variables: ["storeName"],
    channels: { in_app: true, email: false, push: false },
  },
  "store.suspended": {
    name: "Store suspended",
    title: { fr: "Store suspendu", en: "Store suspended", ar: "تم تعليق المتجر" },
    message: {
      fr: "Le store {{storeName}} a été suspendu.",
      en: "Store {{storeName}} has been suspended.",
      ar: "تم تعليق المتجر {{storeName}}.",
    },
    variables: ["storeName"],
    channels: { in_app: true, email: true, push: false },
  },
  "store.activated": {
    name: "Store activated",
    title: { fr: "Store activé", en: "Store activated", ar: "تم تفعيل المتجر" },
    message: {
      fr: "Le store {{storeName}} a été réactivé.",
      en: "Store {{storeName}} has been activated.",
      ar: "تم تفعيل المتجر {{storeName}}.",
    },
    variables: ["storeName"],
    channels: { in_app: true, email: false, push: false },
  },
  "store.deleted": {
    name: "Store deleted",
    title: { fr: "Store supprimé", en: "Store deleted", ar: "تم حذف المتجر" },
    message: {
      fr: "Le store {{storeName}} a été supprimé.",
      en: "Store {{storeName}} has been deleted.",
      ar: "تم حذف المتجر {{storeName}}.",
    },
    variables: ["storeName"],
    channels: { in_app: true, email: true, push: false },
  },

  "user.created": {
    name: "New user",
    title: { fr: "Nouvel utilisateur", en: "New user", ar: "مستخدم جديد" },
    message: {
      fr: "{{userName}} a rejoint l'équipe.",
      en: "{{userName}} joined the team.",
      ar: "انضم {{userName}} إلى الفريق.",
    },
    variables: ["userName"],
    channels: { in_app: true, email: false, push: false },
  },
  "user.invited": {
    name: "User invited",
    title: { fr: "Invitation envoyée", en: "User invited", ar: "تمت دعوة مستخدم" },
    message: {
      fr: "{{userName}} a été invité(e).",
      en: "{{userName}} was invited.",
      ar: "تمت دعوة {{userName}}.",
    },
    variables: ["userName"],
    channels: { in_app: true, email: false, push: false },
  },
  "user.updated": {
    name: "User updated",
    title: { fr: "Utilisateur mis à jour", en: "User updated", ar: "تم تحديث المستخدم" },
    message: {
      fr: "Le profil de {{userName}} a été mis à jour.",
      en: "{{userName}}'s profile was updated.",
      ar: "تم تحديث ملف {{userName}}.",
    },
    variables: ["userName"],
    channels: { in_app: true, email: false, push: false },
  },
  "user.password_changed": {
    name: "Password changed",
    title: { fr: "Mot de passe modifié", en: "Password changed", ar: "تم تغيير كلمة المرور" },
    message: {
      fr: "Votre mot de passe a été modifié.",
      en: "Your password was changed.",
      ar: "تم تغيير كلمة المرور الخاصة بك.",
    },
    variables: [],
    channels: { in_app: true, email: true, push: false },
  },

  "order.created": {
    name: "New order",
    title: { fr: "Nouvelle commande", en: "New order", ar: "طلب جديد" },
    message: {
      fr: "La commande {{orderNumber}} a été créée ({{total}}).",
      en: "Order {{orderNumber}} has been created ({{total}}).",
      ar: "تم إنشاء الطلب {{orderNumber}} ({{total}}).",
    },
    variables: ["orderNumber", "customerName", "total"],
    channels: { in_app: true, email: true, push: false },
  },
  "order.updated": {
    name: "Order updated",
    title: { fr: "Commande mise à jour", en: "Order updated", ar: "تم تحديث الطلب" },
    message: {
      fr: "La commande {{orderNumber}} a été mise à jour.",
      en: "Order {{orderNumber}} has been updated.",
      ar: "تم تحديث الطلب {{orderNumber}}.",
    },
    variables: ["orderNumber"],
    channels: { in_app: true, email: false, push: false },
  },
  "order.cancelled": {
    name: "Order cancelled",
    title: { fr: "Commande annulée", en: "Order cancelled", ar: "تم إلغاء الطلب" },
    message: {
      fr: "La commande {{orderNumber}} a été annulée.",
      en: "Order {{orderNumber}} has been cancelled.",
      ar: "تم إلغاء الطلب {{orderNumber}}.",
    },
    variables: ["orderNumber"],
    channels: { in_app: true, email: true, push: false },
  },
  "order.completed": {
    name: "Order completed",
    title: { fr: "Commande terminée", en: "Order completed", ar: "اكتمل الطلب" },
    message: {
      fr: "La commande {{orderNumber}} a été livrée/terminée.",
      en: "Order {{orderNumber}} has been completed.",
      ar: "اكتمل الطلب {{orderNumber}}.",
    },
    variables: ["orderNumber"],
    channels: { in_app: true, email: false, push: false },
  },

  "payment.created": {
    name: "Payment created",
    title: { fr: "Paiement initié", en: "Payment created", ar: "تم إنشاء دفعة" },
    message: {
      fr: "Un paiement de {{paymentAmount}} a été initié.",
      en: "A payment of {{paymentAmount}} was created.",
      ar: "تم إنشاء دفعة بقيمة {{paymentAmount}}.",
    },
    variables: ["paymentAmount"],
    channels: { in_app: true, email: false, push: false },
  },
  "payment.paid": {
    name: "Payment received",
    title: { fr: "Paiement reçu", en: "Payment received", ar: "تم استلام الدفعة" },
    message: {
      fr: "Un paiement de {{paymentAmount}} a été reçu.",
      en: "A payment of {{paymentAmount}} was received.",
      ar: "تم استلام دفعة بقيمة {{paymentAmount}}.",
    },
    variables: ["paymentAmount"],
    channels: { in_app: true, email: true, push: false },
  },
  "payment.failed": {
    name: "Payment failed",
    title: { fr: "Échec du paiement", en: "Payment failed", ar: "فشلت عملية الدفع" },
    message: {
      fr: "Le paiement de {{paymentAmount}} a échoué.",
      en: "The payment of {{paymentAmount}} failed.",
      ar: "فشلت عملية الدفع بقيمة {{paymentAmount}}.",
    },
    variables: ["paymentAmount"],
    channels: { in_app: true, email: true, push: false },
  },
  "payment.refunded": {
    name: "Payment refunded",
    title: { fr: "Paiement remboursé", en: "Payment refunded", ar: "تم استرداد الدفعة" },
    message: {
      fr: "Un remboursement de {{paymentAmount}} a été effectué.",
      en: "A refund of {{paymentAmount}} was issued.",
      ar: "تم استرداد مبلغ {{paymentAmount}}.",
    },
    variables: ["paymentAmount"],
    channels: { in_app: true, email: true, push: false },
  },

  "subscription.created": {
    name: "Subscription created",
    title: { fr: "Abonnement créé", en: "Subscription created", ar: "تم إنشاء الاشتراك" },
    message: {
      fr: "Votre abonnement au plan {{planName}} a été créé.",
      en: "Your {{planName}} subscription has been created.",
      ar: "تم إنشاء اشتراكك في خطة {{planName}}.",
    },
    variables: ["planName"],
    channels: { in_app: true, email: true, push: false },
  },
  "subscription.renewed": {
    name: "Subscription renewed",
    title: { fr: "Abonnement renouvelé", en: "Subscription renewed", ar: "تم تجديد الاشتراك" },
    message: {
      fr: "Votre abonnement {{planName}} a été renouvelé.",
      en: "Your {{planName}} subscription was renewed.",
      ar: "تم تجديد اشتراكك {{planName}}.",
    },
    variables: ["planName"],
    channels: { in_app: true, email: false, push: false },
  },
  "subscription.expiring": {
    name: "Subscription expiring soon",
    title: { fr: "Abonnement bientôt expiré", en: "Subscription expiring soon", ar: "الاشتراك على وشك الانتهاء" },
    message: {
      fr: "Votre abonnement {{planName}} expire le {{expiresAt}}.",
      en: "Your {{planName}} subscription expires on {{expiresAt}}.",
      ar: "ينتهي اشتراكك {{planName}} في {{expiresAt}}.",
    },
    variables: ["planName", "expiresAt"],
    channels: { in_app: true, email: true, push: false },
  },
  "subscription.expired": {
    name: "Subscription expired",
    title: { fr: "Abonnement expiré", en: "Subscription expired", ar: "انتهى الاشتراك" },
    message: {
      fr: "Votre abonnement {{planName}} a expiré.",
      en: "Your {{planName}} subscription has expired.",
      ar: "انتهى اشتراكك {{planName}}.",
    },
    variables: ["planName"],
    channels: { in_app: true, email: true, push: false },
  },
  "subscription.cancelled": {
    name: "Subscription cancelled",
    title: { fr: "Abonnement annulé", en: "Subscription cancelled", ar: "تم إلغاء الاشتراك" },
    message: {
      fr: "Votre abonnement {{planName}} a été annulé.",
      en: "Your {{planName}} subscription was cancelled.",
      ar: "تم إلغاء اشتراكك {{planName}}.",
    },
    variables: ["planName"],
    channels: { in_app: true, email: true, push: false },
  },

  "invoice.created": {
    name: "New invoice",
    title: { fr: "Nouvelle facture", en: "New invoice", ar: "فاتورة جديدة" },
    message: {
      fr: "La facture {{invoiceNumber}} a été créée.",
      en: "Invoice {{invoiceNumber}} has been created.",
      ar: "تم إنشاء الفاتورة {{invoiceNumber}}.",
    },
    variables: ["invoiceNumber"],
    channels: { in_app: true, email: true, push: false },
  },
  "invoice.paid": {
    name: "Invoice paid",
    title: { fr: "Facture payée", en: "Invoice paid", ar: "تم دفع الفاتورة" },
    message: {
      fr: "La facture {{invoiceNumber}} a été payée.",
      en: "Invoice {{invoiceNumber}} has been paid.",
      ar: "تم دفع الفاتورة {{invoiceNumber}}.",
    },
    variables: ["invoiceNumber"],
    channels: { in_app: true, email: false, push: false },
  },
  "invoice.overdue": {
    name: "Invoice overdue",
    title: { fr: "Facture en retard", en: "Invoice overdue", ar: "فاتورة متأخرة" },
    message: {
      fr: "La facture {{invoiceNumber}} est en retard de paiement.",
      en: "Invoice {{invoiceNumber}} is overdue.",
      ar: "الفاتورة {{invoiceNumber}} متأخرة عن الدفع.",
    },
    variables: ["invoiceNumber"],
    channels: { in_app: true, email: true, push: false },
  },

  "product.created": {
    name: "Product created",
    title: { fr: "Produit créé", en: "Product created", ar: "تم إنشاء منتج" },
    message: {
      fr: "Le produit {{productName}} a été créé.",
      en: "Product {{productName}} has been created.",
      ar: "تم إنشاء المنتج {{productName}}.",
    },
    variables: ["productName"],
    channels: { in_app: true, email: false, push: false },
  },
  "product.updated": {
    name: "Product updated",
    title: { fr: "Produit mis à jour", en: "Product updated", ar: "تم تحديث المنتج" },
    message: {
      fr: "Le produit {{productName}} a été mis à jour.",
      en: "Product {{productName}} has been updated.",
      ar: "تم تحديث المنتج {{productName}}.",
    },
    variables: ["productName"],
    channels: { in_app: true, email: false, push: false },
  },
  "product.low_stock": {
    name: "Low stock",
    title: { fr: "Stock faible", en: "Low stock", ar: "المخزون منخفض" },
    message: {
      fr: "Le produit {{productName}} a un stock faible ({{quantity}} restant).",
      en: "Product {{productName}} is low on stock ({{quantity}} left).",
      ar: "المنتج {{productName}} مخزونه منخفض ({{quantity}} متبقٍ).",
    },
    variables: ["productName", "quantity"],
    channels: { in_app: true, email: false, push: false },
  },
  "product.out_of_stock": {
    name: "Out of stock",
    title: { fr: "Rupture de stock", en: "Out of stock", ar: "نفاد المخزون" },
    message: {
      fr: "Le produit {{productName}} est en rupture de stock.",
      en: "Product {{productName}} is out of stock.",
      ar: "المنتج {{productName}} نفد من المخزون.",
    },
    variables: ["productName"],
    channels: { in_app: true, email: true, push: false },
  },

  "customer.created": {
    name: "New customer",
    title: { fr: "Nouveau client", en: "New customer", ar: "عميل جديد" },
    message: {
      fr: "{{customerName}} vient de créer un compte.",
      en: "{{customerName}} just created an account.",
      ar: "قام {{customerName}} بإنشاء حساب.",
    },
    variables: ["customerName"],
    channels: { in_app: true, email: false, push: false },
  },
  "customer.updated": {
    name: "Customer updated",
    title: { fr: "Client mis à jour", en: "Customer updated", ar: "تم تحديث العميل" },
    message: {
      fr: "Le profil de {{customerName}} a été mis à jour.",
      en: "{{customerName}}'s profile was updated.",
      ar: "تم تحديث ملف {{customerName}}.",
    },
    variables: ["customerName"],
    channels: { in_app: true, email: false, push: false },
  },

  "customer.order_confirmed": {
    name: "Order confirmed (customer)",
    title: { fr: "Commande confirmée", en: "Order confirmed", ar: "تم تأكيد الطلب" },
    message: {
      fr: "Merci ! Votre commande {{orderNumber}} a bien été reçue ({{total}}).",
      en: "Thank you! Your order {{orderNumber}} has been received ({{total}}).",
      ar: "شكرًا لك! تم استلام طلبك {{orderNumber}} ({{total}}).",
    },
    variables: ["orderNumber", "total"],
    channels: { in_app: true, email: true, push: false },
  },
  "customer.order_status_updated": {
    name: "Order status updated (customer)",
    title: { fr: "Mise à jour de votre commande", en: "Your order was updated", ar: "تحديث حالة طلبك" },
    message: {
      fr: "Votre commande {{orderNumber}} est maintenant : {{status}}.",
      en: "Your order {{orderNumber}} is now: {{status}}.",
      ar: "طلبك {{orderNumber}} أصبح الآن: {{status}}.",
    },
    variables: ["orderNumber", "status"],
    channels: { in_app: true, email: true, push: false },
  },
  "customer.review_approved": {
    name: "Your review was approved (customer)",
    title: { fr: "Votre avis a été approuvé", en: "Your review was approved", ar: "تمت الموافقة على تقييمك" },
    message: {
      fr: "Votre avis sur {{productName}} a été approuvé et est maintenant visible.",
      en: "Your review on {{productName}} was approved and is now visible.",
      ar: "تمت الموافقة على تقييمك حول {{productName}} وأصبح مرئيًا الآن.",
    },
    variables: ["productName"],
    channels: { in_app: true, email: false, push: false },
  },

  "review.created": {
    name: "New review",
    title: { fr: "Nouvel avis", en: "New review", ar: "تقييم جديد" },
    message: {
      fr: "Un nouvel avis a été laissé sur {{productName}}.",
      en: "A new review was left on {{productName}}.",
      ar: "تم ترك تقييم جديد على {{productName}}.",
    },
    variables: ["productName"],
    channels: { in_app: true, email: false, push: false },
  },
  "review.approved": {
    name: "Review approved",
    title: { fr: "Avis approuvé", en: "Review approved", ar: "تمت الموافقة على التقييم" },
    message: {
      fr: "L'avis sur {{productName}} a été approuvé.",
      en: "The review on {{productName}} was approved.",
      ar: "تمت الموافقة على تقييم {{productName}}.",
    },
    variables: ["productName"],
    channels: { in_app: true, email: false, push: false },
  },
  "review.rejected": {
    name: "Review rejected",
    title: { fr: "Avis rejeté", en: "Review rejected", ar: "تم رفض التقييم" },
    message: {
      fr: "L'avis sur {{productName}} a été rejeté.",
      en: "The review on {{productName}} was rejected.",
      ar: "تم رفض تقييم {{productName}}.",
    },
    variables: ["productName"],
    channels: { in_app: true, email: false, push: false },
  },

  "ticket.created": {
    name: "New support ticket",
    title: { fr: "Nouveau ticket", en: "New ticket", ar: "تذكرة جديدة" },
    message: {
      fr: "Le ticket {{ticketNumber}} a été créé.",
      en: "Ticket {{ticketNumber}} has been created.",
      ar: "تم إنشاء التذكرة {{ticketNumber}}.",
    },
    variables: ["ticketNumber"],
    channels: { in_app: true, email: false, push: false },
  },
  "ticket.updated": {
    name: "Ticket updated",
    title: { fr: "Ticket mis à jour", en: "Ticket updated", ar: "تم تحديث التذكرة" },
    message: {
      fr: "Le ticket {{ticketNumber}} a été mis à jour.",
      en: "Ticket {{ticketNumber}} has been updated.",
      ar: "تم تحديث التذكرة {{ticketNumber}}.",
    },
    variables: ["ticketNumber"],
    channels: { in_app: true, email: false, push: false },
  },
  "ticket.assigned": {
    name: "Ticket assigned",
    title: { fr: "Ticket assigné", en: "Ticket assigned", ar: "تم تعيين التذكرة" },
    message: {
      fr: "Le ticket {{ticketNumber}} vous a été assigné.",
      en: "Ticket {{ticketNumber}} was assigned to you.",
      ar: "تم تعيين التذكرة {{ticketNumber}} لك.",
    },
    variables: ["ticketNumber"],
    channels: { in_app: true, email: false, push: false },
  },
  "ticket.agent_replied": {
    name: "Agent replied (customer)",
    title: { fr: "Nouvelle réponse à votre ticket", en: "New reply on your ticket", ar: "رد جديد على تذكرتك" },
    message: {
      fr: "Vous avez reçu une réponse sur le ticket {{ticketNumber}}.",
      en: "You received a reply on ticket {{ticketNumber}}.",
      ar: "لقد تلقيت ردًا على التذكرة {{ticketNumber}}.",
    },
    variables: ["ticketNumber"],
    channels: { in_app: true, email: true, push: false },
  },
  "ticket.customer_replied": {
    name: "Customer replied",
    title: { fr: "Réponse du client", en: "Customer replied", ar: "رد العميل" },
    message: {
      fr: "Le client a répondu sur le ticket {{ticketNumber}}.",
      en: "The customer replied on ticket {{ticketNumber}}.",
      ar: "رد العميل على التذكرة {{ticketNumber}}.",
    },
    variables: ["ticketNumber"],
    channels: { in_app: true, email: false, push: false },
  },
  "ticket.status_changed": {
    name: "Ticket status changed (customer)",
    title: { fr: "Votre ticket a été mis à jour", en: "Your ticket was updated", ar: "تم تحديث تذكرتك" },
    message: {
      fr: "Le statut de votre ticket {{ticketNumber}} est maintenant : {{status}}.",
      en: "Your ticket {{ticketNumber}} is now: {{status}}.",
      ar: "تذكرتك {{ticketNumber}} أصبحت الآن: {{status}}.",
    },
    variables: ["ticketNumber", "status"],
    channels: { in_app: true, email: true, push: false },
  },
  "ticket.sla_warning": {
    name: "SLA warning",
    title: { fr: "SLA bientôt dépassé", en: "SLA warning", ar: "تحذير اتفاقية مستوى الخدمة" },
    message: {
      fr: "Le ticket {{ticketNumber}} approche de sa deadline de résolution (moins de 2h restantes).",
      en: "Ticket {{ticketNumber}} is approaching its resolution deadline (under 2h left).",
      ar: "التذكرة {{ticketNumber}} تقترب من الموعد النهائي للحل (أقل من ساعتين متبقية).",
    },
    variables: ["ticketNumber"],
    channels: { in_app: true, email: true, push: false },
  },
  "ticket.sla_overdue": {
    name: "SLA overdue",
    title: { fr: "SLA dépassé", en: "SLA overdue", ar: "تم تجاوز اتفاقية مستوى الخدمة" },
    message: {
      fr: "Le ticket {{ticketNumber}} a dépassé sa deadline de résolution.",
      en: "Ticket {{ticketNumber}} has passed its resolution deadline.",
      ar: "تجاوزت التذكرة {{ticketNumber}} الموعد النهائي للحل.",
    },
    variables: ["ticketNumber"],
    channels: { in_app: true, email: true, push: false },
  },

  "security.login": {
    name: "Login",
    title: { fr: "Connexion", en: "Login", ar: "تسجيل الدخول" },
    message: {
      fr: "Une connexion a été détectée sur votre compte.",
      en: "A login was detected on your account.",
      ar: "تم رصد تسجيل دخول على حسابك.",
    },
    variables: [],
    channels: { in_app: true, email: false, push: false },
  },
  "security.new_login": {
    name: "New login",
    title: { fr: "Nouvelle connexion", en: "New login", ar: "تسجيل دخول جديد" },
    message: {
      fr: "Nouvelle connexion depuis {{ipAddress}}.",
      en: "New login from {{ipAddress}}.",
      ar: "تسجيل دخول جديد من {{ipAddress}}.",
    },
    variables: ["ipAddress"],
    channels: { in_app: true, email: true, push: false },
  },
  "security.failed_login": {
    name: "Failed login attempt",
    title: { fr: "Tentative de connexion échouée", en: "Failed login attempt", ar: "محاولة تسجيل دخول فاشلة" },
    message: {
      fr: "Une tentative de connexion a échoué sur votre compte.",
      en: "A failed login attempt was made on your account.",
      ar: "فشلت محاولة تسجيل دخول على حسابك.",
    },
    variables: [],
    channels: { in_app: true, email: true, push: false },
  },
  "security.password_changed": {
    name: "Password changed",
    title: { fr: "Mot de passe modifié", en: "Password changed", ar: "تم تغيير كلمة المرور" },
    message: {
      fr: "Le mot de passe de votre compte a été modifié.",
      en: "Your account password was changed.",
      ar: "تم تغيير كلمة مرور حسابك.",
    },
    variables: [],
    channels: { in_app: true, email: true, push: false },
  },
  "security.new_device": {
    name: "New device",
    title: { fr: "Nouvel appareil", en: "New device", ar: "جهاز جديد" },
    message: {
      fr: "Un nouvel appareil s'est connecté à votre compte.",
      en: "A new device signed in to your account.",
      ar: "قام جهاز جديد بتسجيل الدخول إلى حسابك.",
    },
    variables: [],
    channels: { in_app: true, email: true, push: false },
  },
  "security.alert": {
    name: "Security alert",
    title: { fr: "Alerte sécurité", en: "Security alert", ar: "تنبيه أمني" },
    message: {
      fr: "Une alerte de sécurité nécessite votre attention : {{details}}",
      en: "A security alert needs your attention: {{details}}",
      ar: "تنبيه أمني يتطلب انتباهك: {{details}}",
    },
    variables: ["details"],
    channels: { in_app: true, email: true, push: false },
  },

  "system.error": {
    name: "System error",
    title: { fr: "Erreur système", en: "System error", ar: "خطأ في النظام" },
    message: {
      fr: "Une erreur système s'est produite : {{details}}",
      en: "A system error occurred: {{details}}",
      ar: "حدث خطأ في النظام: {{details}}",
    },
    variables: ["details"],
    channels: { in_app: true, email: true, push: false },
  },
  "invoice.reminder": {
    name: "Invoice payment reminder",
    title: { fr: "Rappel de paiement", en: "Payment reminder", ar: "تذكير بالدفع" },
    message: {
      fr: "La facture {{invoiceNumber}} d'un montant de {{amount}} arrive à échéance le {{dueDate}}.",
      en: "Invoice {{invoiceNumber}} of {{amount}} is due on {{dueDate}}.",
      ar: "الفاتورة {{invoiceNumber}} بمبلغ {{amount}} تستحق في {{dueDate}}.",
    },
    variables: ["invoiceNumber", "amount", "dueDate"],
    channels: { in_app: true, email: true, push: false },
  },
  "wallet.low_balance": {
    name: "Wallet low balance",
    title: { fr: "Solde du portefeuille faible", en: "Wallet balance low", ar: "رصيد المحفظة منخفض" },
    message: {
      fr: "Le solde de votre portefeuille est de {{currentBalance}}. Rechargez pour éviter toute interruption.",
      en: "Your wallet balance is {{currentBalance}}. Top up to avoid service interruption.",
      ar: "رصيد محفظتك هو {{currentBalance}}. أعد التعبئة لتجنب انقطاع الخدمة.",
    },
    variables: ["currentBalance"],
    channels: { in_app: true, email: true, push: false },
  },
  "promotion.offer": {
    name: "Promotion offer",
    title: { fr: "Nouvelle offre disponible", en: "New offer available", ar: "عرض جديد متاح" },
    message: {
      fr: "{{promotionName}} : profitez de {{discount}} jusqu'au {{validUntil}}.",
      en: "{{promotionName}}: enjoy {{discount}} until {{validUntil}}.",
      ar: "{{promotionName}}: استفد من {{discount}} حتى {{validUntil}}.",
    },
    variables: ["promotionName", "discount", "validUntil"],
    channels: { in_app: true, email: false, push: false },
  },
};

const DIRECT_ONLY_EVENTS = {
  "customer.order_confirmed": { category: "orders", priority: "normal" },
  "customer.order_status_updated": { category: "orders", priority: "normal" },
  "customer.review_approved": { category: "reviews", priority: "low" },
};

const seedNotificationTemplates = async () => {
  const templates = [];
  const allConfigs = { ...EVENT_CONFIG, ...DIRECT_ONLY_EVENTS };
  for (const code of Object.keys(allConfigs)) {
    const content = TEMPLATE_CONTENT[code];
    if (!content) continue; // every declared event must have content above
    templates.push({
      code,
      name: content.name,
      category: allConfigs[code].category,
      priority: allConfigs[code].priority,
      enabled: true,
      channels: content.channels,
      title: content.title,
      message: content.message,
      variables: content.variables,
    });
  }

  for (const tpl of templates) {
    await NotificationTemplate.findOneAndUpdate({ code: tpl.code }, tpl, {
      upsert: true,
      new: true,
      setDefaultsOnInsert: true,
    });
  }

  await AuditService.logAction({
    actorType: "system",
    module: "NotificationTemplate",
    action: "seed",
    entityType: "NotificationTemplate",
    status: "success",
    severity: "low",
    newValue: { count: templates.length },
  }).catch(() => {});

  return NotificationTemplate.find();
};

module.exports = seedNotificationTemplates;
module.exports.TEMPLATE_CONTENT = TEMPLATE_CONTENT;

if (require.main === module) {
  require("dotenv").config();
  const mongoose = require("mongoose");

  (async () => {
    try {
      await mongoose.connect(process.env.MONGO_URI);
      const templates = await seedNotificationTemplates();
      console.log(`✅ ${templates.length} notification templates créés/mis à jour`);
      process.exit(0);
    } catch (error) {
      console.error("❌ Erreur seed notification templates:", error.message);
      process.exit(1);
    }
  })();
}
