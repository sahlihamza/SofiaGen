const express = require("express");
const { getCode, getCodes } = require("../config/rbac/permissionCodes");
const router = express.Router();
const {
  getStaff,
  getStaffById,
  searchUsers,
  addStaff,
  updateStaff,
  deleteStaff,
  updateStaffStatus,
  assignRoles,
  getProfile,
  updateProfile,
  updateProfileImage,
  changePassword,
  getMyStores,
  selectMyStore,
  deselectMyStore,
  blockUser,
  unblockUser,
  suspendUser,
  activateUser,
  archiveUser,
  unarchiveUser,
  resetUserPassword,
  resendInvitation,
  resendPasswordEmail,
  forcePasswordChange,
  enable2FA,
  disable2FA,
  getUserSessions,
  revokeAllSessions,
  logoutDevice,
  getUserLoginHistory,
  getUserActivity,
  getUserPermissions,
  getUserProfile,
  impersonateUser,
  duplicateUser,
  exportUser,
  bulkActivate,
  bulkDeactivate,
  bulkBlock,
  bulkUnblock,
  bulkSuspend,
  bulkArchive,
  bulkDelete,
  bulkResetPassword,
  bulkResendInvitation,
  bulkExport,
  bulkAssignRole,
  bulkEnable2FA,
  bulkDisable2FA,
} = require("../controller/userController");
const { hasPermission } = require("../middleware/auth");

router.get("/staff", hasPermission("staff", "view"), getStaff);
router.get("/search", hasPermission("staff", "view"), searchUsers);
router.get("/staff/:id", hasPermission("staff", "view"), getStaffById);
router.post("/staff", hasPermission("staff", "create"), addStaff);
router.put("/staff/:id", hasPermission("staff", "update"), updateStaff);
router.delete("/staff/:id", hasPermission("staff", "delete"), deleteStaff);
router.put("/staff/:id/status", hasPermission("staff", "update"), updateStaffStatus);
router.patch("/:id/assign-roles", hasPermission("staff", "update"), assignRoles);
// ─── PROFILE (connected user) ─────────────────────────────────────────────

router.post("/:id/block", hasPermission("staff", "update"), blockUser);
router.post("/:id/unblock", hasPermission("staff", "update"), unblockUser);
router.post("/:id/suspend", hasPermission("staff", "update"), suspendUser);
router.post("/:id/activate", hasPermission("staff", "update"), activateUser);
router.post("/:id/archive", hasPermission("staff", "update"), archiveUser);
router.post("/:id/unarchive", hasPermission("staff", "update"), unarchiveUser);
router.post("/:id/reset-password", hasPermission("staff", "update"), resetUserPassword);
router.post("/:id/resend-invitation", hasPermission("staff", "update"), resendInvitation);
router.post("/:id/resend-password-email", hasPermission("staff", "update"), resendPasswordEmail);
router.post("/:id/force-password-change", hasPermission("staff", "update"), forcePasswordChange);
router.post("/:id/2fa/enable", hasPermission("staff", "update"), enable2FA);
router.post("/:id/2fa/disable", hasPermission("staff", "update"), disable2FA);
router.get("/:id/sessions", hasPermission("staff", "view"), getUserSessions);
router.post("/:id/sessions/revoke-all", hasPermission("staff", "update"), revokeAllSessions);
router.post("/:id/sessions/:sessionId/logout", hasPermission("staff", "update"), logoutDevice);
router.get("/:id/login-history", hasPermission("staff", "view"), getUserLoginHistory);
router.get("/:id/activity", hasPermission("staff", "view"), getUserActivity);
router.get("/:id/permissions", hasPermission("staff", "view"), getUserPermissions);
router.get("/:id/profile", hasPermission("staff", "view"), getUserProfile);
router.post("/:id/impersonate", hasPermission("staff", "update"), impersonateUser);
router.post("/:id/duplicate", hasPermission("staff", "create"), duplicateUser);
router.get("/:id/export", hasPermission("staff", "view"), exportUser);

router.post("/bulk/activate", hasPermission("staff", "update"), bulkActivate);
router.post("/bulk/deactivate", hasPermission("staff", "update"), bulkDeactivate);
router.post("/bulk/block", hasPermission("staff", "update"), bulkBlock);
router.post("/bulk/unblock", hasPermission("staff", "update"), bulkUnblock);
router.post("/bulk/suspend", hasPermission("staff", "update"), bulkSuspend);
router.post("/bulk/archive", hasPermission("staff", "update"), bulkArchive);
router.post("/bulk/delete", hasPermission("staff", "delete"), bulkDelete);
router.post("/bulk/reset-password", hasPermission("staff", "update"), bulkResetPassword);
router.post("/bulk/resend-invitation", hasPermission("staff", "update"), bulkResendInvitation);
router.post("/bulk/export", hasPermission("staff", "view"), bulkExport);
router.post("/bulk/role-assign", hasPermission("staff", "update"), bulkAssignRole);
router.post("/bulk/enable-2fa", hasPermission("staff", "update"), bulkEnable2FA);
router.post("/bulk/disable-2fa", hasPermission("staff", "update"), bulkDisable2FA);

// ─── PROFILE (connected user) ─────────────────────────────────────
router.get("/profile", getProfile);
router.put("/profile", updateProfile);
router.patch("/profile/image", updateProfileImage);
router.put("/profile/password", changePassword);

// ─── MY STORES (connected user) ────────────────────────────────────
router.get("/stores", getMyStores);
router.patch("/stores/select", selectMyStore);
router.delete("/stores/select", deselectMyStore);

module.exports = router;
