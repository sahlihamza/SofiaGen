const express = require("express");
const { getCode, getCodes } = require("../config/rbac/permissionCodes");
const mongoose = require("mongoose");
const router = express.Router();
const Store = require("../models/Store");
const User = require("../models/User");
const userService = require("../service/userService");
const UserStore = require("../models/UserStore");
const Role = require("../models/Role");
const crypto = require("node:crypto");
const StoreDomain = require("../models/StoreDomain");
const StoreUsageService = require("../service/StoreUsageService");
const { loadUser, resolveAuthorizationContext, hasPermission, hasAnyPermission, requireStoreAccess } = require("../middleware/auth");
const { emitEvent } = require("../lib/eventBus");
const storeService = require("../service/storeService");
const AuditService = require("../service/AuditService");
const GeneralSettings = require("../models/GeneralSettings");
const ProductSettings = require("../models/ProductSettings");
const Country = require("../models/Country");
const Currency = require("../models/Currency");
const roleService = require("../service/RoleService");
const DomainVerificationService = require("../service/DomainVerificationService");
const ApiKeyService = require("../service/ApiKeyService");
const StoreWebhookService = require("../service/StoreWebhookService");
const StoreWebhook = require("../models/StoreWebhook");
const BackupJobService = require("../service/BackupJobService");
const WebhookLog = require("../models/WebhookLog");
const ExportJob = require("../models/ExportJob");
const ApiKey = require("../models/ApiKey");
const BackupJob = require("../models/BackupJob");
const ShippingZoneService = require("../service/ShippingZoneService");
const ShippingZone = require("../models/ShippingZone");
const ShippingClass = require("../models/ShippingClass");
const ShippingSettings = require("../models/ShippingSettings");
const PickupLocation = require("../models/PickupLocation");
const logger = require("../config/logger");
const { sendStoreOwnerInvitationEmail, sendStaffWelcomeEmail } = require("../utils/mailer");
const { generatePassword } = require("../utils/generatePassword");
const Customer = require("../models/Customer");
const Product = require("../models/Product");
const Order = require("../models/Order");
const Payment = require("../models/Payment");
const OrderItem = require("../models/OrderItem");
const Invoice = require("../models/Invoice");
const AuditLog = require("../models/AuditLog");
const StoreUsage = require("../models/StoreUsage");
const QuotaType = require("../models/QuotaType");
const Backup = require("../models/Backup");
const ThemeService = require("../service/ThemeService");
const PageProvisioningService = require("../service/PageProvisioningService");

const DEFAULT_COUNTRY_ISO2 = "TN";

// Helper: échappe les caractères spéciaux regex
const escapeRegex = (str) => str.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");

// Validate domain name (basic, rejects spaces and invalid labels)
const isValidDomain = (d) => {
  if (!d || typeof d !== "string") return false;
  const domain = d.trim();
  // domain must contain at least one dot and valid labels
  const domainRegex = /^(?!-)(?:[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?\.)+[A-Za-z]{2,}$/;
  return domainRegex.test(domain);
};

const buildOwnerName = (ownerFirstName, ownerLastName, ownerName, fallbackEmail) => {
  const fullName = `${ownerFirstName || ""} ${ownerLastName || ""}`.trim();
  return fullName || ownerName || fallbackEmail;
};

const resolveStoreOwner = async ({
  ownerEmail,
  ownerFirstName,
  ownerLastName,
  ownerName,
  ownerPhone,
  ownerPassword,
  theme,
}) => {
  if (!ownerEmail || !String(ownerEmail).trim()) {
    return { ownerId: null, createdOwner: false };
  }

  const email = String(ownerEmail).trim().toLowerCase();
  const existingUser = await userService.findUserByEmail(email);

  if (existingUser) {
    return { ownerId: existingUser._id, createdOwner: false };
  }

  const tempPassword = String(ownerPassword || "").trim() || crypto.randomBytes(12).toString("hex");
  const nameToUse = buildOwnerName(ownerFirstName, ownerLastName, ownerName, email);

  const newUser = await userService.createUser({
    name: nameToUse,
    email,
    password: tempPassword,
    phone: ownerPhone,
    theme,
  });

  return {
    ownerId: newUser._id,
    createdOwner: true,
    ownerEmail: email,
    ownerName: nameToUse,
    ownerPassword: tempPassword,
  };
};

// GET all stores
router.get("/", loadUser, resolveAuthorizationContext, async (req, res) => {
  try {
    const user = await User.findById(req.userId);
    const accessibleStoreIds = new Set([
      ...(user?.storeIds || []),
      user?.currentStoreId,
    ].filter(Boolean).map((id) => String(id)));

    const stores = await userService.getStoresForUser(req.userId);
    const filteredStores = stores;






    // Use currentStoreId as the single source of truth for the user's
    // selected store in the admin dashboard (replaces the deprecated
    // selectedStore field).
    const selectedStoreId = user?.currentStoreId?.toString();

    const annotatedStores = filteredStores.map((store) => {
      const obj = store.toObject({ flattenMaps: true });
      const owner = obj.ownerId || {};
      return {
        ...obj,
        ownerId: undefined,
        owner: {
          _id: owner._id,
          name: owner.name,
          email: owner.email,
        },
        ownerName: owner.name || owner.email || "N/A",
        isSelected: store._id.toString() === selectedStoreId,
      };
    });

    res.json(annotatedStores);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// CHECK store name availability
router.get("/check-name", async (req, res) => {
  try {
    const { name } = req.query;

    if (!name || !name.trim()) {
      return res.json({ available: false, message: "Name is required" });
    }

    const existing = await Store.findOne({
      name: { $regex: new RegExp(`^${escapeRegex(name.trim())}$`, "i") },
    });

    if (existing) {
      return res.json({ available: false, message: `A store named "${name}" already exists` });
    }

    res.json({ available: true, message: "Name is available" });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// CHECK subdomain availability
router.get("/check-subdomain", async (req, res) => {
  try {
    const { subdomain } = req.query;

    if (!subdomain || !subdomain.trim()) {
      return res.json({ available: false, message: "Subdomain is required" });
    }

    const normalized = String(subdomain).trim().toLowerCase();
    const subdomainRegex = /^[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?$/;

    if (!subdomainRegex.test(normalized)) {
      return res.json({ available: false, message: "Subdomain format is invalid" });
    }

    const existing = await Store.findOne({ subdomain: normalized });

    if (existing) {
      return res.json({ available: false, message: `Subdomain "${normalized}" is already taken` });
    }

    res.json({ available: true, message: "Subdomain is available" });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// --- Store domains endpoints (placed before ":id" route to avoid param conflicts) ---

// GET domains for a store
router.get(
  "/:id/domains",
  loadUser, resolveAuthorizationContext, requireStoreAccess(),
  hasAnyPermission(["online store", "view"], ["store", "view"], ["stores", "view"]),
  async (req, res) => {
  try {
    const domains = await StoreDomain.find({ storeId: req.params.id });
    res.json(domains);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// CREATE domain for a store (unique across all domains)
router.post(
  "/:id/domains",
  loadUser, resolveAuthorizationContext, requireStoreAccess(),
  hasAnyPermission(["online store", "create"], ["store", "create"], ["stores", "create"]),
  async (req, res) => {
  try {
    // Clients can only name the domain and choose it primary. DNS/SSL state is
    // determined server-side by DomainVerificationService — never from req.body.
    const { domain, isPrimary } = req.body;

    if (!domain || !domain.trim()) {
      return res.status(400).json({ message: "Domain is required" });
    }

    if (!isValidDomain(domain)) {
      return res.status(400).json({ message: "Domain format is invalid" });
    }

    try {
      DomainVerificationService.assertDomainEligible(domain);
    } catch (eligibilityError) {
      return res.status(400).json({ message: eligibilityError.message });
    }

    const existing = await StoreDomain.findOne({
      domain: { $regex: new RegExp(`^${escapeRegex(domain.trim())}$`, "i") },
    });

    if (existing) {
      return res.status(400).json({ message: `Domain '${domain}' already exists` });
    }

    if (isPrimary) {
      await StoreDomain.updateMany({ storeId: req.params.id }, { $set: { isPrimary: false } });
    }

    const saved = await StoreDomain.create({
      storeId: req.params.id,
      domain: domain.trim().toLowerCase(),
      type: "custom",
      isPrimary: !!isPrimary,
    });

    try {
      await StoreUsageService.incrementUsage(req.params.id, "domains", 1);
    } catch (err) {
      console.error("Failed to increment domain usage for store:", err.message);
    }

    // First verification pass in the background; the UI also has an explicit Verify action.
    DomainVerificationService.verifyStoreDomainDocument(saved).catch((err) => {
      console.error("Background domain verification failed:", err.message);
    });

    res.json(saved);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// --- Re-check a domain's DNS + SSL state (server-side determination) ---
router.post(
  "/:id/domains/:domainId/verify",
  loadUser, resolveAuthorizationContext, requireStoreAccess(),
  hasAnyPermission(["online store", "update"], ["store", "update"], ["stores", "update"]),
  async (req, res) => {
    try {
      const updated = await DomainVerificationService.verifyById(req.params.domainId, req.params.id);
      res.json(updated);
    } catch (err) {
      if (err.name === "NotFound") return res.status(404).json({ message: err.message });
      res.status(500).json({ message: err.message });
    }
  }
);


// --- Store detail tab endpoints ---

const analyticsCache = new Map();
const ANALYTICS_CACHE_TTL = 5 * 60 * 1000;

// GET analytics for a store
// Window-bounded reads only (never full history) + 5-minute cache.
router.get("/:id/analytics", loadUser, resolveAuthorizationContext, requireStoreAccess(), hasAnyPermission(["online store", "view"], ["store", "view"], ["stores", "view"]), async (req, res) => {
  try {
    const storeId = req.params.id;
    const range = ["7d", "30d", "90d", "12m", "custom"].includes(req.query.range) ? req.query.range : "30d";
    const now = new Date();
    let start;
    let end = now;
    if (range === "custom") {
      const from = req.query.from ? new Date(req.query.from) : null;
      const to = req.query.to ? new Date(req.query.to) : null;
      start = from && !Number.isNaN(from.getTime()) ? from : new Date(now.getTime() - 30 * 86400000);
      end = to && !Number.isNaN(to.getTime()) ? to : now;
    } else {
      const days = { "7d": 7, "30d": 30, "90d": 90, "12m": 365 }[range];
      start = new Date(now.getTime() - days * 86400000);
    }

    const granularity = range === "12m" ? "month" : "day";
    const cacheKey = `${storeId}:${range}:${start.toISOString()}:${end.toISOString()}`;
    const cached = analyticsCache.get(cacheKey);
    if (cached && cached.expires > Date.now()) {
      return res.json({ ...cached.data, cached: true });
    }

    const windowMatch = { storeId, createdAt: { $gte: start, $lte: end } };
    const windowOrders = await Order.find(windowMatch).select("total paymentStatus status customerId").lean();

    const isPaid = (o) => o.paymentStatus === "paid" && !["Cancel", "Refunded"].includes(o.status);
    const paidOrders = windowOrders.filter(isPaid);
    const refundedOrders = windowOrders.filter((o) => o.paymentStatus === "refunded" || o.status === "Refunded");
    const cancelledOrders = windowOrders.filter((o) => o.status === "Cancel");

    const revenue = paidOrders.reduce((sum, o) => sum + Number(o.total || 0), 0);
    const ordersCount = windowOrders.length;
    const avgOrderValue = paidOrders.length > 0 ? Math.round(revenue / paidOrders.length) : 0;

    const [customersTotal, newCustomers] = await Promise.all([
      Customer.countDocuments({ storeId }),
      Customer.countDocuments({ storeId, createdAt: { $gte: start, $lte: end } }),
    ]);

    // New vs returning: paying customers whose account was created inside the window
    const customerIds = [...new Set(paidOrders.map((o) => String(o.customerId || "")))].filter(Boolean);
    let newBuyers = 0;
    let returningBuyers = 0;
    if (customerIds.length > 0) {
      const buyers = await Customer.find({ _id: { $in: customerIds } }).select("createdAt").lean();
      for (const buyer of buyers) {
        if (buyer.createdAt && buyer.createdAt >= start) newBuyers += 1;
        else returningBuyers += 1;
      }
    }

    // Revenue trend grouped by day/month over the window only
    const trendMap = new Map();
    for (const order of paidOrders) {
      const date = new Date(order.createdAt);
      const key = granularity === "month" ? `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}` : date.toISOString().slice(0, 10);
      trendMap.set(key, (trendMap.get(key) || 0) + Number(order.total || 0));
    }
    const revenueTrend = [...trendMap.entries()]
      .sort(([a], [b]) => (a < b ? -1 : 1))
      .map(([label, value]) => ({ label, value: Math.round(value) }));

    const paymentStatuses = await Payment.aggregate([
      { $match: { storeId: new mongoose.Types.ObjectId(storeId), createdAt: { $gte: start, $lte: end } } },
      { $group: { _id: "$status", count: { $sum: 1 } } },
    ]);
    const paymentsByStatus = Object.fromEntries(paymentStatuses.map((entry) => [entry._id, entry.count]));
    const terminalPayments = (paymentsByStatus.paid || 0) + (paymentsByStatus.failed || 0);
    const paymentSuccessRate = terminalPayments > 0 ? Math.round(((paymentsByStatus.paid || 0) / terminalPayments) * 100) : null;

    const refundRate = ordersCount > 0 ? Math.round((refundedOrders.length / ordersCount) * 100) : null;
    const cancellationRate = ordersCount > 0 ? Math.round((cancelledOrders.length / ordersCount) * 100) : null;

    // Top products & categories from line items of this window's orders
    const orderIds = windowOrders.map((o) => o._id);
    let topProducts = [];
    let topCategories = [];
    if (orderIds.length > 0) {
      const items = await OrderItem.find({ orderId: { $in: orderIds } }).select("productId productName quantity total").lean();
      const productMap = new Map();
      for (const item of items) {
        const key = String(item.productId || item.productName || "unknown");
        const entry = productMap.get(key) || { name: item.productName || "Unknown product", quantity: 0, revenue: 0 };
        entry.quantity += Number(item.quantity || 0);
        entry.revenue += Number(item.total || 0);
        productMap.set(key, entry);
      }
      topProducts = [...productMap.values()].sort((a, b) => b.revenue - a.revenue).slice(0, 5);

      const productIds = [...productMap.keys()].filter((key) => /^[a-f\d]{24}$/i.test(key));
      const products = productIds.length > 0 ? await Product.find({ _id: { $in: productIds } }).select("category").populate("category", "name").lean() : [];
      const categoryByProduct = new Map(products.map((p) => [String(p._id), p.category?.name || "Uncategorized"]));
      const categoryMap = new Map();
      for (const item of items) {
        const categoryName = categoryByProduct.get(String(item.productId)) || "Uncategorized";
        const entry = categoryMap.get(categoryName) || { name: categoryName, orders: 0, revenue: 0 };
        entry.orders += Number(item.quantity || 0);
        entry.revenue += Number(item.total || 0);
        categoryMap.set(categoryName, entry);
      }
      topCategories = [...categoryMap.values()].sort((a, b) => b.revenue - a.revenue).slice(0, 5);
    }

    const data = {
      range,
      window: { start, end },
      summary: {
        revenue,
        orders: ordersCount,
        paidOrders: paidOrders.length,
        aov: avgOrderValue,
        customersTotal,
        newCustomers,
        refundRate,
        cancellationRate,
        paymentSuccessRate,
      },
      newVsReturning: { newBuyers, returningBuyers },
      payments: {
        byStatus: paymentsByStatus,
        successRate: paymentSuccessRate,
      },
      revenueTrend,
      topProducts,
      topCategories,
      notes: {
        conversionRate: null,
        traffic: null,
        cartAbandonment: null,
        reason: "Conversion, cart abandonment and raw traffic require visitor tracking which is not instrumented yet; the previous orders/customers formula was not a real conversion rate.",
      },
      generatedAt: new Date().toISOString(),
    };

    analyticsCache.set(cacheKey, { expires: Date.now() + ANALYTICS_CACHE_TTL, data });
    res.json(data);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// GET API keys for a store
router.get("/:id/api-keys", loadUser, resolveAuthorizationContext, requireStoreAccess(), hasAnyPermission(["online store", "view"], ["store", "view"], ["stores", "view"]), async (req, res) => {
  try {
    const keys = await ApiKeyService.list(req.params.id);
    res.json(keys);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// GET webhooks for a store
router.get("/:id/webhooks", loadUser, resolveAuthorizationContext, requireStoreAccess(), hasAnyPermission(["online store", "view"], ["store", "view"], ["stores", "view"]), async (req, res) => {
  try {
    const webhooks = await StoreWebhookService.list(req.params.id);
    res.json(webhooks);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// GET backups for a store
router.get("/:id/backups", loadUser, resolveAuthorizationContext, requireStoreAccess(), hasAnyPermission(["online store", "view"], ["store", "view"], ["stores", "view"]), async (req, res) => {
  try {
    const backups = await BackupJobService.list(req.params.id);
    res.json(backups);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// CREATE backup for a store (async job: queued -> running -> completed)
router.post("/:id/backups", loadUser, resolveAuthorizationContext, requireStoreAccess(), hasAnyPermission(["online store", "create"], ["store", "create"], ["stores", "create"]), async (req, res) => {
  try {
    const job = await BackupJobService.create(req.params.id, req.body || {}, req.userId);
    res.status(202).json(job);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// Verify a backup artifact against its stored checksum
router.post("/:id/backups/:jobId/verify", loadUser, resolveAuthorizationContext, requireStoreAccess(), hasAnyPermission(["online store", "update"], ["store", "update"], ["stores", "update"]), async (req, res) => {
  try {
    const result = await BackupJobService.verify(req.params.id, req.params.jobId);
    res.json(result);
  } catch (err) {
    if (err.name === "NotFound") return res.status(404).json({ message: err.message });
    res.status(500).json({ message: err.message });
  }
});

// Restore a backup artifact to the store (configuration only)
router.post("/:id/backups/:jobId/restore", loadUser, resolveAuthorizationContext, requireStoreAccess(), hasAnyPermission(["online store", "update"], ["store", "update"], ["stores", "update"]), async (req, res) => {
  try {
    const result = await BackupJobService.restore(req.params.id, req.params.jobId, req.userId);
    res.status(200).json(result);
  } catch (err) {
    if (err.name === "NotFound") return res.status(404).json({ message: err.message });
    if (err.name === "Conflict" || err.status === 409) return res.status(409).json({ message: err.message });
    res.status(500).json({ message: err.message });
  }
});

// Download the backup artifact
router.get("/:id/backups/:jobId/download", loadUser, resolveAuthorizationContext, requireStoreAccess(), hasAnyPermission(["online store", "view"], ["store", "view"], ["stores", "view"]), async (req, res) => {
  try {
    const { buffer, fileName } = await BackupJobService.readFileForDownload(req.params.id, req.params.jobId);
    res.setHeader("Content-Type", "application/json");
    res.setHeader("Content-Disposition", `attachment; filename="${fileName}"`);
    res.send(buffer);
  } catch (err) {
    if (err.name === "NotFound") return res.status(404).json({ message: err.message });
    res.status(500).json({ message: err.message });
  }
});

// DELETE a backup job and its artifact
router.delete("/:id/backups/:jobId", loadUser, resolveAuthorizationContext, requireStoreAccess(), hasAnyPermission(["online store", "delete"], ["store", "delete"], ["stores", "delete"]), async (req, res) => {
  try {
    const result = await BackupJobService.remove(req.params.id, req.params.jobId);
    res.json(result);
  } catch (err) {
    if (err.name === "NotFound") return res.status(404).json({ message: err.message });
    res.status(500).json({ message: err.message });
  }
});

// GET operational logs for a store
// Shared filter builder for the store audit tab (Logs ≠ Audit: this is the
// who-did-what trail; technical logs come from their own sources).
const buildAuditQuery = (storeId, query) => {
  const { action, module: moduleFilter, entityType, severity, status, actorId, requestId, dateFrom, dateTo } = query;
  const filter = { storeId };

  if (action) filter.action = { $regex: escapeRegex(String(action).toLowerCase()), $options: "i" };
  if (moduleFilter) filter.module = { $regex: escapeRegex(String(moduleFilter)), $options: "i" };
  if (entityType) filter.entityType = { $regex: escapeRegex(String(entityType)), $options: "i" };
  if (severity && ["low", "medium", "high", "critical"].includes(severity)) filter.severity = severity;
  if (status && ["success", "failed"].includes(status)) filter.status = status;
  if (requestId) filter.requestId = String(requestId);
  if (actorId && mongoose.Types.ObjectId.isValid(actorId)) filter.actorId = new mongoose.Types.ObjectId(actorId);
  if (dateFrom || dateTo) {
    filter.createdAt = {};
    if (dateFrom && !Number.isNaN(new Date(dateFrom).getTime())) filter.createdAt.$gte = new Date(dateFrom);
    if (dateTo && !Number.isNaN(new Date(dateTo).getTime())) {
      const to = dateTo.length === 10 ? `${dateTo}T23:59:59.999Z` : dateTo;
      filter.createdAt.$lte = new Date(to);
    }
  }
  return filter;
};

router.get("/:id/logs", loadUser, resolveAuthorizationContext, requireStoreAccess(), hasAnyPermission(["online store", "view"], ["store", "view"], ["stores", "view"]), async (req, res) => {
  try {
    const page = Math.max(1, Number(req.query.page) || 1);
    const limit = Math.min(100, Math.max(1, Number(req.query.limit) || 25));
    const filter = buildAuditQuery(req.params.id, req.query);

    const [total, logs] = await Promise.all([
      AuditLog.countDocuments(filter),
      AuditLog.find(filter).sort({ createdAt: -1 }).skip((page - 1) * limit).limit(limit).lean(),
    ]);

    res.json({
      logs,
      pagination: { total, page, limit, pages: Math.ceil(total / limit) || 1 },
    });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// GET security data for a store
// No artificial single score: a transparent status (good / attention /
// critical) backed by explicit reasons, plus raw facts per section.
router.get("/:id/security", loadUser, resolveAuthorizationContext, requireStoreAccess(), hasAnyPermission(["online store", "view"], ["store", "view"], ["stores", "view"]), async (req, res) => {
  try {
    const storeId = req.params.id;
    const now = new Date();
    const since30d = new Date(now.getTime() - 30 * 86400000);

    const [store, memberships, failedLogins30d, securityEvents, domainDocs, apiKeyStats, webhookStats] = await Promise.all([
      Store.findById(storeId).select("ownerId name").lean(),
      UserStore.find({ storeId })
        .populate("userId", "name email status twoFactorEnabled")
        .populate("roleId", "name")
        .lean(),
      AuditLog.countDocuments({ storeId, status: "failed", module: "auth", createdAt: { $gte: since30d } }),
      AuditLog.find({
        storeId,
        $or: [
          { action: /^api_key\./ },
          { action: /^store\.owner_changed/ },
          { action: /^webhook\./ },
          { action: /^settings\.updated/ },
          { action: /^permission_changed/ },
          { severity: "critical" },
        ],
      })
        .sort({ createdAt: -1 })
        .limit(8)
        .lean(),
      StoreDomain.find({ storeId }).select("domain isPrimary verified ssl dnsStatus sslExpiresAt").lean(),
      ApiKey.aggregate([
        { $match: { storeId: new mongoose.Types.ObjectId(storeId) } },
        { $group: { _id: "$status", count: { $sum: 1 } } },
      ]),
      StoreWebhook.aggregate([
        { $match: { storeId: new mongoose.Types.ObjectId(storeId) } },
        { $group: { _id: "$status", count: { $sum: 1 } } },
      ]),
    ]);

    const activeMemberships = memberships.filter((m) => m.status === "active" && m.userId);
    const suspendedMemberships = memberships.filter((m) => m.status === "suspended").length;
    const owner = store?.ownerId ? await User.findById(store.ownerId).select("twoFactorEnabled status").lean() : null;

    const staffTotal = activeMemberships.length;
    const staffWith2FA = activeMemberships.filter((m) => m.userId?.twoFactorEnabled).length;

    const rolesMap = new Map();
    for (const membership of activeMemberships) {
      const roleName = membership.roleId?.name || "No role";
      rolesMap.set(roleName, (rolesMap.get(roleName) || 0) + 1);
    }
    const roles = [...rolesMap.entries()]
      .map(([name, count]) => ({ name, count, privileged: /admin|owner/i.test(name) }))
      .sort((a, b) => b.count - a.count);

    const domains = {
      total: domainDocs.length,
      verified: domainDocs.filter((d) => d.verified).length,
      sslActive: domainDocs.filter((d) => d.ssl).length,
      sslExpired: domainDocs.filter((d) => d.sslExpiresAt && new Date(d.sslExpiresAt).getTime() < now.getTime()).length,
    };

    const apiKeys = { active: 0, revoked: 0 };
    for (const entry of apiKeyStats) {
      if (entry._id === "active") apiKeys.active = entry.count;
      if (entry._id === "revoked") apiKeys.revoked = entry.count;
    }
    const expiredStillActive = await ApiKey.countDocuments({
      storeId,
      status: "active",
      expiresAt: { $ne: null, $lt: now },
    });
    apiKeys.expiredStillActive = expiredStillActive;

    const webhooks = { active: 0, total: 0 };
    for (const entry of webhookStats) {
      webhooks.total += entry.count;
      if (entry._id === "active") webhooks.active = entry.count;
    }

    // Transparent rules — every non-good status comes with its reason.
    const reasons = [];
    let hasCritical = false;
    let hasAttention = false;
    const push = (level, text) => {
      if (level === "critical") hasCritical = true;
      if (level === "attention") hasAttention = true;
      reasons.push({ level, text });
    };

    if (!owner?.twoFactorEnabled) push("attention", "Owner account does not have two-factor authentication enabled.");
    else push("good", "Owner account has two-factor authentication enabled.");

    if (staffTotal > 0) {
      if (staffWith2FA < staffTotal) push("attention", `${staffTotal - staffWith2FA} of ${staffTotal} active admins have not enabled two-factor authentication.`);
      else push("good", "All active admins have two-factor authentication enabled.");
    }

    if (failedLogins30d >= 25) push("critical", `${failedLogins30d} failed login attempts in the last 30 days — possible credential stuffing.`);
    else if (failedLogins30d > 0) push("attention", `${failedLogins30d} failed login attempts in the last 30 days.`);
    else push("good", "No failed login attempts recorded in the last 30 days.");

    if (domains.total === 0) push("attention", "No custom domain configured — the storefront runs on a shared URL.");
    if (domains.sslExpired > 0) push("critical", `${domains.sslExpired} domain certificate(s) have expired.`);
    if (domains.total > 0 && domains.verified < domains.total) push("attention", `${domains.total - domains.verified} domain(s) are not DNS-verified yet.`);
    if (domains.total > 0 && domains.verified === domains.total && domains.sslExpired === 0) push("good", `All ${domains.verified} domain(s) are verified with valid SSL.`);

    if (suspendedMemberships > 0) push("attention", `${suspendedMemberships} suspended membership(s) should be reviewed or removed.`);
    else push("good", "No suspended staff memberships.");

    if (expiredStillActive > 0) push("critical", `${expiredStillActive} expired API key(s) are still flagged active — rotate or revoke them.`);

    const status = hasCritical ? "critical" : hasAttention ? "attention" : "good";

    res.json({
      status,
      reasons,
      sections: {
        authentication: {
          ownerTwoFactor: Boolean(owner?.twoFactorEnabled),
          staffWith2FA,
          staffTotal,
          failedLogins30d,
        },
        access: {
          activeAdmins: staffTotal,
          suspendedMemberships,
          roles,
        },
        infrastructure: {
          domains,
          apiKeys,
          webhooks,
        },
      },
      recentEvents: securityEvents.map((event) => ({
        _id: event._id,
        createdAt: event.createdAt,
        action: event.action,
        summary: event.summary,
        severity: event.severity,
        actorNameSnapshot: event.actorNameSnapshot || event.actorType,
      })),
    });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// GET maintenance data for a store
router.get("/:id/maintenance", loadUser, resolveAuthorizationContext, requireStoreAccess(), hasAnyPermission(["online store", "view"], ["store", "view"], ["stores", "view"]), async (req, res) => {
  try {
    const store = await Store.findById(req.params.id).select("maintenance name").lean();
    if (!store) return res.status(404).json({ message: "Store not found" });
    const maintenance = store.maintenance || {};
    res.json({
      enabled: Boolean(maintenance.enabled),
      message: maintenance.message || "",
      updatedAt: maintenance.updatedAt || null,
      updatedBy: maintenance.updatedBy || null,
    });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// UPDATE store-scoped maintenance mode (platform ops are NOT handled here)
router.put(
  "/:id/maintenance",
  loadUser, resolveAuthorizationContext, requireStoreAccess(),
  hasAnyPermission(["online store", "update"], ["store", "update"], ["stores", "update"]),
  async (req, res) => {
    try {
      const { enabled, message } = req.body || {};
      const updated = await Store.findByIdAndUpdate(
        req.params.id,
        {
          $set: {
            "maintenance.enabled": Boolean(enabled),
            "maintenance.message": String(message ?? "").slice(0, 500),
            "maintenance.updatedAt": new Date(),
            "maintenance.updatedBy": req.userId,
          },
        },
        { new: true }
      ).select("name maintenance");
      if (!updated) return res.status(404).json({ message: "Store not found" });

      AuditService.logAction({
        actorType: req.user?.isSuperAdmin ? "platform_admin" : "store_owner",
        actorId: req.userId,
        module: "store",
        action: enabled ? "maintenance.enabled" : "maintenance.disabled",
        summary: `Maintenance mode ${enabled ? "enabled" : "disabled"} for store "${updated.name}"`,
        entityType: "store",
        entityId: updated._id,
        storeId: updated._id,
        severity: enabled ? "high" : "low",
        requestId: req.requestId,
      }).catch(() => {});

      res.json({ enabled: updated.maintenance?.enabled || false, message: updated.maintenance?.message || "", updatedAt: updated.maintenance?.updatedAt || null });
    } catch (err) {
      res.status(400).json({ message: err.message });
    }
  }
);


// GET one store
router.get("/:id", loadUser, resolveAuthorizationContext, requireStoreAccess(), async (req, res) => {
  try {
    const data = await storeService.getAdminStoreDetails(req.params.id);
    res.json(data);
  } catch (err) {
    if (err.code === "BAD_REQUEST") return res.status(400).json({ message: err.message });
    if (err.code === "NOT_FOUND") return res.status(404).json({ message: err.message });
    res.status(500).json({ message: err.message });
  }
});

// CREATE store
//
// Atomic (transactional):
//   Store + Subscription + UserStore + User.currentStoreId + isSelected invariant
// Best-effort (after commit):
//   Roles, settings, theme, pages, shipping zone, provisioning status, events, email
// Permission: platform.store.create is verified inside storeService.createStore().
router.post("/", loadUser, resolveAuthorizationContext, async (req, res) => {
  try {
    const { name } = req.body;

    if (!name || !name.trim()) {
      return res.status(400).json({ message: "Store name is required" });
    }

    const ownerResult = await resolveStoreOwner({
      ownerEmail,
      ownerFirstName,
      ownerLastName,
      ownerName,
      ownerPhone,
      ownerPassword,
      theme,
    });

    const ownerId = ownerResult.ownerId;

    const storePayload = { ...req.body };
    if (Object.prototype.hasOwnProperty.call(storePayload, "category")) {
      storePayload.category = String(storePayload.category || "").trim() || undefined;
    }
    if (ownerId) storePayload.owner = ownerId;

    const store = new Store(storePayload);
    const saved = await store.save();

    emitEvent("store.created", {
      storeId: saved._id,
      actorId: req.userId,
      entityId: saved._id,
      metadata: { storeName: saved.name },
      actionUrl: `/stores/${saved._id}`,
    });

    AuditService.logAction({
      actorType: req.user?.isSuperAdmin ? "platform_admin" : "store_owner",
      actorId: req.userId,
      module: "store",
      action: "create",
      summary: `Store "${saved.name}" created`,
      entityType: "store",
      entityId: saved._id,
      storeId: saved._id,
      newValue: { name: saved.name, category: saved.category },
      requestId: req.requestId,
      ip: req.headers["x-forwarded-for"]?.split(",")[0] || req.socket?.remoteAddress,
      userAgent: req.headers["user-agent"],
    }).catch(() => {});

    await UserStore.create({ userId: req.userId, storeId: saved._id });

    if (ownerResult.createdOwner && ownerResult.ownerId) {
      await UserStore.create({ userId: ownerResult.ownerId, storeId: saved._id });
      await User.findByIdAndUpdate(ownerResult.ownerId, {
        $addToSet: { storeIds: saved._id },
      });
      const owner = await User.findById(ownerResult.ownerId);
      if (!owner.currentStoreId) {
        owner.currentStoreId = saved._id;
        await owner.save();
      }
    }

    try {
      await roleService.seedDefaultRolesForStore(saved._id);
    } catch (seedErr) {
      logger.error(
        `Erreur lors du seed des rôles par défaut pour le store ${saved._id}:`,
        seedErr.message
      );
    }

    const user = await User.findById(req.userId);
    if (user && !user.currentStoreId) {
      user.currentStoreId = saved._id;
      await user.save();
    }

    if (ownerResult.createdOwner) {
      try {
        await sendStoreOwnerInvitationEmail({
          to: ownerResult.ownerEmail,
          storeName: saved.name,
          ownerName: ownerResult.ownerName,
          password: ownerResult.ownerPassword,
          loginUrl: process.env.FRONTEND_URL ? `${process.env.FRONTEND_URL}/login` : undefined,
        });
      } catch (mailErr) {
        console.error("Failed to send owner invitation email:", mailErr.message);
      }
    }

    try {
      // Tunisia is the home market, so it's the sensible default for a new
      // store. Country.findOne() without a filter returns whichever document
      // comes first (Afghanistan), which is not a meaningful default.
      const [country, currency] = await Promise.all([
        Country.findOne({ iso2: DEFAULT_COUNTRY_ISO2 }).then(
          (found) => found || Country.findOne()
        ),
        Currency.findOne(),
      ]);

      if (country && currency) {
        await GeneralSettings.create({
          storeId: saved._id,
          storeName: saved.name,
          addressLine1: saved.address || "N/A",
          city: "N/A",
          postcode: "N/A",
          countryId: country._id,
          sellingCountries: [country._id],
          shippingCountries: [country._id],
          currencyId: currency._id,
          defaultCustomerAddress: "base",
          timezone: "UTC",
          weightUnit: "kg",
          dimensionUnit: "cm",
          // Must match one of the option values in GeneralSettingsSection's
          // date format <Select> ("MMM D, YYYY" / "D MMM, YYYY" /
          // "YYYY,MMM D"), not a plain display label — an unmatched value
          // leaves the dropdown showing blank.
          dateFormat: "D MMM, YYYY",
        });
      } else {
        logger.warn(
          `Paramètres généraux non créés pour le store ${saved._id}: aucune donnée Country/Currency disponible.`
        );
      }
    } catch (settingsErr) {
      logger.error(
        `Erreur lors de la création des paramètres généraux pour le store ${saved._id}:`,
        settingsErr.message
      );
    }

    try {
      await ProductSettings.create({
        storeId: saved._id,
        shopPage: "shop",
        // Same fallback used across the admin UI wherever a product has no
        // image (ProductTable, ProductDetails, etc.) — required non-empty.
        placeholderImage:
          "https://res.cloudinary.com/ahossain/image/upload/v1655097002/placeholder_kvepfp.png",
      });
    } catch (productSettingsErr) {
      logger.error(
        `Erreur lors de la création des paramètres produits pour le store ${saved._id}:`,
        productSettingsErr.message
      );
    }

    try {
      await ShippingZoneService.seedDefaultZoneForStore(saved._id);
    } catch (shippingZoneErr) {
      logger.error(
        `Erreur lors de la création de la zone de livraison par défaut pour le store ${saved._id}:`,
        shippingZoneErr.message
      );
    }

    res.json(saved);
  } catch (err) {
    if (err.code === "FORBIDDEN") {
      return res.status(403).json({ message: err.message });
    }
    if (err.code === "RATE_LIMITED") {
      return res.status(429).json({ message: err.message });
    }
    if (err.message && err.message.includes("already taken")) {
      return res.status(409).json({ message: err.message });
    }
    if (err.message && err.message.includes("Subdomain format is invalid")) {
      return res.status(400).json({ message: err.message });
    }
    if (err.message && err.message.includes("quota")) {
      return res.status(409).json({ message: err.message });
    }
    logger.error(`storeRoute POST /: ${err.message}`);
    res.status(500).json({ message: err.message });
  }
});

// DUPLICATE store
router.post(
  "/:id/duplicate",
  loadUser, resolveAuthorizationContext, requireStoreAccess(),
  hasAnyPermission(["online store", "create"], ["stores", "create"]),
  async (req, res) => {
  try {
    const original = await Store.findById(req.params.id);
    if (!original) return res.status(404).json({ message: "Store not found" });

    // Build a unique name for the duplicate: "Original - Copy" or add (n)
    const baseName = `${original.name} - Copy`;
    let name = baseName;
    let counter = 1;

    // Ensure uniqueness (case-insensitive)
    while (await Store.findOne({ name: { $regex: new RegExp(`^${escapeRegex(name)}$`, "i") } })) {
      counter += 1;
      name = `${baseName} (${counter})`;
    }

    const obj = original.toObject({ flattenMaps: true });
    delete obj._id;
    // set new name and timestamps
    obj.name = name;
    obj.createdAt = new Date();
    obj.updatedAt = new Date();

    const duplicated = new Store(obj);
    const saved = await duplicated.save();
    res.json(saved);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// UPDATE store — avec vérification d'unicité du nom (sauf lui-même)
router.put("/:id", loadUser, resolveAuthorizationContext, requireStoreAccess(), async (req, res) => {
  try {
    const allowedFields = ["name", "address", "category", "logo", "reviewSettings", "billingCycle", "subdomain", "domain", "customDomain"];
    const storePayload = {};
    for (const field of allowedFields) {
      if (Object.prototype.hasOwnProperty.call(req.body, field)) {
        storePayload[field] = req.body[field];
      }
    }

    if (storePayload.name && String(storePayload.name).trim()) {
      const existing = await Store.findOne({
        _id: { $ne: req.params.id },
        name: { $regex: new RegExp(`^${escapeRegex(String(storePayload.name).trim())}$`, "i") },
      });

      if (existing) {
        return res.status(400).json({
          message: `A store named "${storePayload.name}" already exists. Please choose a different name.`,
        });
      }
    }

    if (Object.prototype.hasOwnProperty.call(storePayload, "category")) {
      storePayload.category = String(storePayload.category || "").trim() || undefined;
    }

    const updated = await Store.findByIdAndUpdate(req.params.id, storePayload, { new: true });

    emitEvent("store.updated", {
      storeId: updated._id,
      actorId: req.userId,
      entityId: updated._id,
      metadata: { storeName: updated.name },
      actionUrl: `/stores/${updated._id}`,
    });

    res.json(updated);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// UPDATE store settings (per-store settings configuration)
// Strict whitelist — an API must never copy req.body straight into the model
// (mass assignment would expose status/plan/subscription/owner fields).
const validateReviewSettingsInput = (input) => {
  const review = {};
  if (!input || typeof input !== "object" || Array.isArray(input)) return review;
  for (const key of ["enabled", "requireApproval", "verifiedOwnersOnly", "allowGuestReviews", "showRating", "showCount"]) {
    if (typeof input[key] === "boolean") review[key] = input[key];
  }
  if (input.maxImages !== undefined) {
    const maxImages = Number(input.maxImages);
    if (Number.isFinite(maxImages) && maxImages >= 0) review.maxImages = Math.floor(maxImages);
  }
  return review;
};

const SETTINGS_GROUP_BUILDERS = {
  general: (body = {}) => {
    const payload = {};
    if (typeof body.name === "string" && body.name.trim()) payload.name = body.name.trim().slice(0, 200);
    if (typeof body.address === "string") payload.address = body.address.trim().slice(0, 500);
    if (typeof body.logo === "string") payload.logo = body.logo.trim();
    if (typeof body.category === "string") payload.category = body.category.trim();
    return payload;
  },
  reviews: (body = {}) => {
    const payload = {};
    const review = validateReviewSettingsInput(body.reviewSettings);
    if (Object.keys(review).length > 0) payload.reviewSettings = review;
    return payload;
  },
};

const SETTINGS_ALLOWED_GROUPS = Object.keys(SETTINGS_GROUP_BUILDERS);

const buildSettingsPayload = (body = {}) => {
  const combined = { ...SETTINGS_GROUP_BUILDERS.general(body), ...SETTINGS_GROUP_BUILDERS.reviews(body) };
  return combined;
};

router.put(
  "/:id/settings/:group",
  loadUser, resolveAuthorizationContext, requireStoreAccess(),
  hasAnyPermission(["online store", "update"], ["store", "update"], ["stores", "update"]),
  async (req, res) => {
    try {
      const builder = SETTINGS_GROUP_BUILDERS[req.params.group];
      if (!builder) {
        return res.status(404).json({ message: `Unknown settings group '${req.params.group}'. Available: ${SETTINGS_ALLOWED_GROUPS.join(", ")}` });
      }
      const store = await Store.findById(req.params.id);
      if (!store) {
        return res.status(404).json({ message: "Store not found" });
      }

      const storePayload = builder(req.body || {});
      if (Object.keys(storePayload).length === 0) {
        return res.status(400).json({ message: `No valid '${req.params.group}' settings provided` });
      }

      const updated = await Store.findByIdAndUpdate(req.params.id, storePayload, { new: true, runValidators: true });

      AuditService.logAction({
        actorType: req.user?.isSuperAdmin ? "platform_admin" : "store_owner",
        actorId: req.userId,
        module: "store",
        action: `settings.${req.params.group}`,
        summary: `Settings group "${req.params.group}" updated for store "${updated.name}"`,
        entityType: "store",
        entityId: updated._id,
        storeId: updated._id,
        severity: req.params.group === "reviews" ? "low" : "medium",
        changes: Object.keys(storePayload),
        requestId: req.requestId,
      }).catch(() => {});

      res.json(updated);
    } catch (err) {
      res.status(400).json({ message: err.message });
    }
  }
);

router.put(
  "/:id/settings",
  loadUser, resolveAuthorizationContext, requireStoreAccess(),
  hasAnyPermission(["online store", "update"], ["store", "update"], ["stores", "update"]),
  async (req, res) => {
    try {
      const store = await Store.findById(req.params.id);
      if (!store) {
        return res.status(404).json({ message: "Store not found" });
      }

      const storePayload = buildSettingsPayload(req.body);
      if (Object.keys(storePayload).length === 0) {
        return res.status(400).json({
          message: `No valid settings provided. Allowed groups: ${SETTINGS_ALLOWED_GROUPS.join(", ")}`,
        });
      }

      const updated = await Store.findByIdAndUpdate(
        req.params.id,
        storePayload,
        { new: true, runValidators: true }
      );

      AuditService.logAction({
        actorType: req.user?.isSuperAdmin ? "platform_admin" : "store_owner",
        actorId: req.userId,
        module: "store",
        action: "settings.updated",
        summary: `Settings updated for store "${updated.name}"`,
        entityType: "store",
        entityId: updated._id,
        storeId: updated._id,
        severity: "medium",
        changes: Object.keys(storePayload),
        requestId: req.requestId,
      }).catch(() => {});

      res.json(updated);
    } catch (err) {
      res.status(400).json({ message: err.message });
    }
  }
);

// UPDATE store active status (archive/unarchive)
router.put(
  "/:id/status",
  loadUser, resolveAuthorizationContext, requireStoreAccess(),
  hasAnyPermission(["online store", "update"], ["store", "update"], ["stores", "update"]),
  async (req, res) => {
    try {
      const { isActive } = req.body;
      const status = isActive ? "active" : "suspended";
      const updated = await Store.findByIdAndUpdate(
        req.params.id,
        { status },
        { new: true }
      );
      if (!updated) {
        return res.status(404).json({ message: "Store not found" });
      }

      emitEvent(isActive ? "store.activated" : "store.suspended", {
        storeId: updated._id,
        actorId: req.userId,
        entityId: updated._id,
        metadata: { storeName: updated.name },
        actionUrl: `/stores/${updated._id}`,
      });

      AuditService.logAction({
        actorType: req.user?.isSuperAdmin ? "platform_admin" : "store_owner",
        actorId: req.userId,
        module: "store",
        action: isActive ? "activate" : "suspend",
        summary: `Store "${updated.name}" ${isActive ? "activated" : "suspended"}`,
        entityType: "store",
        entityId: updated._id,
        storeId: updated._id,
        severity: isActive ? "low" : "high",
        requestId: req.requestId,
      }).catch(() => {});

      res.json(updated);
    } catch (err) {
      res.status(500).json({ message: err.message });
    }
  }
);

// DELETE store (soft-delete)
router.delete(
  "/:id",
  loadUser, resolveAuthorizationContext, requireStoreAccess(),
  hasAnyPermission(getCodes("Platform Store", ["delete"])),
  async (req, res) => {
  try {
    const store = await Store.findById(req.params.id).select("name deletedAt status");
    if (!store) return res.status(404).json({ message: "Store not found" });
    if (store.deletedAt) return res.status(409).json({ message: "Store already deleted" });

    await Store.findByIdAndUpdate(req.params.id, {
      deletedAt: new Date(),
      deletedBy: req.userId,
      status: "deleted",
    });

    await AuditService.logAction({
      actorType: req.user.isSuperAdmin ? "platform_admin" : "store_owner",
      actorId: req.userId,
      module: "Platform Store",
      action: "store.deleted",
      entityType: "store",
      entityId: req.params.id,
      status: "success",
      severity: "high",
      storeId: req.params.id,
      newValue: { storeName: store.name, deletedAt: new Date() },
      summary: `Store "${store.name}" soft-deleted by ${req.user.email || req.userId}`,
    });

    emitEvent("store.deleted", {
      actorId: req.userId,
      entityId: req.params.id,
      metadata: { storeName: store.name },
    });

    res.json({ message: "Store scheduled for deletion", deletedAt: new Date() });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// RESTORE store from soft-delete
router.post(
  "/:id/restore",
  loadUser, resolveAuthorizationContext, requireStoreAccess(),
  hasAnyPermission(getCodes("Platform Store", ["delete"])),
  async (req, res) => {
  try {
    const store = await Store.findById(req.params.id).select("name deletedAt status");
    if (!store) return res.status(404).json({ message: "Store not found" });
    if (!store.deletedAt) return res.status(409).json({ message: "Store is not deleted" });

    const previousStatus = store.status === "suspended" ? "suspended" : "inactive";

    await Store.findByIdAndUpdate(req.params.id, {
      deletedAt: null,
      deletedBy: null,
      status: previousStatus,
    });

    await AuditService.logAction({
      actorType: req.user.isSuperAdmin ? "platform_admin" : "store_owner",
      actorId: req.userId,
      module: "Platform Store",
      action: "store.restored",
      entityType: "store",
      entityId: req.params.id,
      status: "success",
      severity: "medium",
      storeId: req.params.id,
      oldValue: { status: "deleted", deletedAt: store.deletedAt },
      newValue: { status: previousStatus, deletedAt: null },
      summary: `Store "${store.name}" restored from soft-delete by ${req.user.email || req.userId}`,
    });

    res.json({ message: "Store restored successfully", status: previousStatus });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// NOTE: route POST "/:id/select" removed — selecting active store
// should be handled client-side via user preferences or replaced by
// a dedicated user endpoint. Removed to avoid selecting stores from
// the public store detail page.

// --- Update a domain scoped to a store (matches frontend /stores/:id/domains/:domainId) ---
router.put(
  "/:id/domains/:domainId",
  loadUser, resolveAuthorizationContext, requireStoreAccess(),
  hasAnyPermission(["online store", "update"], ["store", "update"], ["stores", "update"]),
  async (req, res) => {
  try {
    // Only domain/isPrimary are client-settable. verified/ssl/dns*/ssl* are
    // derived exclusively by DomainVerificationService.
    const { domain, isPrimary } = req.body;
    const id = req.params.domainId;
    const storeId = req.params.id;

    const existingDoc = await StoreDomain.findById(id);
    if (!existingDoc) return res.status(404).json({ message: "Domain not found" });

    // Ensure domain belongs to the scoped store
    if (existingDoc.storeId && existingDoc.storeId.toString() !== storeId) {
      return res.status(403).json({ message: "Domain does not belong to this store" });
    }

    if (domain && domain.trim()) {
      if (!isValidDomain(domain)) {
        return res.status(400).json({ message: "Domain format is invalid" });
      }

      try {
        DomainVerificationService.assertDomainEligible(domain);
      } catch (eligibilityError) {
        return res.status(400).json({ message: eligibilityError.message });
      }

      const conflict = await StoreDomain.findOne({
        _id: { $ne: id },
        domain: { $regex: new RegExp(`^${escapeRegex(domain.trim())}$`, "i") },
      });
      if (conflict) return res.status(400).json({ message: `Domain '${domain}' already exists` });
    }

    if (isPrimary) {
      await StoreDomain.updateMany({ storeId }, { $set: { isPrimary: false } });
    }

    const updates = {};
    if (domain) updates.domain = domain.trim().toLowerCase();
    if (typeof isPrimary !== "undefined") updates.isPrimary = !!isPrimary;

    // If the hostname changed, previous DNS/SSL results are stale.
    const updated = await StoreDomain.findByIdAndUpdate(
      id,
      { ...updates, ...(updates.domain ? { dnsStatus: "pending", sslStatus: "pending", verified: false, ssl: false, resolvedIps: [], lastError: null } : {}) },
      { new: true }
    );

    if (updates.domain) {
      DomainVerificationService.verifyStoreDomainDocument(updated).catch((err) => {
        console.error("Background domain verification failed:", err.message);
      });
    }

    res.json(updated);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// --- Delete a domain scoped to a store (matches frontend /stores/:id/domains/:domainId) ---
router.delete(
  "/:id/domains/:domainId",
  loadUser, resolveAuthorizationContext, requireStoreAccess(),
  hasAnyPermission(["online store", "delete"], ["store", "delete"], ["stores", "delete"]),
  async (req, res) => {
  try {
    const existing = await StoreDomain.findById(req.params.domainId);
    if (!existing) return res.status(404).json({ message: "Domain not found" });

    if (existing.storeId && existing.storeId.toString() !== req.params.id) {
      return res.status(403).json({ message: "Domain does not belong to this store" });
    }

    await StoreDomain.findByIdAndDelete(req.params.domainId);
    try {
      if (existing.storeId) {
        await StoreUsageService.decrementUsage(existing.storeId, "domains", 1);
      }
    } catch (err) {
      console.error("Failed to decrement domain usage for store:", err.message);
    }
    res.json({ message: "Domain deleted successfully" });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// --- Store detail action endpoints ---

// Change store owner
router.put("/:id/owner", loadUser, resolveAuthorizationContext, requireStoreAccess(), hasAnyPermission(["online store", "update"], ["store", "update"], ["stores", "update"]), async (req, res) => {
  try {
    const { ownerId } = req.body;
    if (!ownerId) {
      return res.status(400).json({ message: "ownerId is required" });
    }
    if (!mongoose.Types.ObjectId.isValid(ownerId)) {
      return res.status(400).json({ message: "Invalid ownerId" });
    }

    const owner = await User.findById(ownerId).lean();
    if (!owner) {
      return res.status(404).json({ message: "Owner user not found" });
    }

    const updated = await Store.findByIdAndUpdate(req.params.id, { ownerId }, { new: true });
    if (!updated) {
      return res.status(404).json({ message: "Store not found" });
    }

    const existingMembership = await UserStore.findOne({ userId: ownerId, storeId: req.params.id }).lean();
    if (!existingMembership) {
      await UserStore.create({ userId: ownerId, storeId: req.params.id });
    }

    await AuditService.logAction({
      actorType: req.user?.isSuperAdmin ? "platform_admin" : "store_owner",
      actorId: req.userId,
      module: "store",
      action: "change_owner",
      summary: `Store "${updated.name}" owner changed to ${owner.email}`,
      entityType: "store",
      entityId: updated._id,
      storeId: updated._id,
      severity: "high",
      requestId: req.requestId,
      ip: req.headers["x-forwarded-for"]?.split(",")[0] || req.socket?.remoteAddress,
      userAgent: req.headers["user-agent"],
    }).catch(() => {});

    res.json(updated);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// Export store logs
router.get("/:id/logs/export", loadUser, resolveAuthorizationContext, requireStoreAccess(), hasAnyPermission(["online store", "view"], ["store", "view"], ["stores", "view"]), async (req, res) => {
  try {
    const filter = buildAuditQuery(req.params.id, req.query);
    const logs = await AuditLog.find(filter).sort({ createdAt: -1 }).limit(5000).lean();

    const cell = (value) => `"${String(value ?? "").replace(/"/g, '""').slice(0, 500)}"`;
    const csv = [
      "timestamp,actor_type,actor_name,module,action,entity_type,entity_id,severity,status,ip,request_id,summary",
      ...logs.map((log) =>
        [
          log.createdAt ? new Date(log.createdAt).toISOString() : "",
          log.actorType || "",
          log.actorNameSnapshot || "",
          log.module || "",
          log.action || "",
          log.entityType || "",
          log.entityId || "",
          log.severity || "",
          log.status || "",
          log.ip || log.sourceIp || log.ipAddress || "",
          log.requestId || "",
          log.summary || "",
        ]
          .map(cell)
          .join(",")
      ),
    ].join("\n");

    res.setHeader("Content-Type", "text/csv");
    res.setHeader("Content-Disposition", `attachment; filename="store-${req.params.id}-audit.csv"`);
    res.send(csv);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// GET technical logs for a store (Logs ≠ Audit — machine events only)
// Sources actually persisted today: outbound webhook deliveries, backup jobs,
// export jobs and auth-related audit entries. API/System request logs require
// request instrumentation that is not built yet.
router.get("/:id/system-logs", loadUser, resolveAuthorizationContext, requireStoreAccess(), hasAnyPermission(["online store", "view"], ["store", "view"], ["stores", "view"]), async (req, res) => {
  try {
    const storeId = req.params.id;
    const service = ["all", "webhooks", "jobs", "auth"].includes(req.query.service) ? req.query.service : "all";
    const limit = Math.min(100, Math.max(1, Number(req.query.limit) || 60));

    const entries = [];
    const levelFrom = (status) =>
      ["failed", "error"].includes(status) ? "error" : ["retrying", "pending", "processing", "queued"].includes(status) ? "warn" : "info";

    const tasks = [];

    if (service === "all" || service === "webhooks") {
      tasks.push(
        WebhookLog.find({ storeId }).sort({ createdAt: -1 }).limit(limit).lean().then((rows) => {
          for (const row of rows) {
            entries.push({
              _id: `whl-${row._id}`,
              ts: row.createdAt,
              level: levelFrom(row.status),
              service: `webhook:${row.provider}`,
              message: `${row.direction || "outbound"} ${row.event}${row.httpStatus ? ` -> HTTP ${row.httpStatus}` : ""}${row.durationMs ? ` (${row.durationMs}ms)` : ""}`,
              requestId: row.requestId || null,
              meta: row.errorMessage || null,
            });
          }
        })
      );
    }

    if (service === "all" || service === "jobs") {
      tasks.push(
        BackupJob.find({ storeId }).sort({ createdAt: -1 }).limit(Math.ceil(limit / 2)).lean().then((rows) => {
          for (const row of rows) {
            entries.push({
              _id: `bkj-${row._id}`,
              ts: row.createdAt,
              level: levelFrom(row.status),
              service: "job:backup",
              message: `Manual/scheduled backup ${row.type} -> ${row.status}${row.progress !== undefined && row.status === "running" ? ` (${row.progress}%)` : ""}`,
              requestId: null,
              meta: row.error || null,
            });
          }
        }),
        ExportJob.find({ "filters.storeId": new mongoose.Types.ObjectId(storeId) })
          .sort({ createdAt: -1 })
          .limit(Math.ceil(limit / 2))
          .lean()
          .then((rows) => {
            for (const row of rows) {
              entries.push({
                _id: `exj-${row._id}`,
                ts: row.createdAt,
                level: levelFrom(row.status),
                service: "job:export",
                message: `${row.source || "audit"} export (${row.format || "csv"}) -> ${row.status}`,
                requestId: null,
                meta: null,
              });
            }
          })
      );
    }

    if (service === "all" || service === "auth") {
      tasks.push(
        AuditLog.find({ storeId, module: "auth" }).sort({ createdAt: -1 }).limit(limit).lean().then((rows) => {
          for (const row of rows) {
            entries.push({
              _id: `aut-${row._id}`,
              ts: row.createdAt,
              level: row.status === "failed" ? "error" : "info",
              service: "auth",
              message: `${row.action}: ${row.summary}`,
              requestId: row.requestId || null,
              meta: null,
            });
          }
        })
      );
    }

    await Promise.all(tasks);

    entries.sort((a, b) => new Date(b.ts) - new Date(a.ts));
    res.json({ logs: entries.slice(0, limit) });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// Attaches an already-registered user to a store as staff, after the checks
// listed in the SO staff-invite ticket: soft-deleted / suspended / superadmin
// accounts are rejected, an existing membership on this store is rejected
// (no duplicate), otherwise the user's storeIds/role are extended in place.
// There's no separate per-store "pending invitation" state modeled in this
// codebase (UserStore is a bare junction table, no role/status fields) — so
// unlike a brand-new user, an existing user is attached immediately rather
// than going through the password-email step below.
const attachExistingUserToStore = async ({ req, res, existingUser, storeId, roleId }) => {
  if (existingUser.deletedAt) {
    return res.status(409).json({ message: "This account has been deleted and cannot be re-added. Contact support." });
  }
  if (["Suspended", "Blocked", "Archived", "Deleted"].includes(existingUser.status)) {
    return res.status(409).json({ message: "This account is suspended and cannot be added as staff." });
  }
  if (existingUser.isSuperAdmin) {
    return res.status(400).json({ message: "Cannot add a platform superadmin as store staff through this flow." });
  }

  const alreadyMember = (existingUser.storeIds || []).some((id) => String(id) === String(storeId));
  if (alreadyMember) {
    return res.status(409).json({ message: "This user is already staff on this store." });
  }

  existingUser.storeIds = [...(existingUser.storeIds || []), storeId];
  const roleIdStr = String(roleId);
  if (!(existingUser.role || []).some((r) => String(r) === roleIdStr)) {
    existingUser.role = [...(existingUser.role || []), roleId];
  }
  await existingUser.save();

  const existingMembership = await UserStore.findOne({ userId: existingUser._id, storeId });
  if (!existingMembership) {
    await UserStore.create({ userId: existingUser._id, storeId });
  }

  await StoreUsageService.incrementUsage(storeId, "admins", 1);

  AuditService.logAction({
    actorType: req.user?.isSuperAdmin ? "platform_admin" : "store_owner",
    actorId: req.userId,
    module: "store",
    action: "admin_attached_existing_user",
    summary: `Existing user "${existingUser.email}" attached to store as staff`,
    entityType: "user",
    entityId: existingUser._id,
    storeId,
  });

  return res.status(200).json({
    message: "Existing user added as staff on this store",
    data: {
      _id: existingUser._id,
      name: existingUser.name,
      email: existingUser.email,
      role: existingUser.role,
      status: existingUser.status,
      emailVerificationWarning: !existingUser.emailVerified,
    },
  });
};

// GET roles assignable to staff on this store (used by the Add admin form)
router.get("/:id/roles", loadUser, resolveAuthorizationContext, requireStoreAccess(), hasAnyPermission(["online store", "view"], ["store", "view"], ["stores", "view"]), async (req, res) => {
  try {
    const roles = await roleService.getRolesByStore(req.params.id);
    res.json(roles);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// Add admin to store
router.post("/:id/admins", loadUser, resolveAuthorizationContext, requireStoreAccess(), hasAnyPermission(["online store", "create"], ["store", "create"], ["stores", "create"]), async (req, res) => {
  try {
    const { name, email, phone, role } = req.body;
    if (!email || !role) {
      return res.status(400).json({ message: "email and role are required" });
    }

    if (!mongoose.Types.ObjectId.isValid(role)) {
      return res.status(400).json({ message: "Invalid role id" });
    }
    const resolvedRole = await roleService.getRoleByIdForStore(role, req.params.id);
    if (!resolvedRole) {
      return res.status(400).json({ message: "Role does not belong to this store" });
    }

    const existingUser = await User.findOne({ email });
    if (existingUser) {
      return await attachExistingUserToStore({
        req,
        res,
        existingUser,
        storeId: req.params.id,
        roleId: resolvedRole._id,
      });
    }

    // New user: a real, usable password is generated server-side and emailed
    // — the client never chooses/sees it, and it's never echoed in the
    // response (mirrors the working POST /users/staff flow in userService.addStaff).
    const password = generatePassword();
    const bcrypt = require("bcryptjs");
    const hashedPassword = await bcrypt.hash(password, 10);
    const user = await User.create({
      name,
      email,
      password: hashedPassword,
      phone,
      userType: "staff",
      role: [resolvedRole._id],
      storeIds: [req.params.id],
      status: "Active",
    });

    await UserStore.create({ userId: user._id, storeId: req.params.id, roleId: resolvedRole._id });

    await StoreUsageService.incrementUsage(req.params.id, "admins", 1);

    let emailSent = true;
    try {
      await sendStaffWelcomeEmail(user.email, {
        name: user.name,
        password,
        loginUrl: `${process.env.FRONTEND_URL}/login`,
      });
    } catch (mailError) {
      emailSent = false;
    }

    AuditService.logAction({
      actorType: req.user?.isSuperAdmin ? "platform_admin" : "store_owner",
      actorId: req.userId,
      module: "store",
      action: "admin_added",
      summary: `Admin "${user.email}" added to store`,
      entityType: "user",
      entityId: user._id,
      storeId: req.params.id,
    });

    res.status(201).json({
      message: emailSent
        ? "Admin added successfully. The password has been sent by email."
        : "Admin added, but the welcome email could not be sent.",
      emailSent,
      data: {
        _id: user._id,
        name: user.name,
        email: user.email,
        phone: user.phone,
        role: user.role,
        status: user.status,
        createdAt: user.createdAt,
      },
    });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// Update staff role for a store
router.put("/:storeId/staff/:userId/role", loadUser, resolveAuthorizationContext, requireStoreAccess(), hasAnyPermission(["online store", "update"], ["store", "update"], ["stores", "update"]), async (req, res) => {
  try {
    const { storeId, userId } = req.params;
    const { roleId } = req.body;

    if (!mongoose.Types.ObjectId.isValid(roleId)) {
      return res.status(400).json({ message: "Valid roleId is required" });
    }

    const role = await Role.findOne({
      _id: roleId,
      $or: [{ storeId }, { scope: "platform", slug: { $in: ["store-owner"] } }],
    });
    if (!role) {
      return res.status(400).json({ message: "Role does not belong to this store" });
    }

    const membership = await UserStore.findOneAndUpdate(
      { userId, storeId },
      { roleId: role._id },
      { new: true }
    );

    if (!membership) {
      return res.status(404).json({ message: "Staff member not found in this store" });
    }

    res.json({ message: "Role updated successfully", data: membership });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// Update staff status for a store
router.patch("/:id/staff/:userId/status", loadUser, resolveAuthorizationContext, requireStoreAccess(), hasAnyPermission(["online store", "update"], ["store", "update"], ["stores", "update"]), async (req, res) => {
  try {
    const { storeId, userId } = req.params;
    const { status } = req.body;

    if (!["active", "invited", "suspended"].includes(status)) {
      return res.status(400).json({ message: "Invalid staff status" });
    }

    const membership = await UserStore.findOneAndUpdate(
      { userId, storeId },
      { status },
      { new: true }
    );

    if (!membership) {
      return res.status(404).json({ message: "Staff member not found in this store" });
    }

    res.json({ message: "Staff status updated successfully", data: membership });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// Remove staff from a store
router.delete("/:id/staff/:userId", loadUser, resolveAuthorizationContext, requireStoreAccess(), hasAnyPermission(["online store", "delete"], ["store", "delete"], ["stores", "delete"]), async (req, res) => {
  try {
    const { storeId, userId } = req.params;

    const membership = await UserStore.findOneAndDelete({
      userId,
      storeId,
    });

    if (!membership) {
      return res.status(404).json({ message: "Staff member not found in this store" });
    }

    await AuditService.logAction({
      actorType: req.user?.isSuperAdmin ? "platform_admin" : "store_owner",
      actorId: req.userId,
      module: "store",
      action: "staff.removed",
      entityType: "user_store",
      entityId: membership._id,
      storeId,
      severity: "medium",
      requestId: req.requestId,
      summary: `Staff ${userId} removed from store ${storeId}`,
    }).catch(() => {});

    res.json({ message: "Staff removed successfully" });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// Store maintenance ops (clear cache / restart workers / rebuild indexes /
// flush queues) are PLATFORM operations and intentionally not exposed here.

// API keys CRUD
router.post("/:id/api-keys", loadUser, resolveAuthorizationContext, requireStoreAccess(), hasAnyPermission(["online store", "create"], ["store", "create"], ["stores", "create"]), async (req, res) => {
  try {
    const created = await ApiKeyService.create(req.params.id, req.body, req.userId);
    // `secret` is returned exactly once, here.
    res.status(201).json(created);
  } catch (err) {
    if (err.name === "ValidationError") return res.status(400).json({ message: err.message });
    res.status(500).json({ message: err.message });
  }
});

router.post("/:id/api-keys/:keyId/regenerate", loadUser, resolveAuthorizationContext, requireStoreAccess(), hasAnyPermission(["online store", "update"], ["store", "update"], ["stores", "update"]), async (req, res) => {
  try {
    const rotated = await ApiKeyService.rotate(req.params.id, req.params.keyId, req.userId);
    // New secret shown exactly once.
    res.json(rotated);
  } catch (err) {
    if (err.name === "ValidationError") return res.status(400).json({ message: err.message });
    if (err.name === "NotFound") return res.status(404).json({ message: err.message });
    res.status(500).json({ message: err.message });
  }
});

router.post("/:id/api-keys/:keyId/revoke", loadUser, resolveAuthorizationContext, requireStoreAccess(), hasAnyPermission(["online store", "delete"], ["store", "delete"], ["stores", "delete"]), async (req, res) => {
  try {
    const revoked = await ApiKeyService.revoke(req.params.id, req.params.keyId, req.userId);
    res.json(revoked);
  } catch (err) {
    if (err.name === "NotFound") return res.status(404).json({ message: err.message });
    res.status(500).json({ message: err.message });
  }
});

router.patch("/:id/api-keys/:keyId/expiry", loadUser, resolveAuthorizationContext, requireStoreAccess(), hasAnyPermission(["online store", "update"], ["store", "update"], ["stores", "update"]), async (req, res) => {
  try {
    const { expiresAt } = req.body || {};
    const updated = await ApiKeyService.setExpiry(req.params.id, req.params.keyId, expiresAt || null, req.userId);
    res.json(updated);
  } catch (err) {
    if (err.name === "ValidationError") return res.status(400).json({ message: err.message });
    if (err.name === "NotFound") return res.status(404).json({ message: err.message });
    res.status(500).json({ message: err.message });
  }
});

// Webhooks CRUD
router.post("/:id/webhooks", loadUser, resolveAuthorizationContext, requireStoreAccess(), hasAnyPermission(["online store", "create"], ["store", "create"], ["stores", "create"]), async (req, res) => {
  try {
    const created = await StoreWebhookService.create(req.params.id, req.body, req.userId);
    // Signing secret shown exactly once, here.
    res.status(201).json(created);
  } catch (err) {
    if (err.name === "ValidationError") return res.status(400).json({ message: err.message });
    res.status(500).json({ message: err.message });
  }
});

router.get("/:id/webhooks/:webhookId/deliveries", loadUser, resolveAuthorizationContext, requireStoreAccess(), hasAnyPermission(["online store", "view"], ["store", "view"], ["stores", "view"]), async (req, res) => {
  try {
    const deliveries = await StoreWebhookService.listDeliveries(req.params.id, req.params.webhookId, req.query.limit);
    res.json(deliveries);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

router.post("/:id/webhooks/:webhookId/test", loadUser, resolveAuthorizationContext, requireStoreAccess(), hasAnyPermission(["online store", "update"], ["store", "update"], ["stores", "update"]), async (req, res) => {
  try {
    const result = await StoreWebhookService.test(req.params.id, req.params.webhookId, req.userId);
    if (!result.ok) return res.status(502).json({ message: "Test delivery failed — check delivery history for details" });
    res.json({ success: true, message: "Test delivered successfully" });
  } catch (err) {
    if (err.name === "NotFound") return res.status(404).json({ message: err.message });
    res.status(500).json({ message: err.message });
  }
});

router.post("/:id/webhooks/:webhookId/status", loadUser, resolveAuthorizationContext, requireStoreAccess(), hasAnyPermission(["online store", "update"], ["store", "update"], ["stores", "update"]), async (req, res) => {
  try {
    const { status } = req.body || {};
    const updated = await StoreWebhookService.setStatus(req.params.id, req.params.webhookId, status);
    res.json(updated);
  } catch (err) {
    if (err.name === "ValidationError") return res.status(400).json({ message: err.message });
    if (err.name === "NotFound") return res.status(404).json({ message: err.message });
    res.status(500).json({ message: err.message });
  }
});

router.post("/:id/webhooks/:webhookId/rotate-secret", loadUser, resolveAuthorizationContext, requireStoreAccess(), hasAnyPermission(["online store", "update"], ["store", "update"], ["stores", "update"]), async (req, res) => {
  try {
    const rotated = await StoreWebhookService.rotateSecret(req.params.id, req.params.webhookId, req.userId);
    res.json(rotated);
  } catch (err) {
    if (err.name === "NotFound") return res.status(404).json({ message: err.message });
    res.status(500).json({ message: err.message });
  }
});

router.post("/:id/webhooks/:webhookId/deliveries/:deliveryId/retry", loadUser, resolveAuthorizationContext, requireStoreAccess(), hasAnyPermission(["online store", "update"], ["store", "update"], ["stores", "update"]), async (req, res) => {
  try {
    const updated = await StoreWebhookService.retry(req.params.id, req.params.webhookId, req.params.deliveryId);
    res.json(updated);
  } catch (err) {
    if (err.name === "NotFound") return res.status(404).json({ message: err.message });
    res.status(500).json({ message: err.message });
  }
});

router.delete("/:id/webhooks/:webhookId", loadUser, resolveAuthorizationContext, requireStoreAccess(), hasAnyPermission(["online store", "delete"], ["store", "delete"], ["stores", "delete"]), async (req, res) => {
  try {
    const result = await StoreWebhookService.remove(req.params.id, req.params.webhookId);
    res.json(result);
  } catch (err) {
    if (err.name === "NotFound") return res.status(404).json({ message: err.message });
    res.status(500).json({ message: err.message });
  }
});

module.exports = router;


