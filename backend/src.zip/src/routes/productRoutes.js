const express = require("express");
const { getCode, getCodes } = require("../config/rbac/permissionCodes");
const router = express.Router();
const {
  addProduct,
  addAllProducts,
  getAllProducts,
  getShowingProducts,
  getProductById,
  getProductsByIds,
  getRelatedProducts,
  updateProduct,
  updateManyProducts,
  updateStatus,
  deleteProduct,
  deleteManyProducts,
  searchProducts,
  getShowingStoreProducts,
} = require("../controller/productController");

//add a product
router.post("/add", addProduct);

//import products from a file (upsert by SKU, never deletes)
router.post("/import", addAllProducts);

//legacy alias for the import endpoint
router.post("/all", addAllProducts);

//get a product
router.post("/:id", getProductById);

//get showing products only
router.get("/show", getShowingProducts);

//get showing products in store
router.get("/store", getShowingStoreProducts);

//get products by ids (for recently viewed, etc.)
router.get("/by-ids", getProductsByIds);

//get related products
router.get("/related", getRelatedProducts);

//search products by productName, productCategory and status
router.get("/search", searchProducts);

//get all products
router.get("/", getAllProducts);

//update a product
router.patch("/:id", updateProduct);

//update many products
router.patch("/update/many", updateManyProducts);

//update a product status
router.put("/status/:id", updateStatus);

//delete a product
router.delete("/:id", deleteProduct);

//delete many product
router.patch("/delete/many", deleteManyProducts);

module.exports = router;
