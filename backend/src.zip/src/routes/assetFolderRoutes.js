const express = require("express");
const { getCode, getCodes } = require("../config/rbac/permissionCodes");
const { isAuth, loadUser, requirePermission } = require("../middleware/auth");
const resolveStoreId = require("../middleware/resolveStoreId");
const assetFolderController = require("../controller/assetFolderController");

const router = express.Router();
router.use(isAuth);
router.use(loadUser);
router.use(resolveStoreId);

router.get("/folders", requirePermission(getCode("Media", "view")), assetFolderController.listFolders);
router.post("/folders", requirePermission(getCode("Media", "create")), assetFolderController.createFolder);
router.delete("/folders/:folderId", requirePermission(getCode("Media", "delete")), assetFolderController.deleteFolder);

module.exports = router;
