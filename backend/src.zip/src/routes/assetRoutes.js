const express = require("express");
const { getCode, getCodes } = require("../config/rbac/permissionCodes");
const multer = require("multer");
const { isAuth, loadUser, requirePermission } = require("../middleware/auth");
const resolveStoreId = require("../middleware/resolveStoreId");
const assetController = require("../controller/assetController");

const router = express.Router();
const upload = multer({ storage: multer.memoryStorage() });

router.use(isAuth);
router.use(loadUser);
router.use(resolveStoreId);

router.post("/upload", requirePermission(getCode("Media", "upload")), upload.single("file"), assetController.uploadAsset);
router.get("/", requirePermission(getCode("Media", "view")), assetController.listAssets);
router.delete("/:assetId", requirePermission(getCode("Media", "delete")), assetController.deleteAsset);

module.exports = router;
