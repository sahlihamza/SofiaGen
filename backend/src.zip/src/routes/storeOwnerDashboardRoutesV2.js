const express = require("express");
const { getCode, getCodes } = require("../config/rbac/permissionCodes");
const router = express.Router();
const { getStoreOwnerDashboardV2, getStoreOwnerDashboardWidget, refreshStoreOwnerDashboard } = require("../controller/storeOwnerDashboardControllerV2");

router.get("/", getStoreOwnerDashboardV2);
router.get("/widget/:widget", getStoreOwnerDashboardWidget);
router.post("/refresh", refreshStoreOwnerDashboard);

module.exports = router;
