const express = require("express");
const router = express.Router();

/**
 * GET /api/public/stats
 * Stats non sensibles affichés sur le site vitrine.
 * { activeStores, totalOrders, integratedCarriers }
 */
router.get("/stats", async (req, res) => {
  try {
    // Utilisation de counts minimaux via les modèles existants mais sans auth.
    // En cas d'erreur (DB down, etc.), on renvoie des valeurs par défaut raisonnables
    // plutôt que de planter la page.
    let activeStores = 0;
    let totalOrders = 0;
    let integratedCarriers = 0;

    try {
      const Store = require("../models/Store");
      const Order = require("../models/Order");
      activeStores = await Store.countDocuments({});
      totalOrders = await Order.countDocuments({});
    } catch (dbErr) {
      console.warn("Public stats DB error:", dbErr.message);
    }
    // CarrierProvider model not yet shipped (SFG-154 in progress)
    // -> hard-coded carrier list, will move to DB once CarrierProvider lands
    integratedCarriers = 4;

    res.json({
      activeStores,
      totalOrders,
      integratedCarriers,
    });
  } catch (err) {
    res.status(500).json({ message: "Erreur serveur", error: err.message });
  }
});

/**
 * GET /api/public/plans
 * Liste des plans visibles publiquement (tarifs + features résumés).
 * Utilise les PlanPrice existants, ne montre que les champs visibles.
 */
router.get("/plans", async (req, res) => {
  try {
    const PlanPrice = require("../models/PlanPrice");
    const plans = await PlanPrice.find({})
      .select("price currency period features visibleName")
      .lean();
    // Mapper en forme légère
    const mapped = plans.map((p) => ({
      id: p._id,
      name: p.visibleName || p._id.toString(),
      price: p.price,
      currency: p.currency || "EUR",
      period: p.period || "monthly",
      features: Array.isArray(p.features) ? p.features : [],
    }));
    res.json(mapped);
  } catch (err) {
    // Valeurs par défaut si DB inaccessible
    res.json([
      {
        id: "starter",
        name: "Démarrage",
        price: 29,
        currency: "EUR",
        period: "monthly",
        features: ["Jusqu'à 5 produits", "1 thème inclus", "Support email"],
      },
      {
        id: "pro",
        name: "Pro",
        price: 79,
        currency: "EUR",
        period: "monthly",
        features: ["Jusqu'à 50 produits", "Tous les thèmes", "Support prioritaire"],
      },
      {
        id: "enterprise",
        name: "Entreprise",
        price: null,
        currency: "EUR",
        period: "contact",
        features: ["Produits illimités", "Personnalisation avancée", "Support dédié"],
      },
    ]);
  }
});

/**
 * GET /api/public/themes
 * Thèmes disponibles (noms + aperçu). Utilise le service Theme.
 */
router.get("/themes", async (req, res) => {
  try {
    const Theme = require("../models/Theme");
    const themes = await Theme.find({}).select("name description previewUrl order").lean();
    res.json(themes);
  } catch (err) {
    // Valeurs par défaut si DB inaccessible
    res.json([
      { id: "paris", name: "Paris", description: "Design urbain et moderne", previewUrl: "/assets/themes/paris.svg" },
      { id: "londres", name: "Londres", description: "Style corporate classique", previewUrl: "/assets/themes/londres.svg" },
      { id: "new-york", name: "New York", description: "Design dynamique et coloré", previewUrl: "/assets/themes/new-york.svg" },
    ]);
  }
});

module.exports = router;