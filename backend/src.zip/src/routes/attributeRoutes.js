const express = require("express");
const { getCode, getCodes } = require("../config/rbac/permissionCodes");
const router = express.Router();

const {
  addAttribute,
  addAllAttributes,
  getAllAttributes,
  getShowingAttributes,
  getAttributeById,
  updateAttribute,
  deleteAttribute,
  deleteManyAttributes,
} = require("../controller/attributeController");

// add attribute
router.post("/add", addAttribute);

// add all attributes
router.post("/add/all", addAllAttributes);

// get all attributes
router.get("/", getAllAttributes);

// get showing attributes in store
router.get("/show", getShowingAttributes);

// delete many attributes
router.patch("/delete/many", deleteManyAttributes);

// get attribute by id
router.get("/:id", getAttributeById);

// update attribute
router.put("/:id", updateAttribute);

// delete attribute
router.delete("/:id", deleteAttribute);

module.exports = router;
