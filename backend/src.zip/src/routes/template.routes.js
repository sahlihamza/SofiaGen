const express = require("express");
const { getCode, getCodes } = require("../config/rbac/permissionCodes");
const router = express.Router();
const { isAuth, loadUser, requirePermission, validateStoreAccess } = require("../middleware/auth");
const templateController = require("../controller/template.controller");

router.get("/stores/:storeId/templates", isAuth, loadUser, validateStoreAccess, requirePermission(getCode("Templates", "view")), templateController.listTemplates);
router.get("/stores/:storeId/templates/:templateId", isAuth, loadUser, validateStoreAccess, requirePermission(getCode("Templates", "view")), templateController.getTemplateById);
router.post("/stores/:storeId/templates", isAuth, loadUser, validateStoreAccess, requirePermission(getCode("Templates", "create")), templateController.createTemplate);
router.post("/stores/:storeId/templates/:templateId/duplicate", isAuth, loadUser, validateStoreAccess, requirePermission(getCode("Templates", "duplicate")), templateController.duplicateTemplate);
router.put("/stores/:storeId/templates/:templateId", isAuth, loadUser, validateStoreAccess, requirePermission(getCode("Templates", "update")), templateController.updateTemplate);
router.delete("/stores/:storeId/templates/:templateId", isAuth, loadUser, validateStoreAccess, requirePermission(getCode("Templates", "delete")), templateController.deleteTemplate);

module.exports = router;
