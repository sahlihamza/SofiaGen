const mongoose = require("mongoose");

const subscriptionEventSchema = new mongoose.Schema(
  {
    subscriptionId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Subscription",
      required: true,
      index: true,
    },
    storeId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Store",
      required: true,
      index: true,
    },
    type: {
      type: String,
      required: true,
    },
    message: {
      type: String,
      required: false,
    },
    payload: {
      type: mongoose.Schema.Types.Mixed,
      required: false,
      default: {},
    },
    status: {
      type: String,
      enum: ["pending", "success", "failed", "info", "warning"],
      default: "info",
    },
    createdBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: false,
    },
  },
  {
    timestamps: true,
  }
);

module.exports = mongoose.model("SubscriptionEvent", subscriptionEventSchema);
