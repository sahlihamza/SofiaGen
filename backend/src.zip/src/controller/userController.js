const userService = require("../service/userService");
const jwt = require("jsonwebtoken");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
const { OAuth2Client } = require("google-auth-library");
const User = require("../models/User");
const UserStore = require("../models/UserStore");
const LoginHistoryService = require("../service/LoginHistoryService");
const StoreUsageService = require("../service/StoreUsageService");
const { emitEvent } = require("../lib/eventBus");
const {
  generateAccessToken,
  generateRefreshToken,
} = require("../config/jwt");

const refreshSecret = process.env.JWT_REFRESH_SECRET || process.env.JWT_SECRET;
const googleClient = new OAuth2Client(process.env.GOOGLE_CLIENT_ID);
const {
  sendPasswordResetEmail,
  sendStaffWelcomeEmail,
} = require("../utils/mailer");
const { generatePassword } = require("../utils/generatePassword");
const { uploadDir, publicPath } = require("../utils/uploadPaths");
const requireCurrentStoreId = (req, res) => {
  const storeId = req.currentStoreId || req.user?.currentStoreId;
  if (!storeId) {
    res.status(400).json({
      success: false,
      message: "Aucun store sélectionné pour cet utilisateur",
    });
    return null;
  }
  return storeId;
};

const roleAccessList = {
  "Super Admin": [
    "dashboard",
    "products",
    "product",
    "categories",
    "attributes",
    "coupons",
    "customers",
    "orders",
    "order",
    "our-staff",
    "settings",
    "currencies",
    "store",
    "customization",
    "store-settings",
    "notifications",
    "edit-profile",
    "coming-soon",
    "customer-order",
  ],
  Admin: [
    "dashboard",
    "products",
    "categories",
    "attributes",
    "coupons",
    "customers",
    "orders",
    "our-staff",
    "settings",
    "currencies",
    "store",
    "customization",
    "store-settings",
    "notifications",
  ],
  Cashier: [
    "dashboard",
    "orders",
    "order",
    "currencies",
    "notifications",
    "edit-profile",
    "coming-soon",
    "customers",
    "customer-order",
  ],
  CEO: ["dashboard", "products", "orders", "customers", "our-staff", "settings"],
  Manager: ["dashboard", "products", "categories", "orders", "customers"],
  Accountant: ["dashboard", "orders", "order", "customers", "coupons"],
  Driver: ["dashboard", "orders", "order"],
  "Security Guard": ["dashboard"],
};

const getAccessList = (user) => {
  if (Array.isArray(user?.access_list) && user.access_list.length > 0) {
    return user.access_list;
  }
  return roleAccessList[user?.role] || ["dashboard"];
};

const register = async (req, res) => {
  try {
    const { name, email, password } = req.body;
    const exists = await userService.userExists({ email });
    if (exists) {
      return res.status(409).json({
        success: false,
        message: "Cet email est déjà utilisé",
      });
    }

    const user = await userService.createUser({ name, email, password });

    return res.status(201).json({
      success: true,
      message: "Compte créé avec succès",
      data: {
        _id: user._id,
        name: user.name,
        email: user.email,
        role: user.role,
        status: user.status,
        createdAt: user.createdAt,
      },
    });

  } catch (error) {

    if (error.name === "ValidationError") {
      const errors = Object.values(error.errors).map((err) => ({
        field: err.path,
        message: err.message,
      }));
      return res.status(422).json({
        success: false,
        message: "Données invalides",
        errors,
      });
    }

    if (error.code === 11000) {
      return res.status(409).json({
        success: false,
        message: "Cet email est déjà utilisé",
      });
    }

    return res.status(500).json({
      success: false,
      message: "Erreur serveur",
      error: error.message,
    });
  }
};


// ─── LOGIN ────────────────────────────────────────────────────────────────
const login = async (req, res) => {
  try {
    const { email, password } = req.body;
    const user = await userService.findUserByEmailWithPassword(email);
    if (!user) {
      return res.status(401).json({
        success: false,
        message: "Email ou mot de passe incorrect",
      });
    }

    if (user.status === "Inactive") {
      await LoginHistoryService.recordLogin({
        userId: user._id,
        ipAddress: req.ip,
        userAgent: req.headers["user-agent"],
        device: req.headers["user-agent"],
        browser: req.headers["user-agent"],
        os: req.headers["user-agent"],
        status: "blocked",
        failureReason: "Account inactive",
      });

      return res.status(403).json({
        success: false,
        message: "Compte désactivé, contactez l'administrateur",
      });
    }

    if (user.status === "Blocked") {
      await LoginHistoryService.recordLogin({
        userId: user._id,
        ipAddress: req.ip,
        userAgent: req.headers["user-agent"],
        device: req.headers["user-agent"],
        browser: req.headers["user-agent"],
        os: req.headers["user-agent"],
        status: "blocked",
        failureReason: user.blockedReason || "Account blocked",
      });

      return res.status(403).json({
        success: false,
        message: user.blockedReason || "Compte bloqué, contactez l'administrateur",
      });
    }

    // Accounts created via Google Sign-In have no local password — bcrypt
    // throws on a missing hash instead of just returning false, so this must
    // be checked explicitly rather than left to fall through to compare().
    if (!user.password) {
      return res.status(401).json({
        success: false,
        message: "Ce compte utilise la connexion Google, veuillez vous connecter avec Google",
      });
    }

    //  Check the password
    const isValid = await userService.validatePassword(password, user.password);
    if (!isValid) {
      emitEvent("security.failed_login", {
        userId: user._id,
        metadata: { ipAddress: req.ip },
      });
      return res.status(401).json({
        success: false,
        message: "Email ou mot de passe incorrect",
      });
    }

    const userRoleSlugs = (user.role || [])
      .map((r) => (typeof r === "object" ? r.slug : undefined))
      .filter(Boolean);

    const isSuperAdminFromRole = userRoleSlugs.includes("super-admin");
    const isPlatformAdminFromRole = userRoleSlugs.includes("platform-admin");

    const isSuperAdmin = Boolean(user.isSuperAdmin) || isSuperAdminFromRole;
    const resolvedUserType = isSuperAdmin
      ? "superadmin"
      : isPlatformAdminFromRole
        ? "platform_admin"
        : user.userType;

    const accessToken = generateAccessToken(user);
    const refreshToken = generateRefreshToken(user);
    await userService.saveRefreshToken(user._id, refreshToken);

    await userService.updateLastLogin(user._id);

    await LoginHistoryService.recordLogin({
      userId: user._id,
      ipAddress: req.ip,
      userAgent: req.headers["user-agent"],
      device: req.headers["user-agent"],
      browser: req.headers["user-agent"],
      os: req.headers["user-agent"],
      status: "success",
      sessionId: crypto.randomBytes(16).toString("hex"),
      storeId: user.currentStoreId || null,
    });

    emitEvent("security.new_login", {
      userId: user._id,
      metadata: { ipAddress: req.ip },
    });

    res.cookie("refreshToken", refreshToken, {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      sameSite: process.env.NODE_ENV === "production" ? "None" : "Lax",
      maxAge: 30 * 24 * 60 * 60 * 1000, // 30 jours — synchronisé avec JWT_REFRESH_EXPIRES_IN
    });

    console.log("DEBUG role renvoyé:", JSON.stringify(user.role, null, 2));

    return res.status(200).json({
      success: true,
      message: "Connexion réussie",
      accessToken,
      data: {
        _id: user._id,
        accountType: "admin",
        name: user.name,
        email: user.email,
        image: user.image,
        role: user.role,
        status: user.status,
        lastLogin: user.lastLogin,
        selectedStore: user.selectedStore || null,
        currentStoreId: user.currentStoreId || null,
        userType: resolvedUserType,
        isSuperAdmin: isSuperAdmin,
        storeIds: user.storeIds || [],
      },
    });

  } catch (error) {
    return res.status(500).json({
      success: false,
      message: "Erreur serveur",
      error: error.message,
    });
  }
};

// ─── GOOGLE LOGIN ─────────────────────────────────────────────────────────
const googleLogin = async (req, res) => {
  try {
    const { credential } = req.body;

    if (!credential) {
      return res.status(400).json({
        success: false,
        message: "Token Google manquant",
      });
    }

    let payload;
    try {
      const ticket = await googleClient.verifyIdToken({
        idToken: credential,
        audience: process.env.GOOGLE_CLIENT_ID,
      });
      payload = ticket.getPayload();
    } catch (err) {
      return res.status(401).json({
        success: false,
        message: "Token Google invalide",
      });
    }

    const { email, name, sub: googleId, picture } = payload;

    let user = await User.findOne({ email });

    if (!user) {
      // Nouveau compte via Google — aucun mot de passe stocké,
      // l'utilisateur pourra en définir un plus tard depuis son profil.
      user = await User.create({
        name,
        email,
        provider: "google",
        providerId: googleId,
        image: picture,
        status: "Active",
      });
    } else if (user.status === "Inactive") {
      return res.status(403).json({
        success: false,
        message: "Compte désactivé, contactez l'administrateur",
      });
    }

    const accessToken = generateAccessToken(user);
    const refreshToken = generateRefreshToken(user);

    await userService.saveRefreshToken(user._id, refreshToken);
    await userService.updateLastLogin(user._id);

    res.cookie("refreshToken", refreshToken, {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      sameSite: process.env.NODE_ENV === "production" ? "None" : "Lax",
      maxAge: 30 * 24 * 60 * 60 * 1000,
    });

    return res.status(200).json({
      success: true,
      message: "Connexion Google réussie",
      accessToken,
      data: {
        name: user.name,
        email: user.email,
        role: user.role,
        status: user.status,
        lastLogin: user.lastLogin,
        access_list: accessList,
        selectedStore: user.selectedStore || null,
      },
    });

  } catch (error) {
    return res.status(500).json({
      success: false,
      message: "Erreur serveur",
      error: error.message,
    });
  }
};

// ─── REFRESH TOKEN ────────────────────────────────────────────────────────
const refreshToken = async (req, res) => {
  try {
    const token = req.cookies.refreshToken;
    if (!token) {
      return res.status(401).json({
        success: false,
        message: "Refresh token manquant",
      });
    }

    let decoded;
    try {
      decoded = jwt.verify(token, refreshSecret);
    } catch {
      return res.status(401).json({
        success: false,
        message: "Refresh token invalide ou expiré",
      });
    }

    const user = await userService.findUserByRefreshToken(token);
    if (!user) {
      return res.status(401).json({
        success: false,
        message: "Refresh token révoqué",
      });
    }

    const userRoleSlugs = (user.role || [])
      .map((r) => (typeof r === "object" ? r.slug : undefined))
      .filter(Boolean);

    const isSuperAdminFromRole = userRoleSlugs.includes("super-admin");
    const isPlatformAdminFromRole = userRoleSlugs.includes("platform-admin");

    const isSuperAdmin = Boolean(user.isSuperAdmin) || isSuperAdminFromRole;
    const resolvedUserType = isSuperAdmin
      ? "superadmin"
      : isPlatformAdminFromRole
        ? "platform_admin"
        : user.userType;

    const newAccessToken = generateAccessToken(user);

    return res.status(200).json({
      success: true,
      accessToken: newAccessToken,
      data: {
        _id: user._id,
        accountType: "admin",
        name: user.name,
        email: user.email,
        image: user.image,
        role: user.role,
        status: user.status,
        lastLogin: user.lastLogin,
        userType: resolvedUserType,
        isSuperAdmin: isSuperAdmin,
        storeIds: user.storeIds || [],
        selectedStore: user.selectedStore || null,
        currentStoreId: user.currentStoreId || null,
      },
    });

  } catch (error) {
    return res.status(500).json({
      success: false,
      message: "Erreur serveur",
      error: error.message,
    });
  }
};

// ─── LOGOUT ───────────────────────────────────────────────────────────────
const logout = async (req, res) => {
  try {
    const token = req.cookies.refreshToken;
    if (token) {
     
      const user = await userService.findUserByRefreshToken(token);
      if (user) {
        await userService.clearRefreshToken(user._id);
      }
    }

    res.clearCookie("refreshToken", {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      sameSite: process.env.NODE_ENV === "production" ? "None" : "Lax",
    });

    return res.status(200).json({
      success: true,
      message: "Déconnexion réussie",
    });

  } catch (error) {
    return res.status(500).json({
      success: false,
      message: "Erreur serveur",
      error: error.message,
    });
  }

}

const getStaff = async (req, res) => {
  try {
    const storeId = requireCurrentStoreId(req, res);
    if (!storeId) return;

    const users = await userService.getStaff(storeId);

    return res.status(200).json({
      success: true,
      message: "Liste des utilisateurs récupérée avec succès",
      data: users,
    });
  } catch (error) {
    return res.status(500).json({
      success: false,
      message: "Erreur serveur",
      error: error.message,
    });
  }
};

const searchUsers = async (req, res) => {
  try {
    const { q } = req.query;
    const users = await userService.searchUsers(q || "");

    return res.status(200).json({
      success: true,
      message: "Users search results",
      data: users,
    });
  } catch (error) {
    return res.status(500).json({
      success: false,
      message: "Erreur serveur",
      error: error.message,
    });
  }
};

const addStaff = async (req, res) => {
  try {
    const storeId = requireCurrentStoreId(req, res);
    if (!storeId) return;

    const { name, email, phone, role } = req.body;
    const image = req.file
      ? publicPath("staffImages", req.file.filename)
      : req.body.image || null;
    const roleIds = Array.isArray(role) ? role : role ? [role] : [];

    if (roleIds.length === 0) {
      return res.status(422).json({
        success: false,
        message: "Le champ 'role' est obligatoire",
      });
    }

    const exists = await userService.userExists({ email });
    if (exists) {
      return res.status(409).json({
        success: false,
        message: "Cet email est déjà utilisé",
      });
    }
    const password = generatePassword();

    const staff = await userService.addStaff(
      {
        name,
        email,
        password,
        phone,
        joiningData: new Date(),
        image,
        role: roleIds,
      },
      storeId
    );

    await StoreUsageService.incrementUsage(storeId, "admins", 1);
    let emailSent = true;
    try {
      await sendStaffWelcomeEmail(staff.email, {
        name: staff.name,
        password,
        loginUrl: `${process.env.FRONTEND_URL}/login`,
      });
    } catch (mailError) {
      emailSent = false;
    }

    return res.status(201).json({
      success: true,
      message: emailSent
        ? "Staff ajouté avec succès. Le mot de passe a été envoyé par email."
        : "Staff ajouté, mais l'email contenant le mot de passe n'a pas pu être envoyé.",
      emailSent,
      data: {
        name: staff.name,
        email: staff.email,
        image: staff.image,
        role: staff.role,
        status: staff.status,
        joiningData: staff.joiningData,
        createdAt: staff.createdAt,
      },
    });
  } catch (error) {
    if (error.name === "ValidationError") {
      const errors = Object.values(error.errors).map((err) => ({
        field: err.path,
        message: err.message,
      }));
      return res.status(422).json({
        success: false,
        message: "Données invalides",
        errors,
      });
    }
    if (error.code === 11000) {
      return res.status(409).json({
        success: false,
        message: "Cet email est déjà utilisé",
      });
    }
    return res.status(500).json({
      success: false,
      message: "Erreur serveur",
      error: error.message,
    });
  }
};

const getStaffById = async (req, res) => {
  try {
    const storeId = requireCurrentStoreId(req, res);
    if (!storeId) return;

    const { id } = req.params;
    const staff = await userService.getStaffById(id, storeId);

    if (!staff) {
      return res.status(404).json({
        success: false,
        message: "Utilisateur introuvable",
      });
    }

    return res.status(200).json({
      success: true,
      message: "Utilisateur récupéré avec succès",
      data: staff,
    });
  } catch (error) {
    if (error.name === "CastError") {
      return res.status(400).json({
        success: false,
        message: "Identifiant invalide",
      });
    }

    return res.status(500).json({
      success: false,
      message: "Erreur serveur",
      error: error.message,
    });
  }
};

const updateStaff = async (req, res) => {
  try {
    const { id } = req.params;
    const { name, email, password, phone, joiningData, image, role } = req.body;
    const roleIds = Array.isArray(role) ? role : role ? [role] : undefined;

    if (!image || !String(image).trim()) {
      return res.status(422).json({
        success: false,
        message: "L'image du staff est obligatoire",
      });
    }

    const currentStaff = await userService.getStaffById(id);
    if (!currentStaff) {
      return res.status(404).json({
        success: false,
        message: "Utilisateur introuvable",
      });
    }

    const emailTaken = await userService.userExists({
      email,
      _id: { $ne: id },
    });

    if (emailTaken) {
      return res.status(409).json({
        success: false,
        message: "Cet email est déjà utilisé",
      });
    }

    const updatedStaff = await userService.updateStaff(id, {
      name,
      email,
      password,
      phone,
      joiningData,
      image: image !== undefined ? image : currentStaff.image,
      role: roleIds,
    });

    if (
      currentStaff.image &&
      updatedStaff.image &&
      currentStaff.image !== updatedStaff.image
    ) {
      const oldImageName = path.basename(currentStaff.image);
      const oldImagePath = path.join(uploadDir("staffImages"), oldImageName);

      try {
        await fs.promises.unlink(oldImagePath);
      } catch (error) {
        if (error.code !== "ENOENT") {
          throw error;
        }
      }
    }

    return res.status(200).json({
      success: true,
      message: "Staff mis à jour avec succès",
      data: updatedStaff,
    });
  } catch (error) {
    if (error.name === "ValidationError") {
      const errors = Object.values(error.errors).map((err) => ({
        field: err.path,
        message: err.message,
      }));
      return res.status(422).json({
        success: false,
        message: "Données invalides",
        errors,
      });
    }

    if (error.name === "CastError") {
      return res.status(400).json({
        success: false,
        message: "Identifiant invalide",
      });
    }

    return res.status(500).json({
      success: false,
      message: "Erreur serveur",
      error: error.message,
    });
  }
};

const deleteStaffImage = async (imagePath) => {
  if (!imagePath) {
    return;
  }

  const imageName = path.basename(imagePath);
  const filePath = path.join(uploadDir("staffImages"), imageName);

  try {
    await fs.promises.unlink(filePath);
  } catch (error) {
    if (error.code !== "ENOENT") {
      throw error;
    }
  }
};

// ─── ASSIGN ROLES ───────────────────────────────────────────────────────
const assignRoles = async (req, res) => {
  try {
    const { id } = req.params;
    const { role } = req.body;

    if (!Array.isArray(role)) {
      return res.status(422).json({
        success: false,
        message: "Le champ 'role' doit être un tableau d'identifiants",
      });
    }

    const user = await userService.assignRoles(id, role);

    if (!user) {
      return res.status(404).json({
        success: false,
        message: "Utilisateur introuvable",
      });
    }

    return res.status(200).json({
      success: true,
      message: "Rôles assignés avec succès",
      data: user,
    });
  } catch (error) {
    if (error.name === "InvalidRoles") {
      return res.status(422).json({
        success: false,
        message: error.message,
      });
    }

    if (error.name === "CastError") {
      return res.status(400).json({
        success: false,
        message: "Identifiant invalide",
      });
    }

    return res.status(500).json({
      success: false,
      message: "Erreur serveur",
      error: error.message,
    });
  }
};

const deleteStaff = async (req, res) => {
  try {
    const { id } = req.params;
    const staff = await userService.getStaffById(id);

    if (!staff) {
      return res.status(404).json({
        success: false,
        message: "Utilisateur introuvable",
      });
    }

    await deleteStaffImage(staff.image);
    await userService.deleteStaff(id);
    const storeLinks = await UserStore.find({ userId: id }).select("storeId");
    await UserStore.deleteMany({ userId: id });
    await Promise.all(
      storeLinks.map((link) =>
        StoreUsageService.decrementUsage(link.storeId, "admins", 1)
      )
    );

    return res.status(200).json({
      success: true,
      message: "Staff supprimé avec succès",
    });
  } catch (error) {
    if (error.name === "CastError") {
      return res.status(400).json({
        success: false,
        message: "Identifiant invalide",
      });
    }

    return res.status(500).json({
      success: false,
      message: "Erreur serveur",
      error: error.message,
    });
  }
};

const updateStaffStatus = async (req, res) => {
  try {
    const { id } = req.params;
    const staff = await userService.toggleStaffStatus(id);

    if (!staff) {
      return res.status(404).json({
        success: false,
        message: "Utilisateur introuvable",
      });
    }

    return res.status(200).json({
      success: true,
      message: "Statut du staff mis à jour avec succès",
      data: {
        id: staff._id,
        status: staff.status,
      },
    });
  } catch (error) {
    if (error.name === "CastError") {
      return res.status(400).json({
        success: false,
        message: "Identifiant invalide",
      });
    }

    return res.status(500).json({
      success: false,
      message: "Erreur serveur",
      error: error.message,
    });
  }
};


// ─── FORGOT PASSWORD ────────────────────────────────────────────────────
const forgotPassword = async (req, res) => {
  try {
    const { email } = req.body;

    if (!email || typeof email !== "string") {
      return res.status(400).json({
        success: false,
        message: "Email is required",
      });
    }

    const user = await userService.findUserByEmail(email);

    if (user) {
      const rawToken = await userService.setPasswordResetToken(user._id);
      const resetUrl = `${process.env.FRONTEND_URL}/reset-password/${rawToken}`;
      await sendPasswordResetEmail(user.email, resetUrl);
    }

    return res.status(200).json({
      success: true,
      message: "If an account with this email exists, we have sent a password reset link.",
    });

  } catch (error) {
    return res.status(500).json({
      success: false,
      message: "Erreur serveur",
      error: error.message,
    });
  }
};

// ─── RESET PASSWORD ───────────────────────────────────────────────────────
const resetPassword = async (req, res) => {
  try {
    const { token } = req.params;
    const { password, confirmPassword } = req.body;

    if (!password || password.length < 8) {
      return res.status(422).json({
        success: false,
        message: "Le mot de passe doit contenir au moins 8 caractères",
      });
    }

    if (confirmPassword !== undefined && password !== confirmPassword) {
      return res.status(422).json({
        success: false,
        message: "Les mots de passe ne correspondent pas",
      });
    }

    const user = await userService.findUserByResetToken(token);
    if (!user) {
      return res.status(400).json({
        success: false,
        message: "Lien de réinitialisation invalide ou expiré",
      });
    }

    await userService.resetPassword(user._id, password);

   

    return res.status(200).json({
      success: true,
      message: "Mot de passe réinitialisé avec succès",
    });

  } catch (error) {
    return res.status(500).json({
      success: false,
      message: "Erreur serveur",
      error: error.message,
    });
  }
};

// ─── PROFILE (connected user) ─────────────────────────────────────────────
const getProfile = async (req, res) => {
  try {
    const user = req.user;

    return res.status(200).json({
      success: true,
      message: "Profil récupéré avec succès",
      data: {
        name: user.name,
        email: user.email,
        image: user.image,
        address: user.address,
        phone: user.phone,
        gender: user.gender,
        role: user.role,
        status: user.status,
      },
    });
  } catch (error) {
    return res.status(500).json({
      success: false,
      message: "Erreur serveur",
      error: error.message,
    });
  }
};

const updateProfile = async (req, res) => {
  try {
    const { name, email, address, phone, gender, image } = req.body;

    if (email) {
      const emailTaken = await userService.userExists({
        email,
        _id: { $ne: req.userId },
      });

      if (emailTaken) {
        return res.status(409).json({
          success: false,
          message: "Cet email est déjà utilisé",
        });
      }
    }

    const updatedUser = await userService.updateProfile(req.userId, {
      name,
      email,
      address,
      phone,
      gender,
      image,
    });

    if (!updatedUser) {
      return res.status(404).json({
        success: false,
        message: "Utilisateur introuvable",
      });
    }

    return res.status(200).json({
      success: true,
      message: "Profil mis à jour avec succès",
      data: {
        name: updatedUser.name,
        email: updatedUser.email,
        image: updatedUser.image,
        address: updatedUser.address,
        phone: updatedUser.phone,
        gender: updatedUser.gender,
      },
    });
  } catch (error) {
    if (error.name === "ValidationError") {
      const errors = Object.values(error.errors).map((err) => ({
        field: err.path,
        message: err.message,
      }));
      return res.status(422).json({
        success: false,
        message: "Données invalides",
        errors,
      });
    }

    if (error.code === 11000) {
      return res.status(409).json({
        success: false,
        message: "Cet email est déjà utilisé",
      });
    }

    return res.status(500).json({
      success: false,
      message: "Erreur serveur",
      error: error.message,
    });
  }
};

const updateProfileImage = async (req, res) => {
  try {
    const { image } = req.body;

    if (!image || !String(image).trim()) {
      return res.status(422).json({
        success: false,
        message: "L'image est obligatoire",
      });
    }

    const currentImage = req.user.image;
    const updatedUser = await userService.updateProfileImage(req.userId, image);

    if (currentImage && currentImage !== updatedUser.image) {
      await deleteStaffImage(currentImage);
    }

    return res.status(200).json({
      success: true,
      message: "Image de profil mise à jour avec succès",
      data: { image: updatedUser.image },
    });
  } catch (error) {
    return res.status(500).json({
      success: false,
      message: "Erreur serveur",
      error: error.message,
    });
  }
};

const changePassword = async (req, res) => {
  try {
    const { currentPassword, newPassword, confirmPassword } = req.body;

    if (!currentPassword || !newPassword || !confirmPassword) {
      return res.status(422).json({
        success: false,
        message: "Tous les champs sont obligatoires",
      });
    }

    if (newPassword.length < 8) {
      return res.status(422).json({
        success: false,
        message: "Le mot de passe doit contenir au moins 8 caractères",
      });
    }

    if (newPassword !== confirmPassword) {
      return res.status(422).json({
        success: false,
        message: "Les mots de passe ne correspondent pas",
      });
    }

    const user = await userService.findUserByIdWithPassword(req.userId);
    if (!user) {
      return res.status(404).json({
        success: false,
        message: "Utilisateur introuvable",
      });
    }

    const isValid = await userService.validatePassword(currentPassword, user.password);
    if (!isValid) {
      return res.status(401).json({
        success: false,
        message: "Mot de passe actuel incorrect",
      });
    }

    await userService.resetPassword(req.userId, newPassword);

    emitEvent("security.password_changed", { userId: req.userId });

    return res.status(200).json({
      success: true,
      message: "Mot de passe modifié avec succès",
    });
  } catch (error) {
    return res.status(500).json({
      success: false,
      message: "Erreur serveur",
      error: error.message,
    });
  }
};

// ─── MY STORES (connected user) ─────────────────────────────────────────
const getMyStores = async (req, res) => {
  try {
    const stores = await userService.getStoresForUser(req.userId);
    let currentStoreId = req.user.currentStoreId || null;

    if (!currentStoreId && stores.length > 0) {
      currentStoreId = stores[0]._id;
    }

    if (!currentStoreId && stores.length === 0 && (req.user?.isSuperAdmin || req.user?.userType === "superadmin")) {
      const Store = require("../models/Store");
      const defaultStore = await Store.create({
        name: "Default Store",
        status: "active",
        currency: "USD",
        isActive: true,
      });
      await UserStore.create({
        userId: req.userId,
        storeId: defaultStore._id,
      });
      currentStoreId = defaultStore._id;
    }

    return res.status(200).json({
      success: true,
      message: "Stores récupérés avec succès",
      data: {
        stores: currentStoreId ? await userService.getStoresForUser(req.userId) : [],
        currentStoreId,
      },
    });
  } catch (error) {
    return res.status(500).json({
      success: false,
      message: "Erreur serveur",
      error: error.message,
    });
  }
};

const selectMyStore = async (req, res) => {
  try {
    const { storeId } = req.body;

    if (!storeId) {
      return res.status(422).json({
        success: false,
        message: "Le champ 'storeId' est obligatoire",
      });
    }

    let user = await userService.selectStore(req.userId, storeId);

    if (!user && req.user.isSuperAdmin) {
      await UserStore.create({ userId: req.userId, storeId, status: "active" });
      user = await userService.selectStore(req.userId, storeId);
    }

    if (!user) {
      return res.status(403).json({
        success: false,
        message: "Ce store n'est pas assigné à cet utilisateur",
      });
    }

    return res.status(200).json({
      success: true,
      message: "Store sélectionné avec succès",
      data: { currentStoreId: user.currentStoreId },
    });
  } catch (error) {
    if (error.name === "StoreNotAssigned") {
      return res.status(403).json({
        success: false,
        message: error.message,
      });
    }

    if (error.name === "CastError") {
      return res.status(400).json({
        success: false,
        message: "Identifiant invalide",
      });
    }

    return res.status(500).json({
      success: false,
      message: "Erreur serveur",
      error: error.message,
    });
  }
};

const deselectMyStore = async (req, res) => {
  try {
    const user = await userService.deselectStore(req.userId);

    return res.status(200).json({
      success: true,
      message: "Store désélectionné avec succès",
      data: { currentStoreId: user.currentStoreId },
    });
  } catch (error) {
    return res.status(500).json({
      success: false,
      message: "Erreur serveur",
      error: error.message,
    });
  }
};

// ─── BLOCK USER ───────────────────────────────────────────────────
const blockUser = async (req, res) => {
  try {
    const { id } = req.params;
    const { reason } = req.body;
    const user = await userService.blockUser(id, reason);
    if (!user) {
      return res.status(404).json({ success: false, message: "Utilisateur introuvable" });
    }
    return res.status(200).json({ success: true, message: "Utilisateur bloqué avec succès", data: user });
  } catch (error) {
    return res.status(500).json({ success: false, message: "Erreur serveur", error: error.message });
  }
};

// ─── UNBLOCK USER ─────────────────────────────────────────────────
const unblockUser = async (req, res) => {
  try {
    const { id } = req.params;
    const user = await userService.unblockUser(id);
    if (!user) {
      return res.status(404).json({ success: false, message: "Utilisateur introuvable" });
    }
    return res.status(200).json({ success: true, message: "Utilisateur débloqué avec succès", data: user });
  } catch (error) {
    return res.status(500).json({ success: false, message: "Erreur serveur", error: error.message });
  }
};

// ─── SUSPEND USER ─────────────────────────────────────────────────
const suspendUser = async (req, res) => {
  try {
    const { id } = req.params;
    const { reason } = req.body;
    const user = await userService.suspendUser(id, reason);
    if (!user) {
      return res.status(404).json({ success: false, message: "Utilisateur introuvable" });
    }
    return res.status(200).json({ success: true, message: "Utilisateur suspendu avec succès", data: user });
  } catch (error) {
    return res.status(500).json({ success: false, message: "Erreur serveur", error: error.message });
  }
};

// ─── ACTIVATE USER ────────────────────────────────────────────────
const activateUser = async (req, res) => {
  try {
    const { id } = req.params;
    const user = await userService.activateUser(id);
    if (!user) {
      return res.status(404).json({ success: false, message: "Utilisateur introuvable" });
    }
    return res.status(200).json({ success: true, message: "Utilisateur activé avec succès", data: user });
  } catch (error) {
    return res.status(500).json({ success: false, message: "Erreur serveur", error: error.message });
  }
};

// ─── ARCHIVE USER ─────────────────────────────────────────────────
const archiveUser = async (req, res) => {
  try {
    const { id } = req.params;
    const { reason } = req.body;
    const user = await userService.archiveUser(id, reason);
    if (!user) {
      return res.status(404).json({ success: false, message: "Utilisateur introuvable" });
    }
    return res.status(200).json({ success: true, message: "Utilisateur archivé avec succès", data: user });
  } catch (error) {
    return res.status(500).json({ success: false, message: "Erreur serveur", error: error.message });
  }
};

// ─── UNARCHIVE USER ───────────────────────────────────────────────
const unarchiveUser = async (req, res) => {
  try {
    const { id } = req.params;
    const user = await userService.unarchiveUser(id);
    if (!user) {
      return res.status(404).json({ success: false, message: "Utilisateur introuvable" });
    }
    return res.status(200).json({ success: true, message: "Utilisateur désarchivé avec succès", data: user });
  } catch (error) {
    return res.status(500).json({ success: false, message: "Erreur serveur", error: error.message });
  }
};

// ─── RESET PASSWORD ───────────────────────────────────────────────
const resetUserPassword = async (req, res) => {
  try {
    const { id } = req.params;
    const user = await userService.resetPassword(id);
    if (!user) {
      return res.status(404).json({ success: false, message: "Utilisateur introuvable" });
    }
    return res.status(200).json({ success: true, message: "Réinitialisation du mot de passe envoyée", data: user });
  } catch (error) {
    return res.status(500).json({ success: false, message: "Erreur serveur", error: error.message });
  }
};

// ─── RESEND INVITATION ────────────────────────────────────────────
const resendInvitation = async (req, res) => {
  try {
    const { id } = req.params;
    const user = await userService.resendInvitation(id);
    if (!user) {
      return res.status(404).json({ success: false, message: "Utilisateur introuvable" });
    }
    return res.status(200).json({ success: true, message: "Invitation renvoyée avec succès", data: user });
  } catch (error) {
    return res.status(500).json({ success: false, message: "Erreur serveur", error: error.message });
  }
};

// ─── RESEND PASSWORD EMAIL ────────────────────────────────────────
const resendPasswordEmail = async (req, res) => {
  try {
    const { id } = req.params;
    const user = await userService.resendPasswordEmail(id);
    if (!user) {
      return res.status(404).json({ success: false, message: "Utilisateur introuvable" });
    }
    return res.status(200).json({ success: true, message: "Email de mot de passe renvoyé", data: user });
  } catch (error) {
    return res.status(500).json({ success: false, message: "Erreur serveur", error: error.message });
  }
};

// ─── FORCE PASSWORD CHANGE ────────────────────────────────────────
const forcePasswordChange = async (req, res) => {
  try {
    const { id } = req.params;
    const { forcePasswordChange } = req.body;
    const user = await userService.forcePasswordChange(id, forcePasswordChange);
    if (!user) {
      return res.status(404).json({ success: false, message: "Utilisateur introuvable" });
    }
    return res.status(200).json({ success: true, message: "Force password change mis à jour", data: user });
  } catch (error) {
    return res.status(500).json({ success: false, message: "Erreur serveur", error: error.message });
  }
};

// ─── ENABLE 2FA ───────────────────────────────────────────────────
const enable2FA = async (req, res) => {
  try {
    const { id } = req.params;
    const user = await userService.enable2FA(id);
    if (!user) {
      return res.status(404).json({ success: false, message: "Utilisateur introuvable" });
    }
    return res.status(200).json({ success: true, message: "2FA activé avec succès", data: user });
  } catch (error) {
    return res.status(500).json({ success: false, message: "Erreur serveur", error: error.message });
  }
};

// ─── DISABLE 2FA ──────────────────────────────────────────────────
const disable2FA = async (req, res) => {
  try {
    const { id } = req.params;
    const user = await userService.disable2FA(id);
    if (!user) {
      return res.status(404).json({ success: false, message: "Utilisateur introuvable" });
    }
    return res.status(200).json({ success: true, message: "2FA désactivé avec succès", data: user });
  } catch (error) {
    return res.status(500).json({ success: false, message: "Erreur serveur", error: error.message });
  }
};

// ─── GET USER SESSIONS ────────────────────────────────────────────
const getUserSessions = async (req, res) => {
  try {
    const { id } = req.params;
    const user = await userService.getUserById(id);
    if (!user) {
      return res.status(404).json({ success: false, message: "Utilisateur introuvable" });
    }
    return res.status(200).json({ success: true, data: user.activeSessions || [] });
  } catch (error) {
    return res.status(500).json({ success: false, message: "Erreur serveur", error: error.message });
  }
};

// ─── REVOKE ALL SESSIONS ──────────────────────────────────────────
const revokeAllSessions = async (req, res) => {
  try {
    const { id } = req.params;
    const user = await userService.revokeAllSessions(id);
    if (!user) {
      return res.status(404).json({ success: false, message: "Utilisateur introuvable" });
    }
    return res.status(200).json({ success: true, message: "Toutes les sessions révoquées", data: user });
  } catch (error) {
    return res.status(500).json({ success: false, message: "Erreur serveur", error: error.message });
  }
};

// ─── LOGOUT DEVICE ────────────────────────────────────────────────
const logoutDevice = async (req, res) => {
  try {
    const { id, sessionId } = req.params;
    const user = await userService.logoutDevice(id, sessionId);
    if (!user) {
      return res.status(404).json({ success: false, message: "Utilisateur introuvable" });
    }
    return res.status(200).json({ success: true, message: "Session déconnectée", data: user });
  } catch (error) {
    return res.status(500).json({ success: false, message: "Erreur serveur", error: error.message });
  }
};

// ─── GET LOGIN HISTORY ────────────────────────────────────────────
const getUserLoginHistory = async (req, res) => {
  try {
    const { id } = req.params;
    const { page, limit } = req.query;
    const result = await userService.getLoginHistory(id, { page: parseInt(page) || 1, limit: parseInt(limit) || 25 });
    return res.status(200).json({ success: true, data: result.history, pagination: result.pagination });
  } catch (error) {
    return res.status(500).json({ success: false, message: "Erreur serveur", error: error.message });
  }
};

// ─── GET USER ACTIVITY ────────────────────────────────────────────
const getUserActivity = async (req, res) => {
  try {
    const { id } = req.params;
    const { page, limit } = req.query;
    const result = await userService.getActivity(id, { page: parseInt(page) || 1, limit: parseInt(limit) || 25 });
    return res.status(200).json({ success: true, data: result.activities, pagination: result.pagination });
  } catch (error) {
    return res.status(500).json({ success: false, message: "Erreur serveur", error: error.message });
  }
};

// ─── GET USER PERMISSIONS ─────────────────────────────────────────
const getUserPermissions = async (req, res) => {
  try {
    const { id } = req.params;
    const user = await userService.getUserById(id).populate("role permissions");
    if (!user) {
      return res.status(404).json({ success: false, message: "Utilisateur introuvable" });
    }
    return res.status(200).json({ success: true, data: user.permissions || [] });
  } catch (error) {
    return res.status(500).json({ success: false, message: "Erreur serveur", error: error.message });
  }
};

// ─── GET USER PROFILE ─────────────────────────────────────────────
const getUserProfile = async (req, res) => {
  try {
    const { id } = req.params;
    const user = await userService.getUserById(id);
    if (!user) {
      return res.status(404).json({ success: false, message: "Utilisateur introuvable" });
    }
    return res.status(200).json({ success: true, data: user });
  } catch (error) {
    return res.status(500).json({ success: false, message: "Erreur serveur", error: error.message });
  }
};

// ─── IMPERSONATE USER ─────────────────────────────────────────────
const impersonateUser = async (req, res) => {
  try {
    const { id } = req.params;
    const user = await userService.impersonateUser(id, req.user._id);
    if (!user) {
      return res.status(404).json({ success: false, message: "Utilisateur introuvable" });
    }
    return res.status(200).json({ success: true, message: "Impersonation démarrée", data: user });
  } catch (error) {
    return res.status(500).json({ success: false, message: "Erreur serveur", error: error.message });
  }
};

// ─── DUPLICATE USER ───────────────────────────────────────────────
const duplicateUser = async (req, res) => {
  try {
    const { id } = req.params;
    const user = await userService.duplicateUser(id);
    if (!user) {
      return res.status(404).json({ success: false, message: "Utilisateur introuvable" });
    }
    return res.status(201).json({ success: true, message: "Utilisateur dupliqué avec succès", data: user });
  } catch (error) {
    return res.status(500).json({ success: false, message: "Erreur serveur", error: error.message });
  }
};

// ─── EXPORT USER ──────────────────────────────────────────────────
const exportUser = async (req, res) => {
  try {
    const { id } = req.params;
    const user = await userService.getUserById(id);
    if (!user) {
      return res.status(404).json({ success: false, message: "Utilisateur introuvable" });
    }
    return res.status(200).json({ success: true, data: user });
  } catch (error) {
    return res.status(500).json({ success: false, message: "Erreur serveur", error: error.message });
  }
};

// ─── BULK ACTIONS ─────────────────────────────────────────────────
const bulkActivate = async (req, res) => {
  try {
    const { ids } = req.body;
    const result = await userService.bulkUpdateStatus(ids, "Active");
    return res.status(200).json({ success: true, message: `${result.modifiedCount} utilisateurs activés`, data: result });
  } catch (error) {
    return res.status(500).json({ success: false, message: "Erreur serveur", error: error.message });
  }
};

const bulkDeactivate = async (req, res) => {
  try {
    const { ids } = req.body;
    const result = await userService.bulkUpdateStatus(ids, "Inactive");
    return res.status(200).json({ success: true, message: `${result.modifiedCount} utilisateurs désactivés`, data: result });
  } catch (error) {
    return res.status(500).json({ success: false, message: "Erreur serveur", error: error.message });
  }
};

const bulkBlock = async (req, res) => {
  try {
    const { ids, reason } = req.body;
    const result = await userService.bulkBlock(ids, reason);
    return res.status(200).json({ success: true, message: `${result.modifiedCount} utilisateurs bloqués`, data: result });
  } catch (error) {
    return res.status(500).json({ success: false, message: "Erreur serveur", error: error.message });
  }
};

const bulkUnblock = async (req, res) => {
  try {
    const { ids } = req.body;
    const result = await userService.bulkUnblock(ids);
    return res.status(200).json({ success: true, message: `${result.modifiedCount} utilisateurs débloqués`, data: result });
  } catch (error) {
    return res.status(500).json({ success: false, message: "Erreur serveur", error: error.message });
  }
};

const bulkSuspend = async (req, res) => {
  try {
    const { ids, reason } = req.body;
    const result = await userService.bulkSuspend(ids, reason);
    return res.status(200).json({ success: true, message: `${result.modifiedCount} utilisateurs suspendus`, data: result });
  } catch (error) {
    return res.status(500).json({ success: false, message: "Erreur serveur", error: error.message });
  }
};

const bulkArchive = async (req, res) => {
  try {
    const { ids } = req.body;
    const result = await userService.bulkArchive(ids);
    return res.status(200).json({ success: true, message: `${result.modifiedCount} utilisateurs archivés`, data: result });
  } catch (error) {
    return res.status(500).json({ success: false, message: "Erreur serveur", error: error.message });
  }
};

const bulkDelete = async (req, res) => {
  try {
    const { ids } = req.body;
    const result = await userService.bulkDelete(ids);
    return res.status(200).json({ success: true, message: `${result.deletedCount} utilisateurs supprimés`, data: result });
  } catch (error) {
    return res.status(500).json({ success: false, message: "Erreur serveur", error: error.message });
  }
};

const bulkResetPassword = async (req, res) => {
  try {
    const { ids } = req.body;
    const result = await userService.bulkResetPassword(ids);
    return res.status(200).json({ success: true, message: `${result.modifiedCount} réinitialisations envoyées`, data: result });
  } catch (error) {
    return res.status(500).json({ success: false, message: "Erreur serveur", error: error.message });
  }
};

const bulkResendInvitation = async (req, res) => {
  try {
    const { ids } = req.body;
    const result = await userService.bulkResendInvitation(ids);
    return res.status(200).json({ success: true, message: `${result.modifiedCount} invitations renvoyées`, data: result });
  } catch (error) {
    return res.status(500).json({ success: false, message: "Erreur serveur", error: error.message });
  }
};

const bulkExport = async (req, res) => {
  try {
    const { ids } = req.body;
    const users = await userService.bulkExport(ids);
    return res.status(200).json({ success: true, data: users });
  } catch (error) {
    return res.status(500).json({ success: false, message: "Erreur serveur", error: error.message });
  }
};

const bulkAssignRole = async (req, res) => {
  try {
    const { ids, roleId } = req.body;
    const result = await userService.bulkAssignRole(ids, roleId);
    return res.status(200).json({ success: true, message: `${result.modifiedCount} rôles assignés`, data: result });
  } catch (error) {
    return res.status(500).json({ success: false, message: "Erreur serveur", error: error.message });
  }
};

const bulkEnable2FA = async (req, res) => {
  try {
    const { ids } = req.body;
    const result = await userService.bulkEnable2FA(ids);
    return res.status(200).json({ success: true, message: `${result.modifiedCount} 2FA activés`, data: result });
  } catch (error) {
    return res.status(500).json({ success: false, message: "Erreur serveur", error: error.message });
  }
};

const bulkDisable2FA = async (req, res) => {
  try {
    const { ids } = req.body;
    const result = await userService.bulkDisable2FA(ids);
    return res.status(200).json({ success: true, message: `${result.modifiedCount} 2FA désactivés`, data: result });
  } catch (error) {
    return res.status(500).json({ success: false, message: "Erreur serveur", error: error.message });
  }
};

module.exports = {
  register,
  login,
  googleLogin,
  refreshToken,
  logout,
  getStaff,
  searchUsers,
  getStaffById,
  addStaff,
  updateStaff,
  deleteStaff,
  updateStaffStatus,
  assignRoles,
  forgotPassword,
  resetPassword,
  getProfile,
  updateProfile,
  updateProfileImage,
  changePassword,
  getMyStores,
   selectMyStore,
   deselectMyStore,
  blockUser,
  unblockUser,
  suspendUser,
  activateUser,
  archiveUser,
  unarchiveUser,
  resetUserPassword,
  resendInvitation,
  resendPasswordEmail,
  forcePasswordChange,
  enable2FA,
  disable2FA,
  getUserSessions,
  revokeAllSessions,
  logoutDevice,
  getUserLoginHistory,
  getUserActivity,
  getUserPermissions,
  getUserProfile,
  impersonateUser,
  duplicateUser,
  exportUser,
  bulkActivate,
  bulkDeactivate,
  bulkBlock,
  bulkUnblock,
  bulkSuspend,
  bulkArchive,
  bulkDelete,
  bulkResetPassword,
  bulkResendInvitation,
  bulkExport,
  bulkAssignRole,
  bulkEnable2FA,
  bulkDisable2FA,
};
