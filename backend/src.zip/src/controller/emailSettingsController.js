const emailSettingsService = require("../service/emailSettingsService");

const handleError = (res, error) => {
  if (
    error.name === "UnknownEmailNotification" ||
    error.name === "DuplicateEmailNotification" ||
    error.name === "InvalidRecipientEmail"
  ) {
    return res.status(400).json({
      success: false,
      message: error.message,
    });
  }

  if (error.name === "EmailNotificationNotFound") {
    return res.status(404).json({
      success: false,
      message: error.message,
    });
  }

  if (error.name === "ValidationError") {
    const errors = error.errors
      ? Object.values(error.errors).map((err) => ({
          field: err.path,
          message: err.message,
        }))
      : [];
    return res.status(422).json({
      success: false,
      message: "Données invalides",
      errors,
    });
  }

  if (error.name === "CastError") {
    return res.status(400).json({
      success: false,
      message: "Identifiant invalide",
    });
  }

  return res.status(500).json({
    success: false,
    message: "Erreur serveur",
    error: error.message,
  });
};

const getEmailSettings = async (req, res) => {
  try {
    const { storeId } = req.params;
    const settings = await emailSettingsService.getByStoreId(storeId);

    return res.status(200).json({
      success: true,
      message: "Paramètres e-mail récupérés avec succès",
      data: settings,
    });
  } catch (error) {
    return handleError(res, error);
  }
};

const updateEmailSettings = async (req, res) => {
  try {
    const { storeId } = req.params;
    const { notifications } = req.body;
    const settings = await emailSettingsService.upsertByStoreId(
      storeId,
      notifications,
      req.user
    );

    return res.status(200).json({
      success: true,
      message: "Paramètres e-mail mis à jour avec succès",
      data: settings,
    });
  } catch (error) {
    return handleError(res, error);
  }
};

const toggleEmailNotification = async (req, res) => {
  try {
    const { storeId, key } = req.params;
    const { enabled } = req.body;
    const settings = await emailSettingsService.toggleNotification(
      storeId,
      key,
      !!enabled,
      req.user
    );

    return res.status(200).json({
      success: true,
      message: "Notification e-mail mise à jour avec succès",
      data: settings,
    });
  } catch (error) {
    return handleError(res, error);
  }
};

const getEmailTemplate = async (req, res) => {
  try {
    const { storeId } = req.params;
    const template = await emailSettingsService.getTemplate(storeId);

    return res.status(200).json({
      success: true,
      message: "Modèle d'e-mail récupéré avec succès",
      data: template,
    });
  } catch (error) {
    return handleError(res, error);
  }
};

const updateEmailTemplate = async (req, res) => {
  try {
    const { storeId } = req.params;
    const template = await emailSettingsService.upsertTemplate(
      storeId,
      req.body,
      req.user
    );

    return res.status(200).json({
      success: true,
      message: "Modèle d'e-mail mis à jour avec succès",
      data: template,
    });
  } catch (error) {
    return handleError(res, error);
  }
};

const previewEmailNotification = async (req, res) => {
  try {
    const { storeId, key } = req.params;
    const html = await emailSettingsService.renderPreview(
      storeId,
      key,
      req.body
    );

    return res.status(200).json({
      success: true,
      message: "Aperçu généré avec succès",
      data: { html },
    });
  } catch (error) {
    return handleError(res, error);
  }
};

const sendTestEmailNotification = async (req, res) => {
  try {
    const { storeId, key } = req.params;
    const { testEmail, ...draft } = req.body;
    await emailSettingsService.sendTestEmail(storeId, key, draft, testEmail);

    return res.status(200).json({
      success: true,
      message: "E-mail de test envoyé avec succès",
    });
  } catch (error) {
    return handleError(res, error);
  }
};

// ─── Store SMTP (MAIL-02) ────────────────────────────────────────────────
const getSmtpSettings = async (req, res) => {
  try {
    const { storeId } = req.params;
    const smtp = await emailSettingsService.getSmtpSettings(storeId);

    return res.status(200).json({
      success: true,
      message: "Configuration SMTP récupérée avec succès",
      data: smtp,
    });
  } catch (error) {
    return handleError(res, error);
  }
};

const updateSmtpSettings = async (req, res) => {
  try {
    const { storeId } = req.params;
    const smtp = await emailSettingsService.updateSmtpSettings(storeId, req.body, req.user);

    return res.status(200).json({
      success: true,
      message: "Configuration SMTP mise à jour avec succès",
      data: smtp,
    });
  } catch (error) {
    return handleError(res, error);
  }
};

const sendSmtpTestEmail = async (req, res) => {
  try {
    const { storeId } = req.params;
    const { to } = req.body;
    const result = await emailSettingsService.sendSmtpTestEmail(storeId, to, req.user);

    return res.status(200).json({
      success: true,
      message: "E-mail de test envoyé avec succès",
      data: result,
    });
  } catch (error) {
    return handleError(res, error);
  }
};

module.exports = {
  getEmailSettings,
  updateEmailSettings,
  toggleEmailNotification,
  getEmailTemplate,
  updateEmailTemplate,
  previewEmailNotification,
  sendTestEmailNotification,
  getSmtpSettings,
  updateSmtpSettings,
  sendSmtpTestEmail,
};
