const express = require('express');
const router = express.Router();

const savedBlockController = {
  listSavedBlocks: (req, res) => res.status(501).json({ success: false, message: 'List saved blocks not implemented' }),
  createSavedBlock: (req, res) => res.status(501).json({ success: false, message: 'Create saved block not implemented' }),
  deleteSavedBlock: (req, res) => res.status(501).json({ success: false, message: 'Delete saved block not implemented' }),
  getSavedBlockUsageCount: (req, res) => res.status(501).json({ success: false, message: 'Saved block usage count not implemented' }),
};

module.exports = savedBlockController;
const SavedBlock = require("../models/SavedBlock.model");
const SyncedBlockUsage = require("../models/SyncedBlockUsage");

/**
 * ADMIN controller — authenticated. Scopé par storeId à chaque opération
 * pour garantir qu'un marchand ne voit jamais les blocs sauvegardés
 * d'une autre boutique.
 */

exports.listSavedBlocks = async (req, res) => {
  try {
    const { storeId } = req.params;
    const blocks = await SavedBlock.find({ storeId }).sort({ createdAt: -1 }).lean();
    return res.json(blocks);
  } catch (err) {
    console.error("listSavedBlocks error:", err);
    return res.status(500).json({ error: "Erreur serveur" });
  }
};

exports.createSavedBlock = async (req, res) => {
  try {
    const { storeId } = req.params;
    const { name, category, componentJson, isSynced, isGlobalComponent } = req.body;

    if (!name || !componentJson) {
      return res.status(400).json({ error: "name et componentJson sont requis" });
    }

    // If created via the Global Components flow, force isSynced = true
    const finalIsSynced = isGlobalComponent ? true : Boolean(isSynced);

    const block = await SavedBlock.create({
      storeId,
      name,
      category: category || (isGlobalComponent ? "🌐 Composants Globaux" : "⭐ Mes Blocs"),
      componentJson,
      isSynced: finalIsSynced,
      isGlobalComponent: Boolean(isGlobalComponent),
      createdBy: req.user?._id || null,
    });

    return res.status(201).json(block);
  } catch (err) {
    console.error("createSavedBlock error:", err);
    return res.status(500).json({ error: "Erreur serveur" });
  }
};

exports.deleteSavedBlock = async (req, res) => {
  try {
    const { storeId, blockId } = req.params;
    const deleted = await SavedBlock.findOneAndDelete({ _id: blockId, storeId });

    if (!deleted) {
      return res.status(404).json({ error: "Bloc introuvable" });
    }

    return res.json({ success: true });
  } catch (err) {
    console.error("deleteSavedBlock error:", err);
    return res.status(500).json({ error: "Erreur serveur" });
  }
};

exports.getSavedBlockUsageCount = async (req, res) => {
  try {
    const { blockId } = req.params;
    const count = await SyncedBlockUsage.countDocuments({ savedBlockId: blockId });
    return res.json({ count });
  } catch (err) {
    console.error("getSavedBlockUsageCount error:", err);
    return res.status(500).json({ error: "Erreur serveur" });
  }
};
