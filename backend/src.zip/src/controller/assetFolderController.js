const express = require('express');
const router = express.Router();

const assetFolderController = {
  createFolder: (req, res) => res.status(501).json({ success: false, message: 'Create folder not implemented' }),
  listFolders: (req, res) => res.status(501).json({ success: false, message: 'List folders not implemented' }),
  deleteFolder: (req, res) => res.status(501).json({ success: false, message: 'Delete folder not implemented' }),
};

module.exports = assetFolderController;
const AssetFolder = require("../models/AssetFolder");

const normalizeFolderPath = (folder) => {
  if (!folder || typeof folder !== "string") return "/";
  const cleaned = folder.trim().replace(/\\\\/g, "/").replace(/\/+/g, "/");
  const path = cleaned.startsWith("/") ? cleaned : `/${cleaned}`;
  return path === "/" ? "/" : path.replace(/\/$/, "");
};

const getFolderName = (folderPath) => {
  if (!folderPath || folderPath === "/") return "/";
  return folderPath.split("/").filter(Boolean).pop() || "/";
};

const getParentPath = (folderPath) => {
  if (!folderPath || folderPath === "/") return "/";
  const normalized = normalizeFolderPath(folderPath);
  const segments = normalized.split("/").filter(Boolean);
  if (segments.length <= 1) return "/";
  return `/${segments.slice(0, -1).join("/")}`;
};

exports.listFolders = async (req, res) => {
  try {
    const folders = await AssetFolder.find({ storeId: req.authContext?.storeId }).sort({ path: 1 }).lean();
    res.json(folders);
  } catch (err) {
    console.error("listFolders error:", err);
    res.status(500).json({ error: "Erreur serveur" });
  }
};

exports.createFolder = async (req, res) => {
  try {
    const { name, parentPath = "/", path } = req.body;
    const folderPath = normalizeFolderPath(path || `${parentPath}/${name}`);
    const folderName = getFolderName(folderPath);
    const finalParentPath = path ? getParentPath(folderPath) : normalizeFolderPath(parentPath);

    if (!folderName || folderPath === "/") {
      return res.status(400).json({ error: "Le nom du dossier est requis" });
    }

    const existing = await AssetFolder.findOne({ storeId: req.authContext?.storeId, path: folderPath });
    if (existing) {
      return res.status(200).json(existing);
    }

    const newFolder = await AssetFolder.create({
      storeId: req.authContext?.storeId,
      path: folderPath,
      name: folderName,
      parentPath: finalParentPath,
    });

    res.status(201).json(newFolder);
  } catch (err) {
    console.error("createFolder error:", err);
    res.status(500).json({ error: "Erreur serveur" });
  }
};

exports.deleteFolder = async (req, res) => {
  try {
    const folder = await AssetFolder.findOne({ _id: req.params.folderId, storeId: req.authContext?.storeId });
    if (!folder) {
      return res.status(404).json({ error: "Dossier introuvable" });
    }

    const child = await AssetFolder.findOne({ storeId: req.authContext?.storeId, parentPath: folder.path });
    if (child) {
      return res.status(400).json({ error: "Le dossier contient des sous-dossiers" });
    }

    const assetCount = await require("../models/Asset").countDocuments({ storeId: req.authContext?.storeId, folder: folder.path });
    if (assetCount > 0) {
      return res.status(400).json({ error: "Le dossier contient des fichiers" });
    }

    await folder.remove();
    res.json({ success: true });
  } catch (err) {
    console.error("deleteFolder error:", err);
    res.status(500).json({ error: "Erreur serveur" });
  }
};
