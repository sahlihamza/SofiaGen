const express = require('express');
const router = express.Router();

const themeController = {
  createTheme: (req, res) => res.status(501).json({ success: false, message: 'Theme creation not implemented' }),
  getAllThemes: (req, res) => res.status(501).json({ success: false, message: 'Theme listing not implemented' }),
  getThemeById: (req, res) => res.status(501).json({ success: false, message: 'Theme retrieval not implemented' }),
  updateTheme: (req, res) => res.status(501).json({ success: false, message: 'Theme update not implemented' }),
  publishTheme: (req, res) => res.status(501).json({ success: false, message: 'Theme publish not implemented' }),
  deleteTheme: (req, res) => res.status(501).json({ success: false, message: 'Theme delete not implemented' }),
  duplicateTheme: (req, res) => res.status(501).json({ success: false, message: 'Theme duplication not implemented' }),
  exportTheme: (req, res) => res.status(501).json({ success: false, message: 'Theme export not implemented' }),
  importTheme: (req, res) => res.status(501).json({ success: false, message: 'Theme import not implemented' }),
  getActiveTheme: (req, res) => res.status(501).json({ success: false, message: 'Active theme retrieval not implemented' }),
  updateThemeSettings: (req, res) => res.status(501).json({ success: false, message: 'Theme settings update not implemented' }),
};

module.exports = themeController;
const Theme = require("../models/Theme");
const Page = require("../models/Page");
const Section = require("../models/Section");
const AdmZip = require("adm-zip");
const ThemeService = require("../service/ThemeService");
const { hasStoreAccess } = require("../middleware/auth");

const assertStoreAccess = async (req, storeId) => {
  if (!req.user?.isSuperAdmin) {
    const roles = req.user?.role || [];
    if (!Array.isArray(roles) || !roles.some((r) => r?.name === "Super Admin")) {
      const granted = await hasStoreAccess(req.user, storeId);
      if (!granted) {
        throw { status: 403, success: false, message: "Accès refusé à ce store" };
      }
    }
  }
};

const generateUniqueSlug = (name) => {
  const baseSlug = (name || "default-theme")
    .toString()
    .toLowerCase()
    .replace(/[^a-z0-9\s-]/g, "")
    .replace(/\s+/g, "-")
    .replace(/-+/g, "-")
    .replace(/^-+|-+$/g, "")
    .substring(0, 40);
  return `${baseSlug || "default-theme"}-${Date.now()}-${Math.floor(Math.random() * 10000)}`;
};

// ========== Theme Controller ==========

/**
 * Create a new theme
 * POST /api/themes
 */
const createTheme = async (req, res) => {
  try {
    const { name, description, storeId } = req.body;

    if (!name || !storeId) {
      return res.status(400).json({
        message: "Name and storeId are required",
      });
    }

    const theme = new Theme({
      name,
      description,
      storeId,
      createdBy: req.user?.id,
    });

    await theme.save();

    res.status(201).json({
      success: true,
      message: "Theme created successfully",
      data: theme,
    });
  } catch (error) {
    res.status(500).json({
      message: error.message,
    });
  }
};

/**
 * Get all themes for a store
 * GET /api/themes?storeId=xxx
 */
const getAllThemes = async (req, res) => {
  try {
    const { storeId } = req.query;

    if (!storeId) {
      return res.status(400).json({
        message: "storeId is required",
      });
    }

    let themes = await Theme.find({ storeId })
      .sort({ createdAt: -1 })
      .select("-__v");

    if (themes.length === 0) {
      const defaultTheme = new Theme({
        name: "Default Theme",
        storeId,
        isActive: true,
        isDraft: false,
        colors: {
          primary: "#667eea",
          secondary: "#764ba2",
          accent: "#10b981",
          text: "#333333",
          background: "#ffffff",
        },
        fonts: {
          heading: "Arial",
          body: "Arial",
        },
        settings: {},
      });
      await defaultTheme.save();
      themes = [defaultTheme];
    } else {
      const hasActiveTheme = themes.some((theme) => theme.isActive);
      if (!hasActiveTheme) {
        const [themeToActivate] = themes;
        await Theme.findByIdAndUpdate(themeToActivate._id, {
          isActive: true,
          isDraft: false,
        });
        themes = await Theme.find({ storeId })
          .sort({ createdAt: -1 })
          .select("-__v");
      }
    }

    res.status(200).json({
      success: true,
      data: themes,
    });
  } catch (error) {
    res.status(500).json({
      message: error.message,
    });
  }
};

/**
 * Get theme by ID
 * GET /api/themes/:id
 */
const getThemeById = async (req, res) => {
  try {
    const theme = await Theme.findById(req.params.id);

    if (!theme) {
      return res.status(404).json({
        message: "Theme not found",
      });
    }

    if (!req.user?.isSuperAdmin) {
      const roles = req.user?.role || [];
      if (!Array.isArray(roles) || !roles.some((r) => r?.name === "Super Admin")) {
        const granted = await hasStoreAccess(req.user, theme.storeId);
        if (!granted) {
          return res.status(403).json({
            success: false,
            message: "Accès refusé à ce store",
          });
        }
      }
    }

    res.status(200).json({
      success: true,
      data: theme,
    });
  } catch (error) {
    res.status(500).json({
      message: error.message,
    });
  }
};

/**
 * Update theme
 * PUT /api/themes/:id
 */
const updateTheme = async (req, res) => {
  try {
    const { name, description, colors, fonts, settings, thumbnail } = req.body;

    const theme = await Theme.findById(req.params.id);

    if (!theme) {
      return res.status(404).json({
        message: "Theme not found",
      });
    }

    try {
      await assertStoreAccess(req, theme.storeId);
    } catch (err) {
      return res.status(err.status).json(err);
    }

    if (name !== undefined) theme.name = name;
    if (description !== undefined) theme.description = description;
    if (colors !== undefined) theme.colors = colors;
    if (fonts !== undefined) theme.fonts = fonts;
    if (settings !== undefined) theme.settings = settings;
    if (thumbnail !== undefined) theme.thumbnail = thumbnail;
    theme.updatedBy = req.user?.id;

    await theme.save();

    res.status(200).json({
      success: true,
      message: "Theme updated successfully",
      data: theme,
    });
  } catch (error) {
    if (error.status) {
      return res.status(error.status).json(error);
    }
    res.status(500).json({
      message: error.message,
    });
  }
};

/**
 * Publish theme
 * POST /api/themes/:id/publish
 */
const publishTheme = async (req, res) => {
  try {
    const theme = await Theme.findById(req.params.id);

    if (!theme) {
      return res.status(404).json({
        message: "Theme not found",
      });
    }

    try {
      await assertStoreAccess(req, theme.storeId);
    } catch (err) {
      return res.status(err.status).json(err);
    }

    // Désactive tous les autres thèmes du même store
    await Theme.updateMany(
      { storeId: theme.storeId, _id: { $ne: theme._id } },
      { isActive: false }
    );

    theme.isActive = true;
    theme.isDraft = false;
    theme.updatedBy = req.user?.id;
    await theme.save();

    res.status(200).json({
      success: true,
      message: "Theme published successfully",
      data: theme,
    });
  } catch (error) {
    if (error.status) {
      return res.status(error.status).json(error);
    }
    res.status(500).json({
      message: error.message,
    });
  }
};

/**
 * Delete theme
 * DELETE /api/themes/:id
 */
const deleteTheme = async (req, res) => {
  try {
    const theme = await Theme.findById(req.params.id);

    if (!theme) {
      return res.status(404).json({
        message: "Theme not found",
      });
    }

    try {
      await assertStoreAccess(req, theme.storeId);
    } catch (err) {
      return res.status(err.status).json(err);
    }

    if (theme.isActive) {
      return res.status(400).json({
        message: "Cannot delete the active theme. Please activate another theme first.",
      });
    }

    // Récupère toutes les pages du thème
    const pages = await Page.find({ themeId: theme._id });

    // Collecte tous les section IDs référencés par ces pages
    const sectionIds = pages.reduce(
      (acc, p) => acc.concat(p.sections || []),
      []
    );

    // Supprime les sections, puis les pages, puis le thème
    if (sectionIds.length > 0) {
      await Section.deleteMany({ _id: { $in: sectionIds } });
    }
    await Page.deleteMany({ themeId: theme._id });
    await Theme.findByIdAndDelete(req.params.id);

    res.status(200).json({
      success: true,
      message: "Theme deleted successfully",
    });
  } catch (error) {
    res.status(500).json({
      message: error.message,
    });
  }
};

const getActiveTheme = async (req, res) => {
  try {
    const { storeId } = req.params;
    let theme = await Theme.findOne({ storeId, isActive: true });

    if (!theme) {
      theme = await Theme.findOne({ storeId }).sort({ updatedAt: -1 });
      if (!theme) {
        theme = new Theme({
          name: "Default Theme",
          storeId,
          isActive: true,
          isDraft: false,
          colors: {
            primary: "#667eea",
            secondary: "#764ba2",
            accent: "#10b981",
            text: "#333333",
            background: "#ffffff",
          },
          settings: {},
        });
        await theme.save();
      }
    }

    res.status(200).json(theme);
  } catch (error) {
    res.status(500).json({
      message: error.message,
    });
  }
};

const updateThemeSettings = async (req, res) => {
  try {
    const { storeId } = req.params;
    const { settings } = req.body;

    let theme = await Theme.findOne({ storeId, isActive: true });
    if (!theme) {
      theme = await Theme.findOne({ storeId });
      if (!theme) {
        theme = new Theme({
          name: "Default Theme",
          storeId,
          isActive: true,
          isDraft: false,
        });
      }
    }

    theme.settings = settings;
    theme.updatedBy = req.user?.id;
    await theme.save();

    res.status(200).json(theme);
  } catch (error) {
    res.status(500).json({
      message: error.message,
    });
  }
};

const duplicateTheme = async (req, res) => {
  try {
    const themeToDuplicate = await Theme.findById(req.params.id);
    if (!themeToDuplicate) {
      return res.status(404).json({ message: "Theme not found" });
    }

    const result = await ThemeService.cloneThemeForStore(
      themeToDuplicate.storeId,
      themeToDuplicate._id,
      req.user?.id
    );

    res.status(201).json({ success: true, data: result.theme });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

const exportTheme = async (req, res) => {
  try {
    const theme = await Theme.findById(req.params.id);
    if (!theme) return res.status(404).json({ message: "Theme not found" });

    const pages = await Page.find({ themeId: theme._id });
    const allSectionIds = pages.reduce((acc, p) => acc.concat(p.sections || []), []);
    const sections = await Section.find({ _id: { $in: allSectionIds } });

    const zip = new AdmZip();

    // Add theme.json
    zip.addFile("theme.json", Buffer.from(JSON.stringify({
      name: theme.name,
      colors: theme.colors,
      fonts: theme.fonts,
      settings: theme.settings,
      version: theme.version || "1.0",
    }, null, 2)));

    // Add pages
    pages.forEach(p => {
      zip.addFile(`pages/${p.slug}.json`, Buffer.from(JSON.stringify({
        title: p.title,
        slug: p.slug,
        projectData: p.projectData,
        components: p.components,
        isHome: p.isHome,
        pageType: p.pageType,
        sectionIds: p.sections // We'll map these back on import
      }, null, 2)));
    });

    // Add sections
    sections.forEach(s => {
      zip.addFile(`sections/${s._id}.json`, Buffer.from(JSON.stringify({
        originalId: s._id,
        name: s.name,
        components: s.components,
        styles: s.styles,
        html: s.html,
        css: s.css
      }, null, 2)));
    });

    const zipBuffer = zip.toBuffer();
    res.setHeader("Content-Type", "application/zip");
    res.setHeader("Content-Disposition", `attachment; filename="${theme.slug || 'theme'}.zip"`);
    res.send(zipBuffer);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

const importTheme = async (req, res) => {
  try {
    if (!req.file) return res.status(400).json({ message: "No ZIP file provided" });
    const { storeId } = req.body;
    if (!storeId) return res.status(400).json({ message: "storeId is required" });

    const zip = new AdmZip(req.file.buffer);
    const zipEntries = zip.getEntries();
    
    let themeData = null;
    const pagesData = [];
    const sectionsData = [];

    zipEntries.forEach(entry => {
      if (entry.entryName === "theme.json") {
        themeData = JSON.parse(entry.getData().toString("utf8"));
      } else if (entry.entryName.startsWith("pages/") && entry.entryName.endsWith(".json")) {
        pagesData.push(JSON.parse(entry.getData().toString("utf8")));
      } else if (entry.entryName.startsWith("sections/") && entry.entryName.endsWith(".json")) {
        sectionsData.push(JSON.parse(entry.getData().toString("utf8")));
      }
    });

    if (!themeData) {
      return res.status(400).json({ message: "Invalid theme ZIP: missing theme.json" });
    }

    const newTheme = new Theme({
      name: themeData.name + " (Imported)",
      slug: (themeData.name || "theme").toLowerCase().replace(/[^a-z0-9]+/g, "-") + "-" + Date.now(),
      storeId,
      colors: themeData.colors,
      fonts: themeData.fonts,
      settings: themeData.settings,
      isActive: false,
      isDraft: true,
      createdBy: req.user?.id,
    });
    await newTheme.save();

    // Map old section IDs to new section IDs
    const sectionIdMap = {};
    for (const sData of sectionsData) {
      const newSection = new Section({
        name: sData.name,
        components: sData.components,
        styles: sData.styles,
        html: sData.html,
        css: sData.css,
        storeId,
        createdBy: req.user?.id,
      });
      await newSection.save();
      sectionIdMap[sData.originalId] = newSection._id;
    }

    for (const pData of pagesData) {
      const mappedSectionIds = (pData.sectionIds || []).map(oldId => sectionIdMap[oldId]).filter(Boolean);
      
      const newPage = new Page({
        title: pData.title,
        slug: pData.slug + "-" + Date.now(),
        urlSlug: (pData.slug + "-" + Date.now()).replace(/\//g, "-"),
        storeId,
        themeId: newTheme._id,
        projectData: pData.projectData,
        components: pData.components,
        isHome: false,
        isPublished: false,
        isDraft: true,
        pageType: pData.pageType || "custom",
        sections: mappedSectionIds,
        createdBy: req.user?.id,
      });
      await newPage.save();
    }

    res.status(201).json({ success: true, data: newTheme });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

module.exports = {
  createTheme,
  getAllThemes,
  getThemeById,
  updateTheme,
  publishTheme,
  deleteTheme,
  getActiveTheme,
  updateThemeSettings,
  duplicateTheme,
  exportTheme,
  importTheme,
};
