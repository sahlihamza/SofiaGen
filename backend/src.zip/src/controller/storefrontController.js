const Store = require("../models/Store");

// The store this shop front sells for. Same Store.isSelected singleton the
// admin switches on (see utils/getActiveStore.js), with a fallback to the
// only active store so a fresh install still serves a storefront.
const getCurrentStore = async (req, res) => {
  try {
    const store =
      (await Store.findOne({ isSelected: true })) ||
      (await Store.findOne({ isActive: true }));

    if (!store) {
      return res.status(404).json({ message: "Aucune boutique active" });
    }

    // Public projection only — a visitor has no account, so nothing here may
    // depend on staff auth.
    res.json({
      _id: store._id,
      name: store.name,
      logo: store.logo,
      address: store.address,
      currency: store.currency,
      reviewSettings: store.reviewSettings,
    });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

module.exports = { getCurrentStore };
