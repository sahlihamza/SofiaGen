const StoreOwnerDashboardServiceV2 = require("../service/StoreOwnerDashboardServiceV2");

const getStoreOwnerDashboardV2 = async (req, res) => {
  try {
    const storeId = req.currentStoreId || req.user?.currentStoreId || null;
    // SO-15: the below-the-fold widgets (AI insights, top products, best
    // customers, sales channels, recent activity) are fetched lazily by the
    // frontend on scroll via GET /widget/:widget instead — omitted here so
    // the initial dashboard load doesn't pay for work nobody may ever
    // scroll down to see. Each of those builders/routes still exists
    // unchanged and independently cached (see getStoreOwnerDashboardWidget).
    const payload = await StoreOwnerDashboardServiceV2.getCached(storeId, "full", async () => {
      const kpis = await StoreOwnerDashboardServiceV2.buildKpiCardsPayload(storeId);
      const [
        analytics, orders, customers, products, inventory, payments, shipping, marketing, reviews,
        performance, visitors, financial, tasks, alerts, health, goals, conversionFunnel, onboarding,
      ] = await Promise.all([
        StoreOwnerDashboardServiceV2.buildSalesAnalyticsPayload(storeId, req.query.range || "30days"),
        StoreOwnerDashboardServiceV2.buildOrdersPayload(storeId),
        StoreOwnerDashboardServiceV2.buildCustomersPayload(storeId),
        StoreOwnerDashboardServiceV2.buildProductsPayload(storeId),
        StoreOwnerDashboardServiceV2.buildInventoryPayload(storeId),
        StoreOwnerDashboardServiceV2.buildPaymentsPayload(storeId),
        StoreOwnerDashboardServiceV2.buildShippingPayload(storeId),
        StoreOwnerDashboardServiceV2.buildMarketingPayload(storeId),
        StoreOwnerDashboardServiceV2.buildReviewsPayload(storeId),
        StoreOwnerDashboardServiceV2.buildStorePerformancePayload(storeId),
        StoreOwnerDashboardServiceV2.buildVisitorsPayload(storeId),
        StoreOwnerDashboardServiceV2.buildFinancialPayload(storeId),
        StoreOwnerDashboardServiceV2.buildTasksPayload(storeId),
        StoreOwnerDashboardServiceV2.buildAlertsPayload(storeId),
        StoreOwnerDashboardServiceV2.buildHealthScorePayload(storeId),
        StoreOwnerDashboardServiceV2.buildGoalsPayload(storeId),
        StoreOwnerDashboardServiceV2.buildConversionFunnelPayload(storeId),
        StoreOwnerDashboardServiceV2.buildOnboardingPayload(storeId),
      ]);
      return {
        ...kpis, analytics, orders, customers, products, inventory, payments, shipping, marketing, reviews,
        performance, visitors, financial, tasks, alerts, health, goals, conversionFunnel, onboarding,
        actions: StoreOwnerDashboardServiceV2.buildQuickActionsPayload(),
      };
    });
    res.json(payload);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

const getStoreOwnerDashboardWidget = async (req, res) => {
  try {
    const storeId = req.currentStoreId || req.user?.currentStoreId || null;
    const widget = req.params.widget;
    const builders = {
      kpi: StoreOwnerDashboardServiceV2.buildKpiCardsPayload,
      analytics: () => StoreOwnerDashboardServiceV2.buildSalesAnalyticsPayload(storeId, req.query.range || "30days"),
      orders: StoreOwnerDashboardServiceV2.buildOrdersPayload,
      customers: StoreOwnerDashboardServiceV2.buildCustomersPayload,
      products: StoreOwnerDashboardServiceV2.buildProductsPayload,
      inventory: StoreOwnerDashboardServiceV2.buildInventoryPayload,
      payments: StoreOwnerDashboardServiceV2.buildPaymentsPayload,
      shipping: StoreOwnerDashboardServiceV2.buildShippingPayload,
      marketing: StoreOwnerDashboardServiceV2.buildMarketingPayload,
      reviews: StoreOwnerDashboardServiceV2.buildReviewsPayload,
      performance: StoreOwnerDashboardServiceV2.buildStorePerformancePayload,
      visitors: StoreOwnerDashboardServiceV2.buildVisitorsPayload,
      financial: StoreOwnerDashboardServiceV2.buildFinancialPayload,
      tasks: StoreOwnerDashboardServiceV2.buildTasksPayload,
      alerts: StoreOwnerDashboardServiceV2.buildAlertsPayload,
      recentActivity: StoreOwnerDashboardServiceV2.buildRecentActivityPayload,
      topProducts: StoreOwnerDashboardServiceV2.buildTopProductsPayload,
      bestCustomers: StoreOwnerDashboardServiceV2.buildBestCustomersPayload,
      salesChannels: StoreOwnerDashboardServiceV2.buildSalesChannelsPayload,
      aiInsights: StoreOwnerDashboardServiceV2.buildAiInsightsPayload,
      health: StoreOwnerDashboardServiceV2.buildHealthScorePayload,
      goals: StoreOwnerDashboardServiceV2.buildGoalsPayload,
      conversionFunnel: StoreOwnerDashboardServiceV2.buildConversionFunnelPayload,
      onboarding: StoreOwnerDashboardServiceV2.buildOnboardingPayload,
    };
    const builder = builders[widget];
    if (!builder) return res.status(404).json({ message: "Widget not found" });
    const data = await StoreOwnerDashboardServiceV2.getCached(storeId, widget, () => builder(storeId));
    res.json({ data });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

const refreshStoreOwnerDashboard = async (req, res) => {
  try {
    const storeId = req.currentStoreId || req.user?.currentStoreId || null;
    await StoreOwnerDashboardServiceV2.invalidateCache(storeId);
    res.json({ message: "Dashboard cache invalidated" });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

module.exports = { getStoreOwnerDashboardV2, getStoreOwnerDashboardWidget, refreshStoreOwnerDashboard };
