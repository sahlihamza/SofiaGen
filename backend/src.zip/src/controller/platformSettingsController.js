const PlatformSettingsService = require("../service/PlatformSettingsService");
const AuditService = require("../service/AuditService");
const EmailQueue = require("../service/email/EmailQueue");
const PlatformSettings = require("../models/PlatformSettings");
const { decrypt, isEncrypted } = require("../utils/encryption");
const EmailTransportFactory = require("../service/email/EmailTransportFactory");
const { sendTestEmailViaSmtp } = require("../service/email/sendTestEmailViaSmtp");

// MAIL-Platform — audit payload never contains password/encrypted/auth data.
const maskUser = (user) => {
  const value = String(user || "");
  if (!value) return null;
  const at = value.indexOf("@");
  if (at > 0) return `${value.slice(0, Math.min(2, at))}***${value.slice(at)}`;
  return `${value.slice(0, 2)}***`;
};
const sanitizeAuditSmtp = (smtp = {}) => ({
  enabled: Boolean(smtp.enabled),
  host: smtp.host || null,
  port: smtp.port ?? null,
  secure: Boolean(smtp.secure),
  user: maskUser(smtp.user),
});

const getSettings = async (req, res) => {
  try {
    const settings = await PlatformSettingsService.getSettings();
    return res.status(200).json({
      success: true,
      data: settings,
    });
  } catch (error) {
    return res.status(500).json({
      success: false,
      message: "Erreur serveur",
      error: error.message,
    });
  }
};

const updateSettings = async (req, res) => {
  try {
    const settings = await PlatformSettingsService.updateSettings(req.body);

    return res.status(200).json({
      success: true,
      message: "Paramètres mis à jour avec succès",
      data: settings,
    });
  } catch (error) {
    if (error.name === "ValidationError") {
      return res.status(400).json({ success: false, message: error.message });
    }
    return res.status(500).json({
      success: false,
      message: "Erreur serveur",
      error: error.message,
    });
  }
};

const getPasswordPolicy = async (req, res) => {
  try {
    const policy = await PlatformSettingsService.getPasswordPolicy();
    return res.status(200).json({
      success: true,
      data: policy,
    });
  } catch (error) {
    return res.status(500).json({
      success: false,
      message: "Erreur serveur",
      error: error.message,
    });
  }
};

const updatePasswordPolicy = async (req, res) => {
  try {
    const policy = await PlatformSettingsService.updatePasswordPolicy(req.body);

    return res.status(200).json({
      success: true,
      message: "Politique de mot de passe mise à jour",
      data: policy,
    });
  } catch (error) {
    return res.status(500).json({
      success: false,
      message: "Erreur serveur",
      error: error.message,
    });
  }
};

// ─── Platform email (MAIL-03) ────────────────────────────────────────────
const getEmailHealth = async (req, res) => {
  try {
    const health = await PlatformSettingsService.getEmailHealth();
    return res.status(200).json({ success: true, data: health });
  } catch (error) {
    return res.status(500).json({
      success: false,
      message: "Erreur serveur",
      error: error.message,
    });
  }
};

const sendPlatformEmailTest = async (req, res) => {
  try {
    const { to } = req.body;
    const result = await PlatformSettingsService.sendTestEmail(to, req.user);

    return res.status(200).json({
      success: true,
      message: "E-mail de test envoyé avec succès",
      data: result,
    });
  } catch (error) {
    if (error.name === "InvalidRecipientEmail") {
      return res.status(400).json({ success: false, message: error.message });
    }
    return res.status(500).json({
      success: false,
      message: "Erreur serveur",
      error: error.message,
    });
  }
};

// Basic queue stats by type/channel/status (MAIL-04).
const getEmailQueueStats = async (req, res) => {
  try {
    const sinceDays = Number(req.query.sinceDays) || 30;
    const since = new Date(Date.now() - sinceDays * 24 * 60 * 60 * 1000);
    const stats = await EmailQueue.getStats({ since });
    return res.status(200).json({ success: true, data: stats });
  } catch (error) {
    return res.status(500).json({
      success: false,
      message: "Erreur serveur",
      error: error.message,
    });
  }
};

// MAIL-Platform — SMTP configuration (GET never returns any secret)
const getPlatformSmtp = async (req, res) => {
  try {
    const settings = await PlatformSettings.findOne()
      .select("+smtp.passwordEncrypted")
      .lean();
    const smtp = settings?.smtp || {};
    return res.status(200).json({
      success: true,
      data: {
        enabled: Boolean(smtp.enabled),
        host: smtp.host || "",
        port: smtp.port ?? 587,
        secure: Boolean(smtp.secure),
        user: smtp.user || "",
        hasPassword: Boolean(smtp.passwordEncrypted),
        updatedAt: smtp.updatedAt || null,
        updatedBy: smtp.updatedBy || null,
        source: smtp.enabled ? "database" : "environment",
      },
    });
  } catch (error) {
    return res.status(500).json({ success: false, message: error.message });
  }
};

const updatePlatformSmtp = async (req, res) => {
  try {
    const body = req.body || {};
    const settingsDoc =
      (await PlatformSettings.findOne().select("+smtp.passwordEncrypted")) ||
      new PlatformSettings();

    const oldAudit = sanitizeAuditSmtp(settingsDoc.smtp || {});

    // Validation — enabling requires a usable configuration.
    const port = body.port !== undefined ? Number(body.port) : settingsDoc.smtp?.port ?? 587;
    if (!Number.isInteger(port) || port < 1 || port > 65535) {
      return res.status(400).json({ success: false, message: "Port must be an integer between 1 and 65535" });
    }
    const enabled = typeof body.enabled === "boolean" ? body.enabled : Boolean(settingsDoc.smtp?.enabled);
    const host = body.host !== undefined ? String(body.host).trim() : settingsDoc.smtp?.host || "";
    if (enabled && !host) {
      return res.status(400).json({ success: false, message: "SMTP host is required when the configuration is enabled" });
    }

    // Password rotation rule: absent/empty password keeps the stored one.
    let nextPassword = settingsDoc.smtp?.passwordEncrypted || "";
    if (typeof body.password === "string" && body.password !== "") {
      nextPassword = body.password;
    }

    settingsDoc.smtp = {
      enabled,
      host,
      port,
      secure: Boolean(body.secure ?? settingsDoc.smtp?.secure),
      user: body.user !== undefined ? String(body.user).trim() : settingsDoc.smtp?.user || "",
      passwordEncrypted: nextPassword,
      updatedBy: req.userId,
      updatedAt: new Date(),
    };

    await settingsDoc.save(); // triggers at-rest encryption via pre("save")

    EmailTransportFactory.invalidatePlatformTransports();

    AuditService.logAction({
      actorType: req.user?.isSuperAdmin ? "platform_admin" : "store_owner",
      actorId: req.userId,
      module: "platform_settings",
      action: "platform.settings.smtp_updated",
      summary: `Platform SMTP ${settingsDoc.smtp.enabled ? "enabled/updated" : "updated"} (host: ${settingsDoc.smtp.host}:${settingsDoc.smtp.port})`,
      entityType: "PlatformSettings",
      entityId: settingsDoc._id,
      severity: "critical",
      oldValue: oldAudit,
      newValue: sanitizeAuditSmtp(settingsDoc.smtp),
      requestId: req.requestId,
    }).catch(() => {});

    return res.status(200).json({
      success: true,
      message: "SMTP configuration saved",
      data: {
        enabled: settingsDoc.smtp.enabled,
        host: settingsDoc.smtp.host,
        port: settingsDoc.smtp.port,
        secure: settingsDoc.smtp.secure,
        user: settingsDoc.smtp.user,
        hasPassword: Boolean(nextPassword),
        source: settingsDoc.smtp.enabled ? "database" : "environment",
      },
    });
  } catch (error) {
    return res.status(400).json({ success: false, message: error.message });
  }
};

const testPlatformSmtp = async (req, res) => {
  try {
    const body = req.body || {};

    // Test uses the FORM values. Empty password falls back to the STORED one
    // so an admin can re-test without re-typing the secret.
    let pass = typeof body.password === "string" ? body.password : "";
    if (!pass) {
      const settings = await PlatformSettings.findOne()
        .select("+smtp.passwordEncrypted")
        .lean();
      const encrypted = settings?.smtp?.passwordEncrypted || "";
      if (encrypted && settings.smtp?.user === (body.user || "")) {
        pass = isEncrypted(encrypted)
          ? decrypt(encrypted)
          : encrypted;
      }
    }

    const result = await sendTestEmailViaSmtp({
      host: body.host,
      port: body.port,
      secure: body.secure,
      user: body.user,
      pass,
      fromName: "SofiaGen Platform",
      fromEmail: body.fromEmail,
      to: body.to,
      sourceLabel: "Platform",
    });

    AuditService.logAction({
      actorType: req.user?.isSuperAdmin ? "platform_admin" : "store_owner",
      actorId: req.userId,
      module: "platform_settings",
      action: "platform.settings.smtp_tested",
      summary: `Platform SMTP test e-mail sent to ${body.to} (${result.ok ? "OK" : "FAILED"}) using form values`,
      entityType: "PlatformSettings",
      severity: "low",
      requestId: req.requestId,
    }).catch(() => {});

    return res.status(200).json({ success: true, data: result });
  } catch (error) {
    AuditService.logAction({
      actorType: req.user?.isSuperAdmin ? "platform_admin" : "store_owner",
      actorId: req.userId,
      module: "platform_settings",
      action: "platform.settings.smtp_test_failed",
      summary: `Platform SMTP test failed: ${error.message}`,
      entityType: "PlatformSettings",
      severity: "medium",
      status: "failed",
      requestId: req.requestId,
    }).catch(() => {});
    return res.status(400).json({ success: false, message: error.message });
  }
};

module.exports = {
  getSettings,
  updateSettings,
  getPasswordPolicy,
  updatePasswordPolicy,
  getEmailHealth,
  sendPlatformEmailTest,
  getEmailQueueStats,
  getPlatformSmtp,
  updatePlatformSmtp,
  testPlatformSmtp,
};
