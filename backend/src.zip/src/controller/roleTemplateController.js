const roleTemplateService = require("../service/RoleTemplateService");

// ─── GET ALL TEMPLATES ────────────────────────────────────────────────────
const getAllTemplates = async (req, res) => {
  try {
    const templates = await roleTemplateService.getAllTemplates();
    return res.status(200).json({
      success: true,
      message: "Modèles de rôles récupérés avec succès",
      data: templates,
    });
  } catch (error) {
    return res.status(500).json({
      success: false,
      message: "Erreur serveur",
      error: error.message,
    });
  }
};

// ─── GET TEMPLATE BY ID ───────────────────────────────────────────────────
const getTemplateById = async (req, res) => {
  try {
    const { id } = req.params;
    const template = await roleTemplateService.getTemplateById(id);

    if (!template) {
      return res.status(404).json({
        success: false,
        message: "Modèle de rôle introuvable",
      });
    }

    return res.status(200).json({
      success: true,
      message: "Modèle de rôle récupéré avec succès",
      data: template,
    });
  } catch (error) {
    if (error.name === "CastError") {
      return res.status(400).json({
        success: false,
        message: "Identifiant invalide",
      });
    }

    return res.status(500).json({
      success: false,
      message: "Erreur serveur",
      error: error.message,
    });
  }
};

// ─── CREATE TEMPLATE ──────────────────────────────────────────────────────
const createTemplate = async (req, res) => {
  try {
    const { name, slug, description, scope, actionFilters, permissionCodes, isPredefined } = req.body;

    const template = await roleTemplateService.createTemplate({
      name,
      slug,
      description,
      scope: scope || "store",
      actionFilters: actionFilters || [],
      permissionCodes: permissionCodes || [],
      isPredefined: isPredefined || false,
    });

    return res.status(201).json({
      success: true,
      message: "Modèle de rôle créé avec succès",
      data: template,
    });
  } catch (error) {
    if (error.name === "ValidationError") {
      const errors = Object.values(error.errors).map((err) => ({
        field: err.path,
        message: err.message,
      }));
      return res.status(422).json({
        success: false,
        message: "Données invalides",
        errors,
      });
    }

    if (error.code === 11000) {
      return res.status(409).json({
        success: false,
        message: "Un modèle avec ce slug existe déjà",
      });
    }

    return res.status(500).json({
      success: false,
      message: "Erreur serveur",
      error: error.message,
    });
  }
};

// ─── UPDATE TEMPLATE ──────────────────────────────────────────────────────
const updateTemplate = async (req, res) => {
  try {
    const { id } = req.params;
    const { name, slug, description, scope, actionFilters, permissionCodes, isPredefined } = req.body;

    const template = await roleTemplateService.updateTemplate(id, {
      name,
      slug,
      description,
      scope,
      actionFilters,
      permissionCodes,
      isPredefined,
    });

    if (!template) {
      return res.status(404).json({
        success: false,
        message: "Modèle de rôle introuvable",
      });
    }

    return res.status(200).json({
      success: true,
      message: "Modèle de rôle mis à jour avec succès",
      data: template,
    });
  } catch (error) {
    if (error.name === "ValidationError") {
      const errors = Object.values(error.errors).map((err) => ({
        field: err.path,
        message: err.message,
      }));
      return res.status(422).json({
        success: false,
        message: "Données invalides",
        errors,
      });
    }

    if (error.code === 11000) {
      return res.status(409).json({
        success: false,
        message: "Un modèle avec ce slug existe déjà",
      });
    }

    return res.status(500).json({
      success: false,
      message: "Erreur serveur",
      error: error.message,
    });
  }
};

// ─── DELETE TEMPLATE ──────────────────────────────────────────────────────
const deleteTemplate = async (req, res) => {
  try {
    const { id } = req.params;
    const template = await roleTemplateService.deleteTemplate(id);

    if (!template) {
      return res.status(404).json({
        success: false,
        message: "Modèle de rôle introuvable",
      });
    }

    return res.status(200).json({
      success: true,
      message: "Modèle de rôle supprimé avec succès",
    });
  } catch (error) {
    if (error.name === "CastError") {
      return res.status(400).json({
        success: false,
        message: "Identifiant invalide",
      });
    }

    return res.status(500).json({
      success: false,
      message: "Erreur serveur",
      error: error.message,
    });
  }
};

module.exports = {
  getAllTemplates,
  getTemplateById,
  createTemplate,
  updateTemplate,
  deleteTemplate,
};
