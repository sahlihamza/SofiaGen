const express = require('express');
const router = express.Router();

const accountsPrivacyController = {
  getSettings: (req, res) => res.status(501).json({ success: false, message: 'Not implemented' }),
  updateSettings: (req, res) => res.status(501).json({ success: false, message: 'Not implemented' }),
};

module.exports = accountsPrivacyController;
