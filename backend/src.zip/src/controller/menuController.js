const express = require('express');
const router = express.Router();

const menuController = {
  createMenu: (req, res) => res.status(501).json({ success: false, message: 'Not implemented' }),
  getMenusByStore: (req, res) => res.status(501).json({ success: false, message: 'Not implemented' }),
  getMenuById: (req, res) => res.status(501).json({ success: false, message: 'Not implemented' }),
  updateMenu: (req, res) => res.status(501).json({ success: false, message: 'Not implemented' }),
  deleteMenu: (req, res) => res.status(501).json({ success: false, message: 'Not implemented' }),
  duplicateMenu: (req, res) => res.status(501).json({ success: false, message: 'Not implemented' }),
};

module.exports = menuController;
const Menu = require("../models/Menu");
const { hasStoreAccess } = require("../middleware/auth");

const assertStoreAccess = async (req, storeId) => {
  if (!req.user?.isSuperAdmin) {
    const roles = req.user?.role || [];
    if (!Array.isArray(roles) || !roles.some((r) => r?.name === "Super Admin")) {
      const granted = await hasStoreAccess(req.user, storeId);
      if (!granted) {
        throw { status: 403, error: "Accès refusé à ce store" };
      }
    }
  }
};

exports.createMenu = async (req, res) => {
  try {
    const { storeId, name, location, items, isActive } = req.body;
    const menu = new Menu({
      storeId,
      name,
      location,
      items: items || [],
      isActive: isActive !== undefined ? isActive : true,
      updatedBy: req.user?.id,
    });
    await menu.save();
    res.status(201).json(menu);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.getMenusByStore = async (req, res) => {
  try {
    const { storeId } = req.params;
    const { location } = req.query;
    const filter = { storeId };
    if (location) filter.location = location;
    
    const menus = await Menu.find(filter).sort({ createdAt: -1 });
    res.json(menus);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.getMenuById = async (req, res) => {
  try {
    const menu = await Menu.findById(req.params.id);
    if (!menu) return res.status(404).json({ error: "Menu not found" });

    try {
      await assertStoreAccess(req, menu.storeId);
    } catch (err) {
      return res.status(err.status).json(err);
    }

    res.json(menu);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.updateMenu = async (req, res) => {
  try {
    const { name, location, items, isActive } = req.body;
    const menu = await Menu.findByIdAndUpdate(
      req.params.id,
      {
        $set: {
          name,
          location,
          items,
          isActive,
          updatedBy: req.user?.id,
        },
      },
      { new: true }
    );
    if (!menu) return res.status(404).json({ error: "Menu not found" });

    try {
      await assertStoreAccess(req, menu.storeId);
    } catch (err) {
      return res.status(err.status).json(err);
    }

    res.json(menu);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.deleteMenu = async (req, res) => {
  try {
    const menu = await Menu.findById(req.params.id);
    if (!menu) return res.status(404).json({ error: "Menu not found" });

    try {
      await assertStoreAccess(req, menu.storeId);
    } catch (err) {
      return res.status(err.status).json(err);
    }

    await Menu.findByIdAndDelete(req.params.id);
    res.json({ message: "Menu deleted successfully" });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.duplicateMenu = async (req, res) => {
  try {
    const menu = await Menu.findById(req.params.id);
    if (!menu) return res.status(404).json({ error: "Menu not found" });
    const newMenu = new Menu({
      storeId: menu.storeId,
      name: `${menu.name} (copy)`,
      location: menu.location,
      items: menu.items,
      isActive: false,
      updatedBy: req.user?.id,
    });
    await newMenu.save();
    res.status(201).json(newMenu);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};
