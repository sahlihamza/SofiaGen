const roleService = require("../service/RoleService");

const requireCurrentStoreId = (req, res) => {
  const storeId = req.currentStoreId || req.user?.currentStoreId;
  if (!storeId) {
    res.status(400).json({
      success: false,
      message: "Aucun store sélectionné pour cet utilisateur",
    });
    return null;
  }
  return storeId;
};

// ─── GET ALL ROLES (of the current store) ───────────────────────────────
const getRoles = async (req, res) => {
  try {
    const storeId = requireCurrentStoreId(req, res);
    if (!storeId) return;

    const roles = await roleService.getRolesByStore(storeId);
    return res.status(200).json({
      success: true,
      message: "Liste des rôles récupérée avec succès",
      data: roles,
    });
  } catch (error) {
    return res.status(500).json({
      success: false,
      message: "Erreur serveur",
      error: error.message,
    });
  }
};

// ─── GET ROLE BY ID ─────────────────────────────────────────────────────
const getRoleById = async (req, res) => {
  try {
    const storeId = requireCurrentStoreId(req, res);
    if (!storeId) return;

    const { id } = req.params;
    const role = await roleService.getRoleByIdForStore(id, storeId);

    if (!role) {
      return res.status(404).json({
        success: false,
        message: "Rôle introuvable",
      });
    }

    return res.status(200).json({
      success: true,
      message: "Rôle récupéré avec succès",
      data: role,
    });
  } catch (error) {
    if (error.name === "CastError") {
      return res.status(400).json({
        success: false,
        message: "Identifiant invalide",
      });
    }

    return res.status(500).json({
      success: false,
      message: "Erreur serveur",
      error: error.message,
    });
  }
};

// ─── CREATE ROLE ────────────────────────────────────────────────────────
const createRole = async (req, res) => {
  try {
    const storeId = requireCurrentStoreId(req, res);
    if (!storeId) return;

    const { name, description, permissions } = req.body;

    const exists = await roleService.roleExists({ name, storeId });
    if (exists) {
      return res.status(409).json({
        success: false,
        message: "Ce rôle existe déjà",
      });
    }

    const role = await roleService.createRole({
      name,
      description,
      permissions,
      storeId,
    });

    return res.status(201).json({
      success: true,
      message: "Rôle créé avec succès",
      data: role,
    });
  } catch (error) {
    if (error.name === "ValidationError") {
      const errors = Object.values(error.errors).map((err) => ({
        field: err.path,
        message: err.message,
      }));
      return res.status(422).json({
        success: false,
        message: "Données invalides",
        errors,
      });
    }

    if (error.code === 11000) {
      return res.status(409).json({
        success: false,
        message: "Ce rôle existe déjà",
      });
    }

    return res.status(500).json({
      success: false,
      message: "Erreur serveur",
      error: error.message,
    });
  }
};

// ─── UPDATE ROLE ────────────────────────────────────────────────────────
const updateRole = async (req, res) => {
  try {
    const storeId = requireCurrentStoreId(req, res);
    if (!storeId) return;

    const { id } = req.params;
    const { name, description } = req.body;

    if (name) {
      const nameTaken = await roleService.roleExists({
        name,
        storeId,
        _id: { $ne: id },
      });

      if (nameTaken) {
        return res.status(409).json({
          success: false,
          message: "Ce nom de rôle est déjà utilisé",
        });
      }
    }

    const role = await roleService.updateRole(id, storeId, { name, description });

    if (!role) {
      return res.status(404).json({
        success: false,
        message: "Rôle introuvable",
      });
    }

    return res.status(200).json({
      success: true,
      message: "Rôle mis à jour avec succès",
      data: role,
    });
  } catch (error) {
    if (error.name === "ValidationError") {
      const errors = Object.values(error.errors).map((err) => ({
        field: err.path,
        message: err.message,
      }));
      return res.status(422).json({
        success: false,
        message: "Données invalides",
        errors,
      });
    }

    if (error.name === "CastError") {
      return res.status(400).json({
        success: false,
        message: "Identifiant invalide",
      });
    }

    return res.status(500).json({
      success: false,
      message: "Erreur serveur",
      error: error.message,
    });
  }
};

// ─── ASSIGN PERMISSIONS ─────────────────────────────────────────────────
const assignPermissions = async (req, res) => {
  try {
    const storeId = requireCurrentStoreId(req, res);
    if (!storeId) return;

    const { id } = req.params;
    const { permissions } = req.body;

    if (!Array.isArray(permissions)) {
      return res.status(422).json({
        success: false,
        message: "Le champ 'permissions' doit être un tableau d'identifiants",
      });
    }

    const role = await roleService.assignPermissions(id, storeId, permissions);

    if (!role) {
      return res.status(404).json({
        success: false,
        message: "Rôle introuvable",
      });
    }

    return res.status(200).json({
      success: true,
      message: "Permissions assignées avec succès",
      data: role,
    });
  } catch (error) {
    if (error.name === "InvalidPermissions") {
      return res.status(422).json({
        success: false,
        message: error.message,
      });
    }

    if (error.name === "CastError") {
      return res.status(400).json({
        success: false,
        message: "Identifiant invalide",
      });
    }

    return res.status(500).json({
      success: false,
      message: "Erreur serveur",
      error: error.message,
    });
  }
};

// ─── DELETE ROLE ────────────────────────────────────────────────────────
const deleteRole = async (req, res) => {
  try {
    const storeId = requireCurrentStoreId(req, res);
    if (!storeId) return;

    const { id } = req.params;
    const role = await roleService.deleteRole(id, storeId);

    if (!role) {
      return res.status(404).json({
        success: false,
        message: "Rôle introuvable",
      });
    }

    return res.status(200).json({
      success: true,
      message: "Rôle supprimé avec succès",
    });
  } catch (error) {
    if (error.name === "CastError") {
      return res.status(400).json({
        success: false,
        message: "Identifiant invalide",
      });
    }

    return res.status(500).json({
      success: false,
      message: "Erreur serveur",
      error: error.message,
    });
  }
};

// ─── GET ALL PERMISSIONS (pour construire l'UI de sélection) ───────────
const getPermissions = async (req, res) => {
  try {
    const permissions = await roleService.getAllPermissions();
    return res.status(200).json({
      success: true,
      message: "Liste des permissions récupérée avec succès",
      data: permissions,
    });
  } catch (error) {
    return res.status(500).json({
      success: false,
      message: "Erreur serveur",
      error: error.message,
    });
  }
};

// ─── GET PREDEFINED ROLES ───────────────────────────────────────────────
const getPredefinedRoles = async (req, res) => {
  try {
    const roles = await roleService.getPredefinedRoles();
    return res.status(200).json({
      success: true,
      message: "Rôles prédéfinis récupérés avec succès",
      data: roles,
    });
  } catch (error) {
    return res.status(500).json({
      success: false,
      message: "Erreur serveur",
      error: error.message,
    });
  }
};

module.exports = {
  getRoles,
  getRoleById,
  createRole,
  updateRole,
  assignPermissions,
  deleteRole,
  getPermissions,
  getPredefinedRoles,
};