const express = require('express');
const router = express.Router();

const templateController = {
  listTemplates: (req, res) => res.status(501).json({ success: false, message: 'List templates not implemented' }),
  getTemplateById: (req, res) => res.status(501).json({ success: false, message: 'Get template not implemented' }),
  createTemplate: (req, res) => res.status(501).json({ success: false, message: 'Create template not implemented' }),
  duplicateTemplate: (req, res) => res.status(501).json({ success: false, message: 'Duplicate template not implemented' }),
  updateTemplate: (req, res) => res.status(501).json({ success: false, message: 'Update template not implemented' }),
  deleteTemplate: (req, res) => res.status(501).json({ success: false, message: 'Delete template not implemented' }),
};

module.exports = templateController;
const Template = require("../models/Template.model");

exports.listTemplates = async (req, res) => {
  try {
    const { storeId } = req.params;
    const { type } = req.query;
    const filterType = type || "page";

    const templates = await Template.find({
      $or: [{ storeId: null }, { storeId }],
      type: filterType,
    })
      .sort({ isSystem: -1, createdAt: -1 })
      .lean();

    return res.json(templates);
  } catch (err) {
    console.error("listTemplates error:", err);
    return res.status(500).json({ error: "Erreur serveur" });
  }
};

exports.getTemplateById = async (req, res) => {
  try {
    const { storeId, templateId } = req.params;
    const template = await Template.findOne({ _id: templateId, storeId }).lean();
    if (!template) {
      return res.status(404).json({ error: "Modèle introuvable" });
    }
    return res.json(template);
  } catch (err) {
    console.error("getTemplateById error:", err);
    return res.status(500).json({ error: "Erreur serveur" });
  }
};

exports.createTemplate = async (req, res) => {
  try {
    const { storeId } = req.params;
    const { name, category, projectData, compiledHtml, compiledCss, type, popupSettings, isActive } = req.body;

    if (!name || !projectData) {
      return res.status(400).json({ error: "name et projectData sont requis" });
    }

    const template = await Template.create({
      storeId,
      name,
      category: category || "Autre",
      projectData,
      compiledHtml,
      compiledCss,
      type: type || "page",
      popupSettings,
      isActive: isActive || false,
      isSystem: false,
      createdBy: req.user?._id || null,
    });

    return res.status(201).json(template);
  } catch (err) {
    console.error("createTemplate error:", err);
    return res.status(500).json({ error: "Erreur serveur" });
  }
};

exports.deleteTemplate = async (req, res) => {
  try {
    const { storeId, templateId } = req.params;
    const deleted = await Template.findOneAndDelete({ _id: templateId, storeId });

    if (!deleted) {
      return res.status(404).json({ error: "Modèle introuvable ou non supprimable" });
    }

    return res.json({ success: true });
  } catch (err) {
    console.error("deleteTemplate error:", err);
    return res.status(500).json({ error: "Erreur serveur" });
  }
};

exports.updateTemplate = async (req, res) => {
  try {
    const { storeId, templateId } = req.params;
    const updates = req.body;
    
    const updated = await Template.findOneAndUpdate(
      { _id: templateId, storeId },
      { $set: updates },
      { new: true }
    );
    
    if (!updated) {
      return res.status(404).json({ error: "Modèle introuvable" });
    }
    
    return res.json(updated);
  } catch (err) {
    console.error("updateTemplate error:", err);
    return res.status(500).json({ error: "Erreur serveur" });
  }
};

exports.duplicateTemplate = async (req, res) => {
  try {
    const { storeId, templateId } = req.params;
    const original = await Template.findById(templateId).lean();
    if (!original) return res.status(404).json({ error: "Introuvable" });

    const copyData = {
      ...original,
      _id: undefined,
      id: undefined,
      name: `${original.name} (copie)`,
      storeId,
      favoritedBy: [],
      isSystem: false,
      createdBy: req.user?._id || null,
      createdAt: undefined,
      updatedAt: undefined,
    };

    const copy = await Template.create(copyData);
    return res.status(201).json(copy);
  } catch (err) {
    console.error("duplicateTemplate error:", err);
    return res.status(500).json({ error: "Erreur serveur" });
  }
};
