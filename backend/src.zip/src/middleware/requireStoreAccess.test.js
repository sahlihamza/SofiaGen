const test = require("node:test");
const assert = require("node:assert/strict");

const { hasStoreAccess, resolveTargetStoreId } = require("../middleware/auth");

test("resolveTargetStoreId prefers req.params.storeId", () => {
  const req = { params: { storeId: "storeA" }, body: {}, query: {}, currentStoreId: null };
  assert.equal(resolveTargetStoreId(req), "storeA");
});

test("resolveTargetStoreId falls back to req.body.storeId", () => {
  const req = { params: {}, body: { storeId: "storeB" }, query: {}, currentStoreId: null };
  assert.equal(resolveTargetStoreId(req), "storeB");
});

test("resolveTargetStoreId falls back to req.query.storeId", () => {
  const req = { params: {}, body: {}, query: { storeId: "storeC" }, currentStoreId: null };
  assert.equal(resolveTargetStoreId(req), "storeC");
});

test("resolveTargetStoreId falls back to req.currentStoreId", () => {
  const req = { params: {}, body: {}, query: {}, currentStoreId: "storeD" };
  assert.equal(resolveTargetStoreId(req), "storeD");
});

test("resolveTargetStoreId returns null when no storeId found", () => {
  const req = { params: {}, body: {}, query: {}, currentStoreId: null };
  assert.equal(resolveTargetStoreId(req), null);
});
