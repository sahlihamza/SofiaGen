require("dotenv").config();
const express = require("express");
const cors = require("cors");
const helmet = require("helmet");
const path = require("path");
const setupRoutes = require("./routes");
const cookieParser = require("cookie-parser");
const requestId = require("./middleware/requestId");
const apiLogger = require("./middleware/apiLogger");

const app = express();

/*
 * CSRF Protection Note:
 * This API is designed as a token-based API (JWT in Authorization header).
 * State-changing requests require a valid Bearer token, not cookies alone.
 * CSRF attacks rely on the browser automatically attaching cookies to requests.
 * Since this API does not rely solely on cookies for authentication,
 * and CORS is configured to restrict cross-origin requests,
 * CSRF token middleware is not currently implemented.
 *
 * If the auth model changes to cookie-only sessions, add csurf middleware.
 */

const allowedOrigins = (process.env.CORS_ORIGINS || "").split(",").map((s) => s.trim()).filter(Boolean);

const corsOptions = {
  origin: function (origin, callback) {
    if (!origin) return callback(null, true); // allow non-browser requests like curl or server-to-server
    // Allow explicit whitelist
    if (allowedOrigins.length === 0 || allowedOrigins.includes(origin) || allowedOrigins.includes("*")) {
      return callback(null, true);
    }
    // Allow any localhost/127.0.0.1 with any port only in development
    if (process.env.NODE_ENV !== "production") {
      try {
        const localhostPattern = /^https?:\/\/(localhost|127\.0\.0\.1)(:\d+)?$/i;
        if (localhostPattern.test(origin)) return callback(null, true);
      } catch (e) {
        // continue to deny
      }
    }
    const err = new Error("Not allowed by CORS");
    err.code = "CORS_ORIGIN_DENIED";
    console.warn("CORS origin denied:", origin);
    return callback(err);
  },
  credentials: true,
  methods: ["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"],
  optionsSuccessStatus: 204,
  maxAge: 86400,
};

app.use(express.json({ limit: "4mb" }));
app.use(helmet({ crossOriginResourcePolicy: { policy: "cross-origin" } }));
app.use(cookieParser());
app.use(cors(corsOptions));
app.use(requestId);
app.use(apiLogger);

setupRoutes(app);

// Use express's default error handling middleware
app.use((err, req, res, next) => {
  if (res.headersSent) return next(err);
  const status = err.status || (err.code === "CORS_ORIGIN_DENIED" ? 403 : 400);
  res.status(status).json({ message: err.message });
});

// Serve static files from the "dist" directory
app.use("/static", express.static("public"));
app.use("/invoices", express.static(path.join(__dirname, "../invoices")));

// Explicit 404 for undefined API routes before the SPA catch-all
app.use((req, res) => {
  if (req.path.startsWith("/api/")) {
    return res.status(404).json({ success: false, message: "Route not found" });
  }
  res.sendFile(path.join(__dirname, "build", "index.html"));
});

module.exports = app;
